"""FastAPI adapter - the primary server.

Registers the shared handlers from backend/app/routes.py, so the HTTP surface is
identical to the stdlib fallback while gaining OpenAPI docs at /docs.

    uvicorn backend.api_fastapi:app --reload
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fastapi import FastAPI, Request                              # noqa: E402
from fastapi.responses import FileResponse, JSONResponse          # noqa: E402
from fastapi.staticfiles import StaticFiles                       # noqa: E402

from backend.app import config                                    # noqa: E402
from backend.app.routes import ROUTES, ApiError                   # noqa: E402

app = FastAPI(
    title="Medical Equipment Procurement Copilot",
    version="1.0.0",
    description=(
        "AI-assisted, evidence-backed supplier decisions for medical equipment "
        "procurement. Prototype on synthetic data; AI output is decision support "
        "only and the procurement approver retains final award authority."),
)


@app.exception_handler(ApiError)
async def _api_error(_: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status, content={"error": exc.message})


def _register(method: str, path: str, handler):
    async def endpoint(request: Request):
        params = dict(request.path_params)
        params.update({k: v for k, v in request.query_params.items()})
        body = {}
        if method == "POST":
            try:
                body = await request.json()
            except Exception:
                body = {}
        try:
            return JSONResponse(content=_jsonable(handler(params, body)))
        except ApiError as exc:
            return JSONResponse(status_code=exc.status, content={"error": exc.message})
        except Exception as exc:                       # graceful, never a 500 page
            return JSONResponse(status_code=500,
                                content={"error": f"{type(exc).__name__}: {exc}"})

    endpoint.__name__ = handler.__name__
    app.add_api_route(path, endpoint, methods=[method],
                      name=handler.__name__,
                      summary=(handler.__doc__ or handler.__name__).strip().split("\n")[0])


def _jsonable(obj):
    import json
    return json.loads(json.dumps(obj, default=str))


for _m, _p, _h in ROUTES:
    _register(_m, _p, _h)


# Static: dashboard at /, source PDFs under /rag_documents for the doc viewer.
if config.RAG_DIR.exists():
    app.mount("/rag_documents", StaticFiles(directory=str(config.RAG_DIR)),
              name="rag_documents")


@app.get("/", include_in_schema=False)
def _index():
    return FileResponse(str(config.FRONTEND_DIR / "index.html"))


if config.FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(config.FRONTEND_DIR), html=True),
              name="frontend")
