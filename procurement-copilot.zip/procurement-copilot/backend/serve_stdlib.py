"""Zero-dependency server adapter (Python standard library only).

Serves the same routes as the FastAPI app plus the dashboard's static files.
Used automatically by run.py when FastAPI is not installed, so the demo works on
any machine with Python 3.10+ and nothing else.
"""
from __future__ import annotations

import json
import mimetypes
import re
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.app import config                                   # noqa: E402
from backend.app.routes import ROUTES, ApiError                  # noqa: E402


def _compile(path: str) -> re.Pattern:
    return re.compile("^" + re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", path) + "$")


COMPILED = [(m, _compile(p), h, p) for m, p, h in ROUTES]


class Handler(BaseHTTPRequestHandler):
    server_version = "ProcurementCopilot/1.0"

    def log_message(self, fmt, *args):        # keep the console readable
        if "/api/" in (args[0] if args else ""):
            sys.stderr.write("  %s\n" % (fmt % args))

    # ---------------------------------------------------------------- utils
    def _send(self, status: int, payload, content_type="application/json"):
        body = (json.dumps(payload, default=str).encode()
                if content_type == "application/json" else payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except BrokenPipeError:
            pass

    def _dispatch(self, method: str):
        parsed = urlparse(self.path)
        params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        for m, rx, handler, _tpl in COMPILED:
            if m != method:
                continue
            match = rx.match(parsed.path)
            if not match:
                continue
            params.update(match.groupdict())
            body = {}
            length = int(self.headers.get("Content-Length") or 0)
            if length:
                try:
                    body = json.loads(self.rfile.read(length) or b"{}")
                except json.JSONDecodeError:
                    return self._send(400, {"error": "Request body is not valid JSON"})
            try:
                return self._send(200, handler(params, body))
            except ApiError as exc:
                return self._send(exc.status, {"error": exc.message})
            except Exception as exc:                       # never 500 silently
                traceback.print_exc()
                return self._send(500, {"error": f"{type(exc).__name__}: {exc}"})

        if method == "GET":
            return self._static(parsed.path)
        self._send(404, {"error": f"No route for {method} {parsed.path}"})

    def _static(self, path: str):
        rel = "index.html" if path in ("/", "") else path.lstrip("/")
        # Serve the frontend, and the RAG source PDFs for the document viewer.
        # /rag_documents/... is mounted on RAG_DIR, so strip that prefix there.
        bases = [(config.FRONTEND_DIR, rel), (config.MODELS_DIR, rel)]
        if rel.startswith("rag_documents/"):
            bases.insert(0, (config.RAG_DIR, rel[len("rag_documents/"):]))
        for base, relative in bases:
            candidate = (base / relative).resolve()
            try:
                candidate.relative_to(base.resolve())
            except ValueError:
                continue                                   # path traversal attempt
            if candidate.is_file():
                ctype = mimetypes.guess_type(str(candidate))[0] or "application/octet-stream"
                return self._send(200, candidate.read_bytes(), ctype)
        self._send(404, {"error": f"Not found: {path}"})

    def do_GET(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")


def serve(host: str = None, port: int = None):
    host, port = host or config.HOST, port or config.PORT
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"  Procurement Copilot (stdlib server)  ->  http://{host}:{port}")
    print("  Ctrl-C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  stopped.")


if __name__ == "__main__":
    serve()
