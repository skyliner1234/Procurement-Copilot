"""Feature engineering shared by the ML risk model and the scoring engine.

Two distinct things are produced here and must not be confused:

* `ml_feature_vector`  - numeric inputs to the disruption-risk classifier.
* `subscores`          - deterministic 0-100 procurement sub-scores used by the
                         decision-score engine (scoring.py).

Categorical supplier attributes are mapped through the vocabularies in
config.py so that unseen values degrade to a conservative mid/low value rather
than raising.
"""
from __future__ import annotations

from typing import Any

from . import config


def _lc(v: Any) -> str:
    return str(v or "").strip().lower()


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


def _lerp_score(value: float | None, best: float, worst: float,
                default: float = 50.0) -> float:
    """Linear 0-100 score. `best` maps to 100, `worst` maps to 0.

    Works for both directions (best > worst or best < worst).
    """
    if value is None:
        return default
    if best == worst:
        return default
    return _clamp((value - worst) / (best - worst) * 100.0)


def _cat(value: Any, table: dict[str, float], default: float = 0.5) -> float:
    return table.get(_lc(value), default)


# ---------------------------------------------------------------------------
# ML features
# ---------------------------------------------------------------------------

def ml_feature_vector(sup: dict) -> dict[str, float]:
    """Build the model input row for one supplier.

    Deliberately excludes `synthetic_disruption_probability`: it is the latent
    generator parameter behind the training label, so including it would be
    target leakage.
    """
    return {
        "on_time_delivery": float(sup.get("on_time_delivery") or 0.0),
        "lead_time_variability": float(sup.get("lead_time_variability") or 0.0),
        "order_fulfillment_accuracy": float(sup.get("order_fulfillment_accuracy") or 0.0),
        "field_failure_rate": float(sup.get("field_failure_rate") or 0.0),
        "batch_rejection_rate": float(sup.get("batch_rejection_rate") or 0.0),
        "complaint_rate": float(sup.get("complaint_rate") or 0.0),
        "warranty_claim_rate": float(sup.get("warranty_claim_rate") or 0.0),
        "mtbf_hours": float(sup.get("mtbf_hours") or 0.0),
        "recalls_3y": float(sup.get("recalls_3y") or 0.0),
        "inspection_score": _cat(sup.get("last_inspection_outcome"),
                                 config.INSPECTION_OUTCOME_SCORE, 0.5) * 100.0,
        "regulatory_compliance_raw": float(sup.get("regulatory_compliance_raw") or 0.0),
        "historical_performance_raw": float(sup.get("historical_performance_raw") or 0.0),
        "capacity_utilization": float(sup.get("capacity_utilization") or 0.0),
        "demand_to_capacity": float(sup.get("demand_to_capacity") or 0.0),
        "country_risk": float(sup.get("country_risk") or 0.0),
        "transit_time_variability": float(sup.get("transit_time_variability") or 0.0),
        "payment_history": float(sup.get("payment_history") or 0.0),
        "credit_score": _cat(sup.get("credit_rating"),
                             config.CREDIT_RATING_SCORE, 0.5) * 100.0,
        "debt_to_equity": float(sup.get("debt_to_equity") or 0.0),
        "liquidity_ratio": float(sup.get("liquidity_ratio") or 0.0),
        "alternate_suppliers": float(sup.get("alternate_suppliers") or 0.0),
        "backup_facility": _cat(sup.get("backup_facility"),
                                config.BACKUP_FACILITY_SCORE, 0.5) * 100.0,
        "finished_goods_inventory_days": float(sup.get("finished_goods_inventory_days") or 0.0),
    }


def feature_matrix(suppliers: list[dict]) -> tuple[list[list[float]], list[int], list[str]]:
    """Return (X, y, supplier_ids) ordered by config.ML_FEATURES."""
    X, y, ids = [], [], []
    for s in suppliers:
        fv = ml_feature_vector(s)
        X.append([fv[f] for f in config.ML_FEATURES])
        y.append(int(s.get("historical_disruption_label") or 0))
        ids.append(s["supplier_id"])
    return X, y, ids


# ---------------------------------------------------------------------------
# Deterministic procurement sub-scores (0-100)
# ---------------------------------------------------------------------------

def quality_subscore(sup: dict) -> tuple[float, dict[str, float]]:
    """Product quality / reliability (policy section 6).

    Signals: field failure, batch rejection, complaint rate, warranty claims,
    MTBF, recalls and last inspection outcome.
    """
    parts = {
        "field_failure": _lerp_score(sup.get("field_failure_rate"), best=0.0, worst=7.0),
        "batch_rejection": _lerp_score(sup.get("batch_rejection_rate"), best=0.0, worst=8.0),
        "complaints": _lerp_score(sup.get("complaint_rate"), best=0.0, worst=22.0),
        "warranty_claims": _lerp_score(sup.get("warranty_claim_rate"), best=0.0, worst=10.0),
        "mtbf": _lerp_score(sup.get("mtbf_hours"), best=19000.0, worst=2500.0),
        "recalls": _lerp_score(sup.get("recalls_3y"), best=0.0, worst=7.0),
        "inspection": _cat(sup.get("last_inspection_outcome"),
                           config.INSPECTION_OUTCOME_SCORE, 0.5) * 100.0,
    }
    weights = {"field_failure": 0.24, "batch_rejection": 0.14, "complaints": 0.14,
               "warranty_claims": 0.12, "mtbf": 0.12, "recalls": 0.12,
               "inspection": 0.12}
    score = sum(parts[k] * weights[k] for k in parts)
    return round(_clamp(score), 2), {k: round(v, 1) for k, v in parts.items()}


def historical_subscore(sup: dict) -> tuple[float, dict[str, float]]:
    """Historical supplier performance (master prompt section 18)."""
    parts = {
        "on_time_delivery": _lerp_score(sup.get("on_time_delivery"), best=98.0, worst=55.0),
        "fulfillment_accuracy": _lerp_score(sup.get("order_fulfillment_accuracy"),
                                            best=98.0, worst=68.0),
        "payment_history": _lerp_score(sup.get("payment_history"), best=95.0, worst=40.0),
        "field_failure": _lerp_score(sup.get("field_failure_rate"), best=0.0, worst=7.0),
        "complaints": _lerp_score(sup.get("complaint_rate"), best=0.0, worst=22.0),
        "warranty_claims": _lerp_score(sup.get("warranty_claim_rate"), best=0.0, worst=10.0),
    }
    weights = {"on_time_delivery": 0.30, "fulfillment_accuracy": 0.22,
               "payment_history": 0.14, "field_failure": 0.14,
               "complaints": 0.10, "warranty_claims": 0.10}
    score = sum(parts[k] * weights[k] for k in parts)
    return round(_clamp(score), 2), {k: round(v, 1) for k, v in parts.items()}


def compliance_subscore(sup: dict, rfq: dict | None = None
                        ) -> tuple[float, dict[str, float], list[dict]]:
    """Regulatory compliance (policy section 2, master prompt section 20).

    Returns (score, components, hard_rule_flags).  Hard rules are returned
    rather than silently folded into the number, because policy requires them to
    drive routing (review / block) independently of the score.
    """
    fda, ce = _lc(sup.get("fda_status")), _lc(sup.get("ce_status"))
    iso, k510 = _lc(sup.get("iso_13485_status")), _lc(sup.get("clearance_510k_status"))
    insp = _lc(sup.get("last_inspection_outcome"))

    parts = {
        "fda": _cat(fda, config.FDA_STATUS_SCORE, 0.5) * 100.0,
        "ce": _cat(ce, config.CE_STATUS_SCORE, 0.5) * 100.0,
        "iso_13485": _cat(iso, config.ISO_STATUS_SCORE, 0.5) * 100.0,
        "clearance_510k": _cat(k510, config.CLEARANCE_STATUS_SCORE, 0.5) * 100.0,
        "inspection": _cat(insp, config.INSPECTION_OUTCOME_SCORE, 0.5) * 100.0,
        "recalls": _lerp_score(sup.get("recalls_3y"), best=0.0, worst=7.0),
        "adverse_events": _lerp_score(sup.get("adverse_events"), best=0.0, worst=40.0),
    }
    weights = {"fda": 0.26, "ce": 0.18, "iso_13485": 0.18, "clearance_510k": 0.18,
               "inspection": 0.10, "recalls": 0.06, "adverse_events": 0.04}
    score = sum(parts[k] * weights[k] for k in parts)

    flags: list[dict] = []

    def flag(code, severity, message, clause):
        flags.append({"code": code, "severity": severity,
                      "message": message, "clause": clause})

    if fda in config.SUSPENDED_FDA:
        flag("FDA_SUSPENDED", "BLOCKING",
             "FDA certification is suspended.",
             "POL-MED-001 §4 - suspended regulatory certification must not be auto-approved")
    if k510 in config.MISSING_CLEARANCE:
        flag("CLEARANCE_MISSING", "BLOCKING",
             "Mandatory 510(k) product clearance is not in place.",
             "POL-MED-001 §4 - missing mandatory product clearance must not be auto-approved")
    if iso in config.UNCERTIFIED_ISO:
        flag("ISO_MISSING", "BLOCKING",
             "ISO 13485 certification is missing.",
             "POL-MED-001 §2 - suppliers must provide ISO 13485 certification")
    if ce in config.INVALID_CE:
        flag("CE_EXPIRED", "REVIEW",
             "CE marking has expired.",
             "POL-MED-001 §2 - expired critical regulatory evidence requires procurement review")
    if ce == "under review":
        flag("CE_UNDER_REVIEW", "REVIEW",
             "CE marking is still under review.",
             "POL-MED-001 §2 - missing or expired critical regulatory evidence requires review")
    if k510 in config.PENDING_CLEARANCE:
        flag("CLEARANCE_PENDING", "REVIEW",
             "510(k) clearance is pending.",
             "POL-MED-001 §2 - product-specific clearance must be evidenced")
    if insp == "consent decree":
        flag("CONSENT_DECREE", "BLOCKING",
             "Supplier is under a regulatory consent decree.",
             "CON-MED-001 §10 - buyer may suspend purchasing on material compliance concerns")
    elif insp == "warning letter":
        flag("WARNING_LETTER", "REVIEW",
             "Most recent inspection produced a warning letter.",
             "POL-MED-001 §6 - historical inspection outcomes are a quality signal")
    if fda == "certified - major findings":
        flag("FDA_MAJOR_FINDINGS", "REVIEW",
             "FDA certification carries major findings.",
             "POL-MED-001 §2 - regulatory evidence quality requires review")
    if iso == "certified - conditional":
        flag("ISO_CONDITIONAL", "REVIEW",
             "ISO 13485 certification is conditional.",
             "POL-MED-001 §2 - conditional certification requires procurement review")

    if rfq is not None:
        docs = _lc(rfq.get("_compliance_docs"))
        if docs and docs != "yes":
            flag("DOCS_INCOMPLETE", "REVIEW",
                 f"Compliance documentation provided with the quotation is '{rfq.get('_compliance_docs')}'.",
                 "POL-MED-001 §2 - applicable regulatory evidence must be provided")

    return round(_clamp(score), 2), {k: round(v, 1) for k, v in parts.items()}, flags


def resilience_subscore(sup: dict) -> tuple[float, dict[str, float]]:
    """Financial and service resilience (master prompt section 15)."""
    parts = {
        "credit_rating": _cat(sup.get("credit_rating"),
                              config.CREDIT_RATING_SCORE, 0.5) * 100.0,
        "liquidity": _lerp_score(sup.get("liquidity_ratio"), best=2.5, worst=0.6),
        "leverage": _lerp_score(sup.get("debt_to_equity"), best=0.3, worst=3.1),
        "revenue_growth": _lerp_score(sup.get("revenue_growth"), best=15.0, worst=-8.0),
        "capacity_headroom": _lerp_score(sup.get("capacity_utilization"),
                                         best=55.0, worst=96.0),
        "demand_headroom": _lerp_score(sup.get("demand_to_capacity"),
                                       best=20.0, worst=150.0),
        "alternate_suppliers": _lerp_score(sup.get("alternate_suppliers"),
                                           best=7.0, worst=0.0),
        "backup_facility": _cat(sup.get("backup_facility"),
                                config.BACKUP_FACILITY_SCORE, 0.5) * 100.0,
        "inventory_cover": _lerp_score(sup.get("finished_goods_inventory_days"),
                                       best=60.0, worst=10.0),
        "country_risk": _lerp_score(sup.get("country_risk"), best=5.0, worst=85.0),
    }
    weights = {"credit_rating": 0.16, "liquidity": 0.10, "leverage": 0.10,
               "revenue_growth": 0.06, "capacity_headroom": 0.12,
               "demand_headroom": 0.12, "alternate_suppliers": 0.08,
               "backup_facility": 0.08, "inventory_cover": 0.08,
               "country_risk": 0.10}
    score = sum(parts[k] * weights[k] for k in parts)
    return round(_clamp(score), 2), {k: round(v, 1) for k, v in parts.items()}


def delivery_subscore(sup: dict, quote: dict, rfq: dict
                      ) -> tuple[float, dict[str, float], list[dict]]:
    """Delivery performance (policy section 5, master prompt section 17).

    Blends the quoted lead time against the RFQ requirement with the supplier's
    historical delivery reliability, lead-time variability and transit history.
    """
    required = float(rfq.get("required_delivery_days") or 0) or 1.0
    quoted = float(quote.get("quoted_delivery_days") or 0) or required
    ratio = quoted / required

    # 100 at <=70% of the required window, 0 at >=180% of it.
    quoted_vs_required = _lerp_score(ratio, best=0.70, worst=1.80)

    parts = {
        "quoted_vs_required": quoted_vs_required,
        "on_time_delivery": _lerp_score(sup.get("on_time_delivery"), best=98.0, worst=55.0),
        "lead_time_variability": _lerp_score(sup.get("lead_time_variability"),
                                             best=1.0, worst=25.0),
        "transit_variability": _lerp_score(sup.get("transit_time_variability"),
                                           best=0.0, worst=14.0),
        "route_on_time": _lerp_score(sup.get("route_on_time_delivery"),
                                     best=98.0, worst=55.0),
    }
    weights = {"quoted_vs_required": 0.40, "on_time_delivery": 0.24,
               "lead_time_variability": 0.16, "transit_variability": 0.10,
               "route_on_time": 0.10}
    score = sum(parts[k] * weights[k] for k in parts)

    flags: list[dict] = []
    if quoted > required:
        sev = "REVIEW" if ratio > 1.25 else "INFO"
        flags.append({
            "code": "DELIVERY_EXCEEDS_RFQ", "severity": sev,
            "message": (f"Quoted {int(quoted)} days against an RFQ requirement of "
                        f"{int(required)} days ({ratio:.0%} of the window)."),
            "clause": "POL-MED-001 §5 - RFQ-required delivery days are the maximum preferred target",
        })
    if (sup.get("lead_time_variability") or 0) >= 15:
        flags.append({
            "code": "HIGH_LEAD_TIME_VARIABILITY", "severity": "INFO",
            "message": f"Lead-time variability of {sup.get('lead_time_variability'):.0f} days.",
            "clause": "POL-MED-001 §5 - high lead-time variability should reduce the delivery score",
        })
    return round(_clamp(score), 2), {k: round(v, 1) for k, v in parts.items()}, flags


def warranty_sla_flags(quote: dict, rfq: dict) -> list[dict]:
    """Contractual warranty / SLA conformance (contract sections 5 and 6)."""
    flags: list[dict] = []
    req_w = rfq.get("warranty_months") or 0
    got_w = quote.get("warranty_months") or 0
    if got_w < req_w:
        flags.append({
            "code": "WARRANTY_SHORTFALL", "severity": "REVIEW",
            "message": f"Quoted warranty {got_w} months is below the RFQ requirement of {req_w} months.",
            "clause": "CON-MED-001 §5 - default warranty expectation is 24 months; critical equipment may require 36",
        })
    req_s = rfq.get("service_sla_hours") or 0
    got_s = quote.get("service_sla_hours") or 0
    if req_s and got_s > req_s:
        flags.append({
            "code": "SLA_SHORTFALL", "severity": "REVIEW",
            "message": f"Quoted service response {got_s}h is slower than the RFQ SLA of {req_s}h.",
            "clause": "CON-MED-001 §6 - service acknowledgement within 12h for critical equipment, otherwise 24h",
        })
    return flags


def data_completeness(sup: dict) -> float:
    """Fraction (0-1) of ML feature inputs that are populated for a supplier."""
    raw_cols = [
        "on_time_delivery", "lead_time_variability", "order_fulfillment_accuracy",
        "field_failure_rate", "batch_rejection_rate", "complaint_rate",
        "warranty_claim_rate", "mtbf_hours", "recalls_3y", "last_inspection_outcome",
        "regulatory_compliance_raw", "historical_performance_raw",
        "capacity_utilization", "demand_to_capacity", "country_risk",
        "transit_time_variability", "payment_history", "credit_rating",
        "debt_to_equity", "liquidity_ratio", "alternate_suppliers",
        "backup_facility", "finished_goods_inventory_days", "fda_status",
        "ce_status", "iso_13485_status", "clearance_510k_status",
    ]
    present = sum(1 for c in raw_cols
                  if sup.get(c) is not None and str(sup.get(c)).strip() != "")
    return present / len(raw_cols)
