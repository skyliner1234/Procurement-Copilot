"""CSV -> SQLite ingestion.

Maps the supplied medical-equipment dataset onto the normalised schema in db.py.
Idempotent: re-running rebuilds the master tables without touching the
transactional tables (approvals / audit_events).
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
from typing import Any

from . import config, db

# ---------------------------------------------------------------- helpers


def _num(value: Any, default: float | None = None) -> float | None:
    if value is None:
        return default
    s = str(value).strip().replace(",", "")
    if s == "" or s.lower() in {"na", "n/a", "none", "null"}:
        return default
    try:
        return float(s)
    except ValueError:
        return default


def _int(value: Any, default: int | None = None) -> int | None:
    n = _num(value, None)
    return int(round(n)) if n is not None else default


def _txt(value: Any, default: str = "") -> str:
    return default if value is None else str(value).strip()


def _read_csv(path) -> list[dict[str, str]]:
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------- column maps

SUPPLIER_MAP = {
    "supplier_id": ("Supplier ID", _txt),
    "supplier_name": ("Supplier Name", _txt),
    "contact_name": ("Supplier Contact Name", _txt),
    "contact_email": ("Supplier Contact Email", _txt),
    "contact_phone": ("Supplier Contact Phone", _txt),
    "primary_product_category": ("Primary Product Category", _txt),
    "fda_status": ("FDA Certification Status", _txt),
    "ce_status": ("CE Marking Status", _txt),
    "iso_13485_status": ("ISO 13485 Certification", _txt),
    "clearance_510k_status": ("510(k) Clearance Status", _txt),
    "recalls_3y": ("Recalls Past 3 Years", _int),
    "adverse_events": ("Adverse Event Reports Filed", _int),
    "months_since_inspection": ("Months Since Last Inspection", _int),
    "last_inspection_outcome": ("Last Inspection Outcome", _txt),
    "batch_rejection_rate": ("Batch Rejection Rate (%)", _num),
    "complaint_rate": ("Complaint Rate per 1000 Units", _num),
    "capa_frequency": ("CAPA Frequency (per year)", _num),
    "field_failure_rate": ("Field Failure Rate (%)", _num),
    "mtbf_hours": ("Mean Time Between Failures (hrs)", _num),
    "warranty_claim_rate": ("Warranty Claim Rate (%)", _num),
    "credit_rating": ("Credit Rating", _txt),
    "revenue_growth": ("Revenue Growth Trend (%)", _num),
    "debt_to_equity": ("Debt-to-Equity Ratio", _num),
    "liquidity_ratio": ("Liquidity Ratio", _num),
    "payment_history": ("Payment History Score (0-100)", _num),
    "on_time_delivery": ("On-Time Delivery (%)", _num),
    "lead_time_variability": ("Lead Time Variability (days)", _num),
    "order_fulfillment_accuracy": ("Order Fulfillment Accuracy (%)", _num),
    "capacity_utilization": ("Capacity Utilization (%)", _num),
    "country_risk": ("Country Risk Score (0-100)", _num),
    "alternate_suppliers": ("Alternate Suppliers Available", _int),
    "manufacturing_sites": ("Number of Manufacturing Sites", _int),
    "production_capacity": ("Production Capacity (units/month)", _num),
    "demand_to_capacity": ("Demand-to-Capacity Ratio (%)", _num),
    "finished_goods_inventory_days": ("Finished Goods Inventory (days)", _num),
    "backup_facility": ("Backup Facility Availability", _txt),
    "distance_km": ("Distance to Buyer (km)", _num),
    "transit_time_days": ("Historical Transit Time (days)", _num),
    "transit_time_variability": ("Transit Time Variability (days)", _num),
    "route_on_time_delivery": ("Route On-Time Delivery (%)", _num),
    "historical_performance_raw": ("Historical Performance Score (0-100)", _num),
    "regulatory_compliance_raw": ("Regulatory Compliance Score (0-100)", _num),
    "synthetic_disruption_probability": ("Synthetic Disruption Probability", _num),
    "historical_disruption_label": ("Historical Disruption Label", _int),
}

RFQ_MAP = {
    "rfq_id": ("RFQ ID", _txt),
    "buyer_id": ("Buyer ID", _txt),
    "equipment": ("Equipment", _txt),
    "clinical_use": ("Clinical Use", _txt),
    "quantity": ("Quantity", _int),
    "budget_per_unit": ("Budget per Unit (INR)", _num),
    "required_delivery_days": ("Required Delivery Days", _int),
    "required_certifications": ("Required Certifications", _txt),
    "warranty_months": ("Warranty Requirement (months)", _int),
    "service_sla_hours": ("Service Response SLA (hours)", _int),
    "issue_date": ("Issue Date", _txt),
    "status": ("Status", _txt),
}

QUOTE_MAP = {
    "rfq_id": ("RFQ ID", _txt),
    "supplier_id": ("Supplier ID", _txt),
    "supplier_name": ("Supplier Name", _txt),
    "quoted_unit_price": ("Quoted Unit Price (INR)", _num),
    "quoted_delivery_days": ("Quoted Delivery Days", _int),
    "warranty_months": ("Warranty (months)", _int),
    "service_sla_hours": ("Service SLA (hours)", _int),
    "validity_days": ("Quotation Validity (days)", _int),
    "compliance_docs": ("Compliance Documents Provided", _txt),
}

BUYER_MAP = {
    "buyer_id": ("Buyer ID", _txt),
    "buyer_name": ("Buyer Name", _txt),
    "contact_name": ("Buyer Contact", _txt),
    "contact_email": ("Buyer Contact Email", _txt),
    "industry": ("Industry", _txt),
    "country": ("Country", _txt),
    "procurement_policy_id": ("Procurement Policy ID", _txt),
    "buyer_contract_id": ("Buyer Contract ID", _txt),
}


def _project(row: dict, mapping: dict) -> dict:
    return {k: fn(row.get(src)) for k, (src, fn) in mapping.items()}


def _insert(conn, table: str, rows: list[dict]) -> int:
    if not rows:
        return 0
    cols = list(rows[0].keys())
    sql = (f"INSERT OR REPLACE INTO {table} ({','.join(cols)}) "
           f"VALUES ({','.join('?' for _ in cols)})")
    conn.executemany(sql, [tuple(r[c] for c in cols) for r in rows])
    return len(rows)


# ---------------------------------------------------------------- entrypoint


def ingest_all(verbose: bool = True) -> dict[str, int]:
    """Load every CSV into SQLite.  Returns row counts per table."""
    counts: dict[str, int] = {}
    with db.session() as conn:
        db.init_schema(conn)

        buyers = [_project(r, BUYER_MAP) for r in _read_csv(config.BUYER_CSV)]
        counts["buyers"] = _insert(conn, "buyers", buyers)

        suppliers = [_project(r, SUPPLIER_MAP) for r in _read_csv(config.SUPPLIER_CSV)]
        counts["suppliers"] = _insert(conn, "suppliers", suppliers)

        rfqs = [_project(r, RFQ_MAP) for r in _read_csv(config.RFQ_CSV)]
        counts["rfqs"] = _insert(conn, "rfqs", rfqs)

        # Quotes are fully rebuilt so the autoincrement ids stay stable.
        conn.execute("DELETE FROM rfq_quotes")
        quotes = [_project(r, QUOTE_MAP) for r in _read_csv(config.QUOTES_CSV)]
        known = {s["supplier_id"] for s in suppliers}
        quotes = [q for q in quotes if q["supplier_id"] in known]
        counts["rfq_quotes"] = _insert(conn, "rfq_quotes", quotes)

    if verbose:
        for k, v in counts.items():
            print(f"  ingested {v:>4} rows -> {k}")
    return counts


def integrity_report() -> dict:
    """Sanity checks used by the test-suite and the build script."""
    with db.session() as conn:
        db.init_schema(conn)
        n = lambda t: db.query_one(conn, f"SELECT COUNT(*) c FROM {t}")["c"]
        orphan_quotes = db.query_one(conn, """
            SELECT COUNT(*) c FROM rfq_quotes q
            LEFT JOIN suppliers s ON s.supplier_id = q.supplier_id
            WHERE s.supplier_id IS NULL""")["c"]
        rfqs_without_quotes = db.query_one(conn, """
            SELECT COUNT(*) c FROM rfqs r
            LEFT JOIN rfq_quotes q ON q.rfq_id = r.rfq_id
            WHERE q.rfq_id IS NULL""")["c"]
        tables = {r["name"] for r in db.query(
            conn, "SELECT name FROM sqlite_master WHERE type='table'")}
        return {
            "buyers": n("buyers"),
            "suppliers": n("suppliers"),
            "rfqs": n("rfqs"),
            "rfq_quotes": n("rfq_quotes"),
            "orphan_quotes": orphan_quotes,
            "rfqs_without_quotes": rfqs_without_quotes,
            "supplier_contracts_table_present": "supplier_contracts" in tables,
        }


if __name__ == "__main__":
    ingest_all()
    print(integrity_report())
