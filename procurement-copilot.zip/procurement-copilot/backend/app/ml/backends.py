"""Model-backend selection.

Preference order for every candidate algorithm:

1. scikit-learn / XGBoost, when importable  (primary path)
2. the NumPy reference implementations in numpy_models.py  (fallback)

Whichever backend is used is recorded in the evaluation report so results are
never presented ambiguously.
"""
from __future__ import annotations

import numpy as np

from .. import config
from . import numpy_models as npm

try:                                        # pragma: no cover - env dependent
    from sklearn.linear_model import LogisticRegression as _SkLR
    from sklearn.ensemble import RandomForestClassifier as _SkRF
    from sklearn.pipeline import Pipeline as _SkPipeline
    from sklearn.preprocessing import StandardScaler as _SkScaler
    HAVE_SKLEARN = True
except Exception:                           # pragma: no cover
    HAVE_SKLEARN = False

try:                                        # pragma: no cover - env dependent
    from xgboost import XGBClassifier as _XGB
    HAVE_XGBOOST = True
except Exception:                           # pragma: no cover
    HAVE_XGBOOST = False


class _SkWrapper:
    """Adapt a scikit-learn estimator to the fit/predict_proba API used here."""

    def __init__(self, name: str, estimator, backend: str):
        self.name = name
        self.est = estimator
        self.backend = backend

    def fit(self, X, y):
        self.est.fit(np.asarray(X, dtype=float), np.asarray(y, dtype=int))
        return self

    def predict_proba(self, X):
        return self.est.predict_proba(np.asarray(X, dtype=float))[:, 1]

    def get_params(self) -> dict:
        try:
            return {k: v for k, v in self.est.get_params().items()
                    if isinstance(v, (int, float, str, bool, type(None)))}
        except Exception:
            return {}


def _pos_weight(y) -> float:
    y = np.asarray(y, dtype=float)
    pos = max(y.sum(), 1.0)
    return float((len(y) - pos) / pos)


def build_candidates(seed: int = config.RANDOM_SEED, y=None) -> dict[str, object]:
    """Return {model_key: fresh untrained model} for the three candidates."""
    spw = _pos_weight(y) if y is not None else 1.0
    out: dict[str, object] = {}

    if HAVE_SKLEARN:
        out["logistic_regression"] = _SkWrapper(
            "Logistic Regression",
            _SkPipeline([("scale", _SkScaler()),
                         ("clf", _SkLR(C=1.0, max_iter=5000,
                                       class_weight="balanced",
                                       random_state=seed))]),
            "scikit-learn")
        out["random_forest"] = _SkWrapper(
            "Random Forest",
            _SkRF(n_estimators=300, max_depth=6, min_samples_leaf=2,
                  max_features="sqrt", class_weight="balanced_subsample",
                  random_state=seed, n_jobs=-1),
            "scikit-learn")
    else:
        out["logistic_regression"] = npm.LogisticRegressionNP(seed=seed)
        out["random_forest"] = npm.RandomForestNP(seed=seed)

    if HAVE_XGBOOST:
        out["xgboost"] = _SkWrapper(
            "XGBoost",
            _XGB(n_estimators=200, learning_rate=0.08, max_depth=3,
                 reg_lambda=1.5, subsample=0.9, colsample_bytree=0.8,
                 scale_pos_weight=spw, eval_metric="logloss",
                 random_state=seed, n_jobs=-1, tree_method="hist"),
            "xgboost")
    else:
        out["xgboost"] = npm.GradientBoostingNP(seed=seed)

    return out


def backend_of(model) -> str:
    return getattr(model, "backend", "numpy-reference")


def backend_report() -> dict:
    return {
        "sklearn_available": HAVE_SKLEARN,
        "xgboost_available": HAVE_XGBOOST,
        "note": ("Primary backend is scikit-learn / XGBoost. When those packages "
                 "are unavailable the equivalent NumPy reference implementations "
                 "in backend/app/ml/numpy_models.py are used instead, and this "
                 "flag records which path produced the reported metrics."),
    }
