"""Feature-level explainability for the selected risk model.

Primary path: the `shap` package (TreeExplainer for tree models, LinearExplainer
for the logistic baseline).

Fallback path: Shapley values estimated by permutation sampling
(Strumbelj & Kononenko, 2014, "Explaining prediction models and individual
predictions with feature contributions").  This is the same value function SHAP
approximates - the sampling estimator converges to the exact Shapley values -
so the explanation semantics are unchanged when `shap` is not installed.

Both paths yield, per supplier: signed contributions per feature in probability
space, summing to (prediction - baseline).
"""
from __future__ import annotations

import numpy as np

from .. import config

try:                                        # pragma: no cover - env dependent
    import shap as _shap
    HAVE_SHAP = True
except Exception:                           # pragma: no cover
    HAVE_SHAP = False


def permutation_shapley(predict_fn, x: np.ndarray, background: np.ndarray,
                        n_permutations: int = 200, seed: int = 42,
                        batch: int = 40) -> np.ndarray:
    """Estimate Shapley values for one instance by permutation sampling.

    For each random feature ordering, features are progressively switched from a
    random background row to the instance's own value; the marginal change in the
    prediction is that feature's contribution for that ordering.  Averaging over
    orderings gives the Shapley value.

    All (d + 1) intermediate rows of a permutation - and several permutations at
    a time - are scored in a single vectorised call, which is what makes this
    tractable for an ensemble model.
    """
    rng = np.random.default_rng(seed)
    d = len(x)
    n_bg = len(background)
    phi = np.zeros(d)

    done = 0
    while done < n_permutations:
        k = min(batch, n_permutations - done)
        orders = np.array([rng.permutation(d) for _ in range(k)])
        refs = background[rng.integers(0, n_bg, size=k)].copy()

        # rows[p, s] = background row p with the first s features of order p
        # replaced by the instance's values.  Shape (k, d+1, d).
        rows = np.repeat(refs[:, None, :], d + 1, axis=1)
        for p in range(k):
            cur = refs[p].copy()
            for s, f in enumerate(orders[p]):
                cur[f] = x[f]
                rows[p, s + 1] = cur
        preds = np.asarray(predict_fn(rows.reshape(-1, d)), dtype=float
                           ).reshape(k, d + 1)
        deltas = np.diff(preds, axis=1)             # (k, d) marginal effects
        for p in range(k):
            np.add.at(phi, orders[p], deltas[p])
        done += k
    return phi / n_permutations


def _shap_values(model, X: np.ndarray, background: np.ndarray) -> np.ndarray | None:
    """Try the real shap package; return None if it is unavailable/unsuitable."""
    if not HAVE_SHAP:
        return None
    try:                                     # pragma: no cover - env dependent
        inner = getattr(model, "est", model)
        est = getattr(inner, "steps", [(None, inner)])[-1][1] if hasattr(inner, "steps") else inner
        explainer = _shap.Explainer(
            lambda d: model.predict_proba(d), background, seed=config.RANDOM_SEED)
        vals = explainer(X).values
        return np.asarray(vals, dtype=float)
    except Exception:
        return None


def explain_all(model, X: np.ndarray, feature_names: list[str],
                n_permutations: int = 200, seed: int = config.RANDOM_SEED
                ) -> tuple[np.ndarray, float, str]:
    """Return (contributions [n x d], baseline probability, method label)."""
    X = np.asarray(X, dtype=float)
    background = X                              # full training distribution
    baseline = float(np.mean(model.predict_proba(background)))

    vals = _shap_values(model, X, background)
    if vals is not None and vals.shape == X.shape:
        return vals, baseline, "shap"

    out = np.zeros_like(X)
    for i in range(len(X)):
        out[i] = permutation_shapley(model.predict_proba, X[i], background,
                                     n_permutations, seed + i)
    return out, baseline, "permutation-shapley"


def top_drivers(contributions: np.ndarray, values: np.ndarray,
                feature_names: list[str], k: int = 6) -> list[dict]:
    """Human-readable top-k drivers for a single supplier, highest |phi| first."""
    order = np.argsort(-np.abs(contributions))[:k]
    out = []
    for i in order:
        name = feature_names[i]
        phi = float(contributions[i])
        out.append({
            "feature": name,
            "label": config.ML_FEATURE_LABELS.get(name, name),
            "value": round(float(values[i]), 2),
            "contribution": round(phi, 4),
            "contribution_pp": round(phi * 100.0, 2),   # percentage points of risk
            "direction": "increases risk" if phi > 0 else "reduces risk",
        })
    return out


def global_importance(contributions: np.ndarray, feature_names: list[str]
                      ) -> list[dict]:
    """Mean |Shapley value| per feature - the standard global importance view."""
    mean_abs = np.abs(contributions).mean(axis=0)
    order = np.argsort(-mean_abs)
    return [{
        "feature": feature_names[i],
        "label": config.ML_FEATURE_LABELS.get(feature_names[i], feature_names[i]),
        "mean_abs_contribution": round(float(mean_abs[i]), 5),
        "mean_abs_pp": round(float(mean_abs[i]) * 100.0, 3),
    } for i in order]
