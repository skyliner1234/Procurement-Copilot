"""Dependency-light reference implementations of the three candidate models.

Why these exist
---------------
The primary training path uses scikit-learn and XGBoost (see backends.py).  These
NumPy implementations are the fallback that keeps the demo runnable on a machine
where those wheels cannot be installed, and they let the whole pipeline be
unit-tested without heavyweight dependencies.

They implement the same algorithms, not approximations of them:

* `LogisticRegressionNP`  - L2-regularised logistic regression, full-batch
  gradient descent with standardised inputs.
* `RandomForestNP`        - bagged CART classification trees with per-split
  random feature subsampling (Breiman 2001).
* `GradientBoostingNP`    - second-order gradient boosting on logistic loss with
  shrinkage, row/column subsampling and L2 leaf regularisation, i.e. the
  algorithm XGBoost implements (Chen & Guestrin 2016).

Every model exposes fit / predict_proba / get_params, so the evaluation and
explanation code is backend-agnostic.
"""
from __future__ import annotations

import numpy as np


def _sigmoid(z: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(z, -35.0, 35.0)))


# ---------------------------------------------------------------------------
# Logistic regression (baseline)
# ---------------------------------------------------------------------------
class LogisticRegressionNP:
    name = "Logistic Regression"

    def __init__(self, l2: float = 1.0, lr: float = 0.5, epochs: int = 4000,
                 seed: int = 42):
        self.l2, self.lr, self.epochs, self.seed = l2, lr, epochs, seed
        self.mu_ = self.sigma_ = self.w_ = None
        self.b_ = 0.0

    def get_params(self) -> dict:
        return {"l2": self.l2, "lr": self.lr, "epochs": self.epochs}

    def _scale(self, X: np.ndarray) -> np.ndarray:
        return (X - self.mu_) / self.sigma_

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        self.mu_ = X.mean(axis=0)
        self.sigma_ = X.std(axis=0)
        self.sigma_[self.sigma_ < 1e-9] = 1.0
        Xs = self._scale(X)
        n, d = Xs.shape
        self.w_ = np.zeros(d)
        self.b_ = 0.0
        # class weighting keeps the minority (disruption) class visible
        pos = max(y.sum(), 1.0)
        neg = max(n - y.sum(), 1.0)
        w_pos, w_neg = n / (2.0 * pos), n / (2.0 * neg)
        sw = np.where(y > 0.5, w_pos, w_neg)
        for _ in range(self.epochs):
            p = _sigmoid(Xs @ self.w_ + self.b_)
            err = (p - y) * sw
            gw = Xs.T @ err / n + self.l2 * self.w_ / n
            gb = err.mean()
            self.w_ -= self.lr * gw
            self.b_ -= self.lr * gb
        return self

    def predict_proba(self, X) -> np.ndarray:
        Xs = self._scale(np.asarray(X, dtype=float))
        return _sigmoid(Xs @ self.w_ + self.b_)

    def coefficients(self) -> np.ndarray:
        """Standardised coefficients - directly interpretable as effect sizes."""
        return self.w_.copy()


# ---------------------------------------------------------------------------
# CART building block
# ---------------------------------------------------------------------------
class _Node:
    __slots__ = ("feat", "thr", "left", "right", "value")

    def __init__(self, feat=None, thr=None, left=None, right=None, value=None):
        self.feat, self.thr, self.left, self.right, self.value = feat, thr, left, right, value

    @property
    def is_leaf(self) -> bool:
        return self.value is not None


def _gini(y: np.ndarray, w: np.ndarray) -> float:
    tot = w.sum()
    if tot <= 0:
        return 0.0
    p = (w * y).sum() / tot
    return 2.0 * p * (1.0 - p)


def _predict_tree(node: "_Node", X: np.ndarray) -> np.ndarray:
    """Vectorised tree traversal: one pass per node instead of per row."""
    out = np.empty(len(X), dtype=float)
    stack = [(node, np.arange(len(X)))]
    while stack:
        nd, idx = stack.pop()
        if len(idx) == 0:
            continue
        if nd.is_leaf:
            out[idx] = nd.value
            continue
        go_left = X[idx, nd.feat] <= nd.thr
        stack.append((nd.left, idx[go_left]))
        stack.append((nd.right, idx[~go_left]))
    return out


class _ClassificationTree:
    def __init__(self, max_depth=6, min_samples_leaf=2, max_features=None, rng=None):
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_features = max_features
        self.rng = rng or np.random.default_rng(0)
        self.root = None

    def fit(self, X, y, w):
        self.root = self._grow(X, y, w, depth=0)
        return self

    def _leaf(self, y, w):
        tot = w.sum()
        p = (w * y).sum() / tot if tot > 0 else 0.0
        return _Node(value=float(np.clip(p, 1e-6, 1 - 1e-6)))

    def _grow(self, X, y, w, depth):
        n, d = X.shape
        if depth >= self.max_depth or n < 2 * self.min_samples_leaf or len(np.unique(y)) == 1:
            return self._leaf(y, w)
        k = self.max_features or d
        feats = self.rng.choice(d, size=min(k, d), replace=False)
        parent = _gini(y, w) * w.sum()
        msl = self.min_samples_leaf
        best = (None, None, 0.0)
        for f in feats:
            col = X[:, f]
            order = np.argsort(col, kind="mergesort")
            cs, ys, ws = col[order], y[order], w[order]
            # Weighted Gini for every candidate split, computed in one pass:
            #   weighted_gini(side) * W(side) = 2 * SWY * (W - SWY) / W
            wl = np.cumsum(ws)[:-1]
            swyl = np.cumsum(ws * ys)[:-1]
            wr = ws.sum() - wl
            swyr = (ws * ys).sum() - swyl
            with np.errstate(divide="ignore", invalid="ignore"):
                cost = (np.where(wl > 0, 2.0 * swyl * (wl - swyl) / wl, 0.0)
                        + np.where(wr > 0, 2.0 * swyr * (wr - swyr) / wr, 0.0))
            gains = parent - cost
            pos = np.arange(1, n)
            valid = (cs[1:] != cs[:-1]) & (pos >= msl) & (n - pos >= msl)
            if not valid.any():
                continue
            gains = np.where(valid, gains, -np.inf)
            i = int(np.argmax(gains))
            if gains[i] > best[2] + 1e-12:
                best = (int(f), float((cs[i] + cs[i + 1]) / 2.0), float(gains[i]))
        if best[0] is None:
            return self._leaf(y, w)
        f, thr, _ = best
        m = X[:, f] <= thr
        if m.sum() < self.min_samples_leaf or (~m).sum() < self.min_samples_leaf:
            return self._leaf(y, w)
        return _Node(feat=f, thr=thr,
                     left=self._grow(X[m], y[m], w[m], depth + 1),
                     right=self._grow(X[~m], y[~m], w[~m], depth + 1))

    def predict_proba(self, X) -> np.ndarray:
        return _predict_tree(self.root, np.asarray(X, dtype=float))


class RandomForestNP:
    name = "Random Forest"

    def __init__(self, n_estimators=200, max_depth=6, min_samples_leaf=2,
                 max_features="sqrt", seed=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_features = max_features
        self.seed = seed
        self.trees: list[_ClassificationTree] = []

    def get_params(self) -> dict:
        return {"n_estimators": self.n_estimators, "max_depth": self.max_depth,
                "min_samples_leaf": self.min_samples_leaf,
                "max_features": self.max_features}

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        n, d = X.shape
        mf = int(np.sqrt(d)) if self.max_features == "sqrt" else (self.max_features or d)
        mf = max(1, min(mf, d))
        pos, neg = max(y.sum(), 1.0), max(n - y.sum(), 1.0)
        base_w = np.where(y > 0.5, n / (2 * pos), n / (2 * neg))
        rng = np.random.default_rng(self.seed)
        self.trees = []
        for t in range(self.n_estimators):
            idx = rng.integers(0, n, n)                      # bootstrap sample
            tree = _ClassificationTree(self.max_depth, self.min_samples_leaf, mf,
                                       np.random.default_rng(self.seed + t))
            tree.fit(X[idx], y[idx], base_w[idx])
            self.trees.append(tree)
        return self

    def predict_proba(self, X) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        return np.mean([t.predict_proba(X) for t in self.trees], axis=0)


# ---------------------------------------------------------------------------
# Gradient boosting (the XGBoost algorithm)
# ---------------------------------------------------------------------------
class _RegressionTree:
    """Second-order boosting tree: leaf value = -G / (H + lambda)."""

    def __init__(self, max_depth=3, min_child_weight=1.0, reg_lambda=1.0,
                 gamma=0.0, colsample=1.0, rng=None):
        self.max_depth = max_depth
        self.min_child_weight = min_child_weight
        self.reg_lambda = reg_lambda
        self.gamma = gamma
        self.colsample = colsample
        self.rng = rng or np.random.default_rng(0)
        self.root = None

    def _leaf_value(self, g, h):
        return float(-g.sum() / (h.sum() + self.reg_lambda))

    def _score(self, g, h):
        return float(g.sum() ** 2 / (h.sum() + self.reg_lambda))

    def fit(self, X, g, h):
        self.root = self._grow(X, g, h, 0)
        return self

    def _grow(self, X, g, h, depth):
        if depth >= self.max_depth or len(g) < 2 or h.sum() < 2 * self.min_child_weight:
            return _Node(value=self._leaf_value(g, h))
        d = X.shape[1]
        k = max(1, int(round(self.colsample * d)))
        feats = self.rng.choice(d, size=k, replace=False)
        parent = self._score(g, h)
        best = (None, None, 0.0)
        for f in feats:
            order = np.argsort(X[:, f], kind="mergesort")
            cs, gs, hs = X[order, f], g[order], h[order]
            gl = np.cumsum(gs)[:-1]
            hl = np.cumsum(hs)[:-1]
            gr = gs.sum() - gl
            hr = hs.sum() - hl
            valid = (cs[1:] != cs[:-1]) & (hl >= self.min_child_weight) & (hr >= self.min_child_weight)
            if not valid.any():
                continue
            gain = (gl ** 2 / (hl + self.reg_lambda)
                    + gr ** 2 / (hr + self.reg_lambda) - parent) / 2.0 - self.gamma
            gain = np.where(valid, gain, -np.inf)
            i = int(np.argmax(gain))
            if gain[i] > best[2] + 1e-12:
                best = (int(f), float((cs[i] + cs[i + 1]) / 2.0), float(gain[i]))
        if best[0] is None:
            return _Node(value=self._leaf_value(g, h))
        f, thr, _ = best
        m = X[:, f] <= thr
        return _Node(feat=f, thr=thr,
                     left=self._grow(X[m], g[m], h[m], depth + 1),
                     right=self._grow(X[~m], g[~m], h[~m], depth + 1))

    def predict(self, X) -> np.ndarray:
        return _predict_tree(self.root, np.asarray(X, dtype=float))


class GradientBoostingNP:
    name = "XGBoost (gradient boosting)"

    def __init__(self, n_estimators=200, learning_rate=0.08, max_depth=3,
                 reg_lambda=1.5, gamma=0.0, subsample=0.9, colsample=0.8,
                 min_child_weight=1.0, seed=42):
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.max_depth = max_depth
        self.reg_lambda = reg_lambda
        self.gamma = gamma
        self.subsample = subsample
        self.colsample = colsample
        self.min_child_weight = min_child_weight
        self.seed = seed
        self.trees: list[_RegressionTree] = []
        self.base_ = 0.0

    def get_params(self) -> dict:
        return {"n_estimators": self.n_estimators, "learning_rate": self.learning_rate,
                "max_depth": self.max_depth, "reg_lambda": self.reg_lambda,
                "subsample": self.subsample, "colsample": self.colsample}

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        n = len(y)
        p0 = float(np.clip(y.mean(), 1e-4, 1 - 1e-4))
        self.base_ = float(np.log(p0 / (1 - p0)))
        f = np.full(n, self.base_)
        pos, neg = max(y.sum(), 1.0), max(n - y.sum(), 1.0)
        sw = np.where(y > 0.5, n / (2 * pos), n / (2 * neg))
        rng = np.random.default_rng(self.seed)
        self.trees = []
        for t in range(self.n_estimators):
            p = _sigmoid(f)
            g = (p - y) * sw
            h = np.maximum(p * (1 - p) * sw, 1e-6)
            rows = rng.random(n) < self.subsample
            if rows.sum() < 4:
                rows = np.ones(n, dtype=bool)
            tree = _RegressionTree(self.max_depth, self.min_child_weight,
                                   self.reg_lambda, self.gamma, self.colsample,
                                   np.random.default_rng(self.seed + t))
            tree.fit(X[rows], g[rows], h[rows])
            f += self.learning_rate * tree.predict(X)
            self.trees.append(tree)
        return self

    def decision_function(self, X) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        f = np.full(len(X), self.base_)
        for tree in self.trees:
            f += self.learning_rate * tree.predict(X)
        return f

    def predict_proba(self, X) -> np.ndarray:
        return _sigmoid(self.decision_function(X))
