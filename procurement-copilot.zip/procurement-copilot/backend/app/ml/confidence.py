"""Model confidence = strength and consistency of the evidence behind a prediction.

Confidence is explicitly NOT `100 - risk`.  A supplier can be confidently
high-risk (rich, consistent, unambiguous evidence) or unconfidently low-risk
(sparse data, a probability sitting near the decision boundary, models
disagreeing).  Those are different quantities and the dashboard shows both.

Five components, each 0-1, combined with the weights in config.CONFIDENCE_WEIGHTS:

1. data_completeness      - how much of the supplier's feature record is populated.
2. probability_certainty   - distance of p from the 0.5 decision boundary,
                             scaled so p=0.5 -> 0 and p in {0,1} -> 1.
3. model_agreement         - 1 - normalised spread of the three candidate models'
                             probabilities for this supplier (ensemble consensus).
4. history_consistency     - do the deterministic performance/quality/compliance
                             sub-scores tell the same story as the model?  Measured
                             as 1 - |model risk - evidence-implied risk|.
5. rfq_data_completeness   - completeness of the quotation/RFQ fields the decision
                             also depends on.
"""
from __future__ import annotations

import numpy as np

from .. import config


def _clip01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))


def probability_certainty(p: float) -> float:
    """0 at p = 0.5, 1 at p = 0 or 1."""
    return _clip01(abs(float(p) - 0.5) * 2.0)


def model_agreement(probs: list[float]) -> float:
    """1 - normalised dispersion across candidate models.

    Standard deviation of k probabilities is bounded by 0.5, so dividing by 0.5
    puts the disagreement term on a 0-1 scale.
    """
    arr = np.asarray([p for p in probs if p is not None], dtype=float)
    if len(arr) < 2:
        return 0.6                    # only one model available: neutral-ish
    return _clip01(1.0 - float(arr.std(ddof=0)) / 0.5)


def history_consistency(model_risk_0_1: float, evidence_risk_0_1: float) -> float:
    """Agreement between the learned model and the deterministic evidence view."""
    return _clip01(1.0 - abs(float(model_risk_0_1) - float(evidence_risk_0_1)))


def evidence_implied_risk(historical_score: float, quality_score: float,
                          compliance_score: float, resilience_score: float) -> float:
    """A rule-based risk view built only from the deterministic sub-scores.

    Used purely as an independent second opinion for the consistency check - it
    never feeds the ML model or the decision score.
    """
    blended = (0.40 * historical_score + 0.25 * quality_score
               + 0.20 * compliance_score + 0.15 * resilience_score)
    return _clip01(1.0 - blended / 100.0)


def rfq_data_completeness(quote: dict, rfq: dict) -> float:
    quote_fields = ["quoted_unit_price", "quoted_delivery_days", "warranty_months",
                    "service_sla_hours", "validity_days", "compliance_docs"]
    rfq_fields = ["quantity", "budget_per_unit", "required_delivery_days",
                  "required_certifications", "warranty_months", "service_sla_hours"]
    got = sum(1 for f in quote_fields
              if quote.get(f) is not None and str(quote.get(f)).strip() != "")
    got += sum(1 for f in rfq_fields
               if rfq.get(f) is not None and str(rfq.get(f)).strip() != "")
    return got / (len(quote_fields) + len(rfq_fields))


def compute(data_completeness: float, p_risk: float, candidate_probs: list[float],
            evidence_risk: float, rfq_completeness: float = 1.0
            ) -> tuple[float, dict]:
    """Return (confidence 0-100, per-component breakdown)."""
    comps = {
        "data_completeness": _clip01(data_completeness),
        "probability_certainty": probability_certainty(p_risk),
        "model_agreement": model_agreement(candidate_probs),
        "history_consistency": history_consistency(p_risk, evidence_risk),
        "rfq_data_completeness": _clip01(rfq_completeness),
    }
    w = config.CONFIDENCE_WEIGHTS
    score = sum(comps[k] * w[k] for k in w)
    breakdown = {
        k: {"value": round(comps[k] * 100.0, 1),
            "weight": w[k],
            "contribution": round(comps[k] * w[k] * 100.0, 1)}
        for k in w
    }
    return round(_clip01(score) * 100.0, 1), breakdown
