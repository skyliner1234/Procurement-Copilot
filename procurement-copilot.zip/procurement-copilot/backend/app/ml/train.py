"""Train, compare and select the supplier-disruption risk model, then write
per-supplier predictions, confidence and SHAP-style explanations into SQLite.

Selection rule (fixed before results are seen, so it cannot be reverse-engineered
to favour a preferred model):

    primary   : mean cross-validated ROC-AUC
    tie-break : mean F1, then lower Brier score (calibration)

XGBoost is NOT privileged.  Logistic regression is the declared baseline and
wins if it scores best.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import numpy as np

from .. import config, db, features
from . import backends, confidence, evaluate, explain

SELECTION_RULE = ("highest mean cross-validated ROC-AUC; ties broken on mean F1, "
                  "then on Brier score (lower is better)")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load_suppliers(conn) -> list[dict]:
    return db.query(conn, "SELECT * FROM suppliers ORDER BY supplier_id")


def train_and_predict(verbose: bool = True) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        suppliers = _load_suppliers(conn)

    if not suppliers:
        raise RuntimeError("No suppliers in the database - run ingestion first.")

    X, y, supplier_ids = features.feature_matrix(suppliers)
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    names = list(config.ML_FEATURES)

    # ---------------------------------------------------------- 1. compare
    if verbose:
        print(f"  dataset: n={len(y)} suppliers, {X.shape[1]} features, "
              f"{int(y.sum())} positive labels ({y.mean():.0%} prevalence)")

    comparison: dict[str, dict] = {}
    for key in ("logistic_regression", "random_forest", "xgboost"):
        factory = lambda k=key: backends.build_candidates(config.RANDOM_SEED, y)[k]
        probe = factory()
        res = evaluate.repeated_stratified_cv(
            factory, X, y, config.CV_FOLDS, config.CV_REPEATS, config.RANDOM_SEED)
        comparison[key] = {
            "display_name": getattr(probe, "name", key),
            "backend": backends.backend_of(probe),
            "hyperparameters": probe.get_params() if hasattr(probe, "get_params") else {},
            **res,
        }
        if verbose:
            m = res["metrics"]
            print(f"  {comparison[key]['display_name']:<28} "
                  f"AUC {m['roc_auc']['mean']:.3f}+/-{m['roc_auc']['std']:.3f}  "
                  f"F1 {m['f1']['mean']:.3f}  ACC {m['accuracy']['mean']:.3f}  "
                  f"Brier {m['brier']['mean']:.3f}")

    def rank_key(item):
        m = item[1]["metrics"]
        auc = m["roc_auc"]["mean"] if m["roc_auc"]["mean"] is not None else -1
        f1v = m["f1"]["mean"] if m["f1"]["mean"] is not None else -1
        br = m["brier"]["mean"] if m["brier"]["mean"] is not None else 1
        return (auc, f1v, -br)

    selected_key = max(comparison.items(), key=rank_key)[0]
    if verbose:
        print(f"  selected: {comparison[selected_key]['display_name']} "
              f"({SELECTION_RULE.split(';')[0]})")

    # ---------------------------------------------------------- 2. fit finals
    # The final models are fitted on all 50 suppliers - that is the artefact
    # that would score a *new* supplier.  But the risk shown for the 50
    # suppliers already in the training set is taken from the cross-validated
    # out-of-fold predictions, so no supplier is ever scored by a model that saw
    # its own label.  Reporting in-sample probabilities here would inflate the
    # apparent separation between suppliers.
    fitted = {}
    for key in comparison:
        m = backends.build_candidates(config.RANDOM_SEED, y)[key]
        m.fit(X, y)
        fitted[key] = m
    selected = fitted[selected_key]

    probs = {k: np.asarray(comparison[k]["oof_probabilities"], dtype=float)
             for k in comparison}
    p_sel = probs[selected_key]
    prediction_basis = "cross-validated out-of-fold probability (mean over repeats)"

    # ---------------------------------------------------------- 3. explain
    contributions, baseline, method = explain.explain_all(selected, X, names)
    global_imp = explain.global_importance(contributions, names)
    if verbose:
        print(f"  explainability: {method}; baseline P(disruption)={baseline:.3f}")
        print("  top global drivers: " + ", ".join(
            g["label"] for g in global_imp[:4]))

    # ---------------------------------------------------------- 4. persist
    rows = []
    for i, sup in enumerate(suppliers):
        sid = sup["supplier_id"]
        # Round the probability first, then derive the score from the rounded
        # value, so the two figures shown side by side on the dashboard can never
        # disagree in the last digit.
        p = round(float(p_sel[i]), 4)
        risk_score = round(p * 100.0, 1)
        level = config.risk_band(risk_score)

        hist, _ = features.historical_subscore(sup)
        qual, _ = features.quality_subscore(sup)
        comp, _, _ = features.compliance_subscore(sup)
        resl, _ = features.resilience_subscore(sup)
        ev_risk = confidence.evidence_implied_risk(hist, qual, comp, resl)

        conf, breakdown = confidence.compute(
            data_completeness=features.data_completeness(sup),
            p_risk=p,
            candidate_probs=[float(probs[k][i]) for k in probs],
            evidence_risk=ev_risk,
            rfq_completeness=1.0,
        )
        drivers = explain.top_drivers(contributions[i], X[i], names, k=6)
        rows.append((sid, p, risk_score, level, conf,
                     comparison[selected_key]["display_name"],
                     json.dumps(drivers), json.dumps(breakdown), _now()))

    with db.session() as conn:
        conn.executemany("""
            INSERT OR REPLACE INTO supplier_risk_predictions
              (supplier_id, risk_probability, risk_score, risk_level,
               model_confidence, model_name, top_drivers_json,
               confidence_breakdown_json, predicted_at)
            VALUES (?,?,?,?,?,?,?,?,?)""", rows)

    # ---------------------------------------------------------- 5. report
    dist = {}
    for r in rows:
        dist[r[3]] = dist.get(r[3], 0) + 1

    report = {
        "generated_at": _now(),
        "data_note": ("PROTOTYPE RESULT ON SYNTHETIC DATA. n=50 suppliers, "
                      f"{int(y.sum())} positive labels. Figures are illustrative of "
                      "the methodology, not of real-world supplier risk."),
        "target": ("Historical Disruption Label - a material supply-disruption or "
                   "late-delivery event attributed to the supplier."),
        "leakage_control": ("'Synthetic Disruption Probability' is the latent "
                            "generator parameter behind the label and is excluded "
                            "from the feature set."),
        "n_samples": int(len(y)),
        "n_features": int(X.shape[1]),
        "positive_rate": round(float(y.mean()), 4),
        "cv_design": f"{config.CV_FOLDS}-fold stratified x {config.CV_REPEATS} repeats",
        "selection_rule": SELECTION_RULE,
        "selected_model": selected_key,
        "selected_model_name": comparison[selected_key]["display_name"],
        "prediction_basis": prediction_basis,
        "compute_backend": backends.backend_report(),
        "explainability_method": method,
        "baseline_probability": round(float(baseline), 4),
        "models": comparison,
        "global_feature_importance": global_imp,
        "risk_distribution": dist,
        "limitations": [
            "Synthetic data: absolute metric values do not transfer to real suppliers.",
            "n=50 with 18 positive labels; confidence intervals on every metric are wide.",
            "Repeated stratified CV is used precisely because a single hold-out split "
            "at this sample size would be dominated by fold noise.",
            "The label is a single historical binary event, not a rate over time.",
        ],
    }
    # keep the artifact readable - OOF probability vectors are diagnostic only
    for k in report["models"]:
        report["models"][k].pop("oof_probabilities", None)

    with open(config.METRICS_ARTIFACT, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)

    model_card = {
        "selected_model": selected_key,
        "display_name": comparison[selected_key]["display_name"],
        "backend": comparison[selected_key]["backend"],
        "features": names,
        "baseline_probability": round(float(baseline), 4),
        "trained_at": _now(),
        "seed": config.RANDOM_SEED,
    }
    with open(config.MODEL_ARTIFACT, "w", encoding="utf-8") as fh:
        json.dump(model_card, fh, indent=2)

    if verbose:
        print(f"  risk distribution: {dist}")
        print(f"  wrote {config.METRICS_ARTIFACT.name}, {config.MODEL_ARTIFACT.name}")
    return report


if __name__ == "__main__":
    train_and_predict()
