"""Model evaluation: metrics and repeated stratified cross-validation.

n = 50 suppliers with 18 positive labels.  A single train/test split at that size
gives a test fold of ~10 rows, so a single accuracy number would be almost pure
noise.  Repeated stratified k-fold (5 folds x 10 repeats = 50 fits per model)
with out-of-fold pooling is used instead, and every metric is reported as
mean +/- standard deviation across repeats.  This is the honest way to compare
models on a dataset this small and it is what the selection decision uses.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------- metrics


def confusion(y_true, y_pred) -> tuple[int, int, int, int]:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    return tp, tn, fp, fn


def accuracy(y_true, y_pred) -> float:
    tp, tn, fp, fn = confusion(y_true, y_pred)
    total = tp + tn + fp + fn
    return tp + tn if total == 0 else (tp + tn) / total


def precision(y_true, y_pred) -> float:
    tp, _, fp, _ = confusion(y_true, y_pred)
    return 0.0 if tp + fp == 0 else tp / (tp + fp)


def recall(y_true, y_pred) -> float:
    tp, _, _, fn = confusion(y_true, y_pred)
    return 0.0 if tp + fn == 0 else tp / (tp + fn)


def f1(y_true, y_pred) -> float:
    p, r = precision(y_true, y_pred), recall(y_true, y_pred)
    return 0.0 if p + r == 0 else 2 * p * r / (p + r)


def roc_auc(y_true, y_prob) -> float:
    """AUC via the rank (Mann-Whitney U) formulation, ties handled correctly."""
    y_true = np.asarray(y_true, dtype=int)
    y_prob = np.asarray(y_prob, dtype=float)
    pos, neg = (y_true == 1).sum(), (y_true == 0).sum()
    if pos == 0 or neg == 0:
        return float("nan")
    order = np.argsort(y_prob, kind="mergesort")
    ranks = np.empty(len(y_prob), dtype=float)
    sorted_p = y_prob[order]
    i = 0
    while i < len(sorted_p):
        j = i
        while j + 1 < len(sorted_p) and sorted_p[j + 1] == sorted_p[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0
        i = j + 1
    return float((ranks[y_true == 1].sum() - pos * (pos + 1) / 2.0) / (pos * neg))


def brier(y_true, y_prob) -> float:
    y_true = np.asarray(y_true, dtype=float)
    y_prob = np.asarray(y_prob, dtype=float)
    return float(np.mean((y_prob - y_true) ** 2))


def all_metrics(y_true, y_prob, threshold: float = 0.5) -> dict[str, float]:
    y_pred = (np.asarray(y_prob) >= threshold).astype(int)
    return {
        "accuracy": round(float(accuracy(y_true, y_pred)), 4),
        "precision": round(float(precision(y_true, y_pred)), 4),
        "recall": round(float(recall(y_true, y_pred)), 4),
        "f1": round(float(f1(y_true, y_pred)), 4),
        "roc_auc": round(float(roc_auc(y_true, y_prob)), 4),
        "brier": round(float(brier(y_true, y_prob)), 4),
    }


# ---------------------------------------------------------------- CV


def stratified_folds(y, n_splits: int, seed: int) -> list[np.ndarray]:
    """Stratified fold assignment: class proportions preserved in every fold."""
    y = np.asarray(y, dtype=int)
    rng = np.random.default_rng(seed)
    fold_id = np.empty(len(y), dtype=int)
    for cls in np.unique(y):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)
        fold_id[idx] = np.arange(len(idx)) % n_splits
    return [np.where(fold_id == k)[0] for k in range(n_splits)]


def repeated_stratified_cv(model_factory, X, y, n_splits=5, n_repeats=10,
                           seed=42) -> dict:
    """Run repeated stratified k-fold CV.

    Returns per-metric mean/std across repeats plus the pooled out-of-fold
    probabilities from the first repeat (used for threshold diagnostics).
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    per_repeat: list[dict[str, float]] = []
    oof_sum = np.zeros(len(y))

    for rep in range(n_repeats):
        folds = stratified_folds(y, n_splits, seed + rep)
        oof = np.zeros(len(y))
        for test_idx in folds:
            mask = np.ones(len(y), dtype=bool)
            mask[test_idx] = False
            if len(np.unique(y[mask])) < 2 or len(test_idx) == 0:
                continue
            m = model_factory()
            m.fit(X[mask], y[mask])
            oof[test_idx] = m.predict_proba(X[test_idx])
        per_repeat.append(all_metrics(y, oof))
        oof_sum += oof

    keys = ["accuracy", "precision", "recall", "f1", "roc_auc", "brier"]
    summary = {}
    for k in keys:
        vals = np.array([r[k] for r in per_repeat], dtype=float)
        vals = vals[~np.isnan(vals)]
        summary[k] = {
            "mean": round(float(vals.mean()), 4) if len(vals) else None,
            "std": round(float(vals.std(ddof=1)), 4) if len(vals) > 1 else 0.0,
        }
    return {
        "cv": f"{n_splits}-fold stratified x {n_repeats} repeats",
        "n_fits": n_splits * n_repeats,
        "metrics": summary,
        # Mean out-of-fold probability per sample: every value here was produced
        # by a model that never saw that supplier during training, so it is an
        # honest per-supplier risk estimate rather than an in-sample fit.
        "oof_probabilities": [round(float(p), 6) for p in (oof_sum / max(n_repeats, 1))],
    }
