"""SQLite persistence layer.

SQLite is used instead of PostgreSQL because the schema, SQL and access layer are
identical for this workload, while removing a server dependency from the demo.
`DB_URL` is honoured if present so the same schema can be pointed at PostgreSQL
later without touching call sites.

Deliberately absent: a `supplier_contracts` table.  Supplier contracts are out of
scope for this system (master prompt sections 9 and 36).
"""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from typing import Any, Iterable

from . import config

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS buyers (
    buyer_id             TEXT PRIMARY KEY,
    buyer_name           TEXT NOT NULL,
    contact_name         TEXT,
    contact_email        TEXT,
    industry             TEXT,
    country              TEXT,
    procurement_policy_id TEXT,
    buyer_contract_id    TEXT
);

CREATE TABLE IF NOT EXISTS suppliers (
    supplier_id                   TEXT PRIMARY KEY,
    supplier_name                 TEXT NOT NULL,
    contact_name                  TEXT,
    contact_email                 TEXT,
    contact_phone                 TEXT,
    primary_product_category      TEXT,
    fda_status                    TEXT,
    ce_status                     TEXT,
    iso_13485_status              TEXT,
    clearance_510k_status         TEXT,
    recalls_3y                    INTEGER,
    adverse_events                INTEGER,
    months_since_inspection       INTEGER,
    last_inspection_outcome       TEXT,
    batch_rejection_rate          REAL,
    complaint_rate                REAL,
    capa_frequency                REAL,
    field_failure_rate            REAL,
    mtbf_hours                    REAL,
    warranty_claim_rate           REAL,
    credit_rating                 TEXT,
    revenue_growth                REAL,
    debt_to_equity                REAL,
    liquidity_ratio               REAL,
    payment_history               REAL,
    on_time_delivery              REAL,
    lead_time_variability         REAL,
    order_fulfillment_accuracy    REAL,
    capacity_utilization          REAL,
    country_risk                  REAL,
    alternate_suppliers           INTEGER,
    manufacturing_sites           INTEGER,
    production_capacity           REAL,
    demand_to_capacity            REAL,
    finished_goods_inventory_days REAL,
    backup_facility               TEXT,
    distance_km                   REAL,
    transit_time_days             REAL,
    transit_time_variability      REAL,
    route_on_time_delivery        REAL,
    historical_performance_raw    REAL,
    regulatory_compliance_raw     REAL,
    synthetic_disruption_probability REAL,
    historical_disruption_label   INTEGER
);

CREATE TABLE IF NOT EXISTS rfqs (
    rfq_id                  TEXT PRIMARY KEY,
    buyer_id                TEXT REFERENCES buyers(buyer_id),
    equipment               TEXT,
    clinical_use            TEXT,
    quantity                INTEGER,
    budget_per_unit         REAL,
    required_delivery_days  INTEGER,
    required_certifications TEXT,
    warranty_months         INTEGER,
    service_sla_hours       INTEGER,
    issue_date              TEXT,
    status                  TEXT
);

CREATE TABLE IF NOT EXISTS rfq_quotes (
    quote_id            INTEGER PRIMARY KEY AUTOINCREMENT,
    rfq_id              TEXT REFERENCES rfqs(rfq_id),
    supplier_id         TEXT REFERENCES suppliers(supplier_id),
    supplier_name       TEXT,
    quoted_unit_price   REAL,
    quoted_delivery_days INTEGER,
    warranty_months     INTEGER,
    service_sla_hours   INTEGER,
    validity_days       INTEGER,
    compliance_docs     TEXT,
    UNIQUE (rfq_id, supplier_id)
);

CREATE TABLE IF NOT EXISTS supplier_risk_predictions (
    supplier_id       TEXT PRIMARY KEY REFERENCES suppliers(supplier_id),
    risk_probability  REAL,   -- 0..1  P(material disruption / late delivery)
    risk_score        REAL,   -- 0..100
    risk_level        TEXT,   -- LOW / MEDIUM / HIGH / CRITICAL
    model_confidence  REAL,   -- 0..100, evidence strength (NOT 100 - risk)
    model_name        TEXT,
    top_drivers_json  TEXT,   -- SHAP-style feature attributions
    confidence_breakdown_json TEXT,
    predicted_at      TEXT
);

CREATE TABLE IF NOT EXISTS supplier_scores (
    rfq_id            TEXT REFERENCES rfqs(rfq_id),
    supplier_id       TEXT REFERENCES suppliers(supplier_id),
    price_score       REAL,
    delivery_score    REAL,
    historical_score  REAL,
    quality_score     REAL,
    compliance_score  REAL,
    resilience_score  REAL,
    decision_score    REAL,   -- 0..100
    total_evaluated_cost REAL,
    flags_json        TEXT,
    eligibility       TEXT,   -- AUTO_APPROVABLE / REVIEW_REQUIRED / BLOCKED
    computed_at       TEXT,
    PRIMARY KEY (rfq_id, supplier_id)
);

CREATE TABLE IF NOT EXISTS recommendations (
    recommendation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    rfq_id            TEXT REFERENCES rfqs(rfq_id),
    supplier_id       TEXT REFERENCES suppliers(supplier_id),
    decision_score    REAL,
    risk_score        REAL,
    risk_probability  REAL,
    risk_level        TEXT,
    model_confidence  REAL,
    outcome           TEXT,   -- RECOMMENDED / RECOMMENDED_WITH_REVIEW / FLAGGED
    reasons_json      TEXT,
    evidence_json     TEXT,
    created_at        TEXT
);

CREATE TABLE IF NOT EXISTS approvals (
    approval_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    rfq_id            TEXT REFERENCES rfqs(rfq_id),
    supplier_id       TEXT REFERENCES suppliers(supplier_id),
    recommendation_score REAL,
    risk_score        REAL,
    risk_probability  REAL,
    model_confidence  REAL,
    approver          TEXT,
    decision          TEXT,   -- APPROVED / REJECTED
    reason            TEXT,
    decided_at        TEXT
);

CREATE TABLE IF NOT EXISTS audit_events (
    event_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    rfq_id       TEXT,
    supplier_id  TEXT,
    event_type   TEXT,
    decision_score REAL,
    risk_score   REAL,
    decision     TEXT,
    actor        TEXT,
    reason       TEXT,
    created_at   TEXT
);

CREATE INDEX IF NOT EXISTS idx_quotes_rfq ON rfq_quotes(rfq_id);
CREATE INDEX IF NOT EXISTS idx_scores_rfq ON supplier_scores(rfq_id);
CREATE INDEX IF NOT EXISTS idx_audit_rfq ON audit_events(rfq_id);
CREATE INDEX IF NOT EXISTS idx_recs_rfq ON recommendations(rfq_id);
"""


def connect(path=None) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path or config.DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def session(path=None):
    conn = connect(path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)


def query(conn: sqlite3.Connection, sql: str, params: Iterable = ()) -> list[dict[str, Any]]:
    cur = conn.execute(sql, tuple(params))
    return [dict(r) for r in cur.fetchall()]


def query_one(conn: sqlite3.Connection, sql: str, params: Iterable = ()) -> dict[str, Any] | None:
    rows = query(conn, sql, params)
    return rows[0] if rows else None
