"""Central configuration for the Medical Equipment Procurement Copilot.

Everything tunable lives here: paths, scoring weights, risk bands, compliance
rules and demo settings.  No secrets are stored in this file - API keys are read
from environment variables only (see .env.example).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
RAG_DIR = ROOT / "rag_documents"
RFQ_PDF_DIR = RAG_DIR / "rfqs"
MODELS_DIR = ROOT / "models"
FRONTEND_DIR = ROOT / "frontend"
DOCS_DIR = ROOT / "docs"

# DB_PATH may be redirected (e.g. onto local disk) when models/ lives on a
# network or FUSE mount that does not support SQLite locking.
DB_PATH = Path(os.getenv("PROCUREMENT_DB_PATH", str(MODELS_DIR / "procurement.db")))
MODEL_ARTIFACT = MODELS_DIR / "risk_model.json"
METRICS_ARTIFACT = MODELS_DIR / "model_evaluation.json"
RAG_INDEX = MODELS_DIR / "rag_index.json"
STATIC_SNAPSHOT = MODELS_DIR / "static_snapshot.json"

BUYER_CSV = DATA_DIR / "buyer.csv"
SUPPLIER_CSV = DATA_DIR / "supplier_master.csv"
RFQ_CSV = DATA_DIR / "rfqs.csv"
QUOTES_CSV = DATA_DIR / "rfq_quotes.csv"
SCORING_SPEC = DATA_DIR / "scoring_spec.json"

POLICY_PDF = RAG_DIR / "buyer_procurement_policy_POL-MED-001.pdf"
CONTRACT_PDF = RAG_DIR / "buyer_master_contract_CON-MED-001.pdf"

for _d in (MODELS_DIR,):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Determinism.  The demo must be repeatable.
# --------------------------------------------------------------------------
RANDOM_SEED = 42

# Golden-path RFQs hardened for the live demo.
GOLDEN_PATH_RFQS = ["RFQ-102", "RFQ-101"]
DEFAULT_RFQ = "RFQ-102"

BUYER_ID = "BUY-001"

# --------------------------------------------------------------------------
# Procurement decision score - configurable weights (must sum to 1.0)
# Source of truth: buyer procurement policy POL-MED-001 section 3.
# --------------------------------------------------------------------------
DECISION_WEIGHTS = {
    "price": 0.25,
    "delivery": 0.20,
    "historical_performance": 0.20,
    "quality_reliability": 0.15,
    "regulatory_compliance": 0.15,
    "financial_service_resilience": 0.05,
}

WEIGHT_LABELS = {
    "price": "Price competitiveness",
    "delivery": "Delivery performance",
    "historical_performance": "Historical supplier performance",
    "quality_reliability": "Product quality / reliability",
    "regulatory_compliance": "Regulatory compliance",
    "financial_service_resilience": "Financial / service resilience",
}

# --------------------------------------------------------------------------
# Risk bands (policy POL-MED-001 section 4)
# --------------------------------------------------------------------------
RISK_BANDS = [
    ("LOW", 0.0, 25.0),
    ("MEDIUM", 25.0, 50.0),
    ("HIGH", 50.0, 75.0),
    ("CRITICAL", 75.0, 100.01),
]


def risk_band(risk_score_0_100: float) -> str:
    """Map a 0-100 risk score onto the buyer's policy risk bands.

    Policy POL-MED-001 section 4:  0-25 Low, >25-50 Medium,
    >50-75 High, >75 Critical.  Boundaries are inclusive on the upper edge.
    """
    r = float(risk_score_0_100)
    if r <= 25.0:
        return "LOW"
    if r <= 50.0:
        return "MEDIUM"
    if r <= 75.0:
        return "HIGH"
    return "CRITICAL"


# --------------------------------------------------------------------------
# Price scoring guard rails
# --------------------------------------------------------------------------
# A quote this far below the RFQ peer median is flagged as a suspiciously low
# bid: it stops earning additional price points and raises a review flag.
SUSPICIOUS_LOW_BID_RATIO = 0.75

# --------------------------------------------------------------------------
# Regulatory compliance vocabulary observed in the supplier master data.
# Values are 0-1 multipliers / sub-scores used by the compliance scorer.
# --------------------------------------------------------------------------
FDA_STATUS_SCORE = {
    "certified": 1.00,
    "certified - minor findings": 0.85,
    "certified - major findings": 0.55,
    "suspended": 0.00,
    "certification suspended": 0.00,
}
CE_STATUS_SCORE = {
    "valid": 1.00,
    "under review": 0.60,
    "expired": 0.10,
}
ISO_STATUS_SCORE = {
    "certified": 1.00,
    "certified - conditional": 0.70,
    "not certified": 0.00,
}
CLEARANCE_STATUS_SCORE = {
    "cleared": 1.00,
    "pending": 0.50,
    "not cleared": 0.00,
}
INSPECTION_OUTCOME_SCORE = {
    "pass": 1.00,
    "minor findings": 0.80,
    "warning letter": 0.45,
    "consent decree": 0.05,
}
CREDIT_RATING_SCORE = {
    "aa": 1.00, "a": 0.85, "bbb": 0.65, "bb": 0.40, "b": 0.20, "ccc": 0.05,
}
BACKUP_FACILITY_SCORE = {"yes": 1.0, "partial": 0.5, "no": 0.0}
COMPLIANCE_DOCS_SCORE = {"yes": 1.0, "partial": 0.5, "no": 0.0}

# Statuses that trigger the policy's mandatory-review hard rules.
SUSPENDED_FDA = {"suspended", "certification suspended"}
MISSING_CLEARANCE = {"not cleared"}
PENDING_CLEARANCE = {"pending"}
INVALID_CE = {"expired"}
UNCERTIFIED_ISO = {"not certified"}
SEVERE_INSPECTION = {"consent decree", "warning letter"}

# --------------------------------------------------------------------------
# ML configuration
# --------------------------------------------------------------------------
# NOTE: 'Synthetic Disruption Probability' is the latent generator probability
# that produced the training label.  Using it as a feature would be target
# leakage, so it is deliberately excluded from the model feature set and is
# used only as a documentation/diagnostic column.
ML_FEATURES = [
    "on_time_delivery",
    "lead_time_variability",
    "order_fulfillment_accuracy",
    "field_failure_rate",
    "batch_rejection_rate",
    "complaint_rate",
    "warranty_claim_rate",
    "mtbf_hours",
    "recalls_3y",
    "inspection_score",
    "regulatory_compliance_raw",
    "historical_performance_raw",
    "capacity_utilization",
    "demand_to_capacity",
    "country_risk",
    "transit_time_variability",
    "payment_history",
    "credit_score",
    "debt_to_equity",
    "liquidity_ratio",
    "alternate_suppliers",
    "backup_facility",
    "finished_goods_inventory_days",
]

ML_FEATURE_LABELS = {
    "on_time_delivery": "On-time delivery %",
    "lead_time_variability": "Lead-time variability (days)",
    "order_fulfillment_accuracy": "Order fulfilment accuracy %",
    "field_failure_rate": "Field failure rate %",
    "batch_rejection_rate": "Batch rejection rate %",
    "complaint_rate": "Complaint rate / 1000 units",
    "warranty_claim_rate": "Warranty claim rate %",
    "mtbf_hours": "Mean time between failures (hrs)",
    "recalls_3y": "Recalls (past 3 years)",
    "inspection_score": "Last inspection outcome",
    "regulatory_compliance_raw": "Regulatory compliance score",
    "historical_performance_raw": "Historical performance score",
    "capacity_utilization": "Capacity utilisation %",
    "demand_to_capacity": "Demand-to-capacity ratio %",
    "country_risk": "Country risk score",
    "transit_time_variability": "Transit-time variability (days)",
    "payment_history": "Payment history score",
    "credit_score": "Credit rating",
    "debt_to_equity": "Debt-to-equity ratio",
    "liquidity_ratio": "Liquidity ratio",
    "alternate_suppliers": "Alternate suppliers available",
    "backup_facility": "Backup facility availability",
    "finished_goods_inventory_days": "Finished-goods inventory (days)",
}

CV_FOLDS = 5
CV_REPEATS = 10

# --------------------------------------------------------------------------
# Model confidence.  Confidence is evidence strength, NOT (100 - risk).
# Weights sum to 1.0.
# --------------------------------------------------------------------------
CONFIDENCE_WEIGHTS = {
    "data_completeness": 0.25,
    "probability_certainty": 0.25,
    "model_agreement": 0.20,
    "history_consistency": 0.20,
    "rfq_data_completeness": 0.10,
}

# --------------------------------------------------------------------------
# RAG
# --------------------------------------------------------------------------
RAG_TOP_K = 5
RAG_CHUNK_TARGET_CHARS = 900
RAG_CHUNK_OVERLAP_CHARS = 150
# Only these three document types may ever enter the knowledge base
# (policy POL-MED-001 section 9).  Supplier contracts are forbidden.
ALLOWED_RAG_DOC_TYPES = {"buyer_policy", "buyer_master_contract", "buyer_rfq"}

# --------------------------------------------------------------------------
# Hugging Face (single credential for both AI slots)
# --------------------------------------------------------------------------
# Setting HF_API_KEY alone is enough to switch the system on:
#   * the Copilot uses a Hugging Face chat model to phrase answers, and
#   * retrieval adds Hugging Face embeddings alongside BM25 + TF-IDF.
# Both degrade to the offline path automatically if the key is absent or the
# service is unreachable, so the demo never depends on the network.
HF_API_KEY = (os.getenv("HF_API_KEY") or os.getenv("HUGGINGFACE_API_KEY", "")).strip()

# HF's router speaks the OpenAI chat-completions wire format.
HF_ROUTER = "https://router.huggingface.co"
HF_CHAT_URL = f"{HF_ROUTER}/v1/chat/completions"
HF_CHAT_MODEL = os.getenv("HF_CHAT_MODEL", "meta-llama/Llama-3.3-70B-Instruct").strip()
# Optional `:provider` suffix (e.g. ":together") pins who serves the model;
# without it Hugging Face routes to the fastest available provider.

HF_EMBED_MODEL = os.getenv("HF_EMBED_MODEL",
                           "sentence-transformers/all-MiniLM-L6-v2").strip()
HF_EMBED_URL = (f"{HF_ROUTER}/hf-inference/models/{HF_EMBED_MODEL}"
                f"/pipeline/feature-extraction")
HF_EMBED_BATCH = int(os.getenv("HF_EMBED_BATCH", "32"))
HF_TIMEOUT = int(os.getenv("HF_TIMEOUT", "30"))

# --------------------------------------------------------------------------
# LLM (optional).  Absent keys => deterministic grounded fallback.
# --------------------------------------------------------------------------
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()


def _resolve_provider() -> str:
    """Pick the generation provider.

    An explicit LLM_PROVIDER always wins.  Otherwise the provider is inferred
    from whichever key is present, so supplying HF_API_KEY on its own is enough
    to enable Hugging Face without setting anything else.
    """
    explicit = os.getenv("LLM_PROVIDER", "").strip().lower()
    if explicit:
        return explicit
    if HF_API_KEY:
        return "huggingface"
    if ANTHROPIC_API_KEY:
        return "anthropic"
    if OPENAI_API_KEY:
        return "openai"
    return ""


LLM_PROVIDER = _resolve_provider()

_DEFAULT_MODEL = {
    "huggingface": HF_CHAT_MODEL,
    "anthropic": "claude-sonnet-5",
    "openai": "gpt-4o-mini",
}
LLM_MODEL = (os.getenv("LLM_MODEL", "").strip()
             or _DEFAULT_MODEL.get(LLM_PROVIDER, ""))

# Providers reachable through the OpenAI chat-completions request shape.
CHAT_COMPLETIONS_URL = {
    "huggingface": HF_CHAT_URL,
    "openai": "https://api.openai.com/v1/chat/completions",
}

_API_KEYS = {
    "huggingface": HF_API_KEY,
    "anthropic": ANTHROPIC_API_KEY,
    "openai": OPENAI_API_KEY,
}


def llm_api_key() -> str:
    return _API_KEYS.get(LLM_PROVIDER, "")


def llm_enabled() -> bool:
    return bool(LLM_PROVIDER) and bool(llm_api_key())


# --------------------------------------------------------------------------
# Dense retrieval (optional second signal alongside BM25 + TF-IDF)
# --------------------------------------------------------------------------
# On by default whenever a Hugging Face key exists; set USE_DENSE_RETRIEVAL=0
# to force the purely lexical retriever even with a key configured.
def _env_flag(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


USE_DENSE_RETRIEVAL = _env_flag("USE_DENSE_RETRIEVAL", bool(HF_API_KEY))

# Vote the dense ranking gets in reciprocal rank fusion, relative to 1.0 for
# each lexical ranking (BM25 and TF-IDF).  Kept below 1.0 deliberately: on a
# regulatory corpus the decisive terms are exact surface forms, so embeddings
# should broaden recall without overriding an exact clause match.
DENSE_FUSION_WEIGHT = float(os.getenv("DENSE_FUSION_WEIGHT", "0.5"))


# --------------------------------------------------------------------------
# Server
# --------------------------------------------------------------------------
HOST = os.getenv("APP_HOST", "127.0.0.1")
PORT = int(os.getenv("APP_PORT", "8000"))

APP_TITLE = "Procurement Copilot"
APP_SUBTITLE = "AI-assisted, evidence-backed medical equipment supplier decisions"
PROTOTYPE_BANNER = (
    "Prototype - all figures derived from synthetic data. AI output is decision "
    "support only; final award authority remains with the procurement approver."
)


def load_scoring_spec() -> dict:
    """Load the external scoring spec, falling back to the in-code defaults."""
    try:
        with open(SCORING_SPEC, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return {"default_weights": DECISION_WEIGHTS, "risk_bands": dict(
            (n, f"{lo}-{hi}") for n, lo, hi in RISK_BANDS)}


def active_weights() -> dict:
    """Weights actually used, taken from the spec file when it is valid."""
    spec = load_scoring_spec()
    w = spec.get("default_weights") or {}
    if w and abs(sum(w.values()) - 1.0) < 1e-6 and set(w) == set(DECISION_WEIGHTS):
        return dict(w)
    return dict(DECISION_WEIGHTS)
