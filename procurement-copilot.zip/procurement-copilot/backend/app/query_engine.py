"""Structured retrieval over the procurement database.

Why this exists
---------------
A question like "how many suppliers have suspended FDA certification?" or "which
supplier has the best on-time delivery?" cannot be answered by document
retrieval: the answer is not written in any document, it has to be *computed*
from 50 supplier records and 120 quotations.

So the Copilot uses two retrievers, and routes each question to the right one:

    structured retrieval (this module)  -> facts computed from SQLite
    document retrieval  (rag/)          -> cited clauses from buyer documents

This is the hybrid-RAG pattern, and it is the correct one here for a specific
reason: **numbers must not pass through an embedding**.  Chunking supplier rows
into text and retrieving them by vector similarity is how a system ends up
reporting the wrong supplier's price with total confidence.  Reading them with a
parameterised query cannot do that.  It is also what the specification requires -
structured supplier facts come from the database, never from retrieved text.

Safety: the question never reaches SQL.  Column names come from the FIELDS and
FILTERS registries in this file only, and every user-supplied value is bound as a
parameter.  There is no string interpolation of user input anywhere, so the
question cannot alter the query's shape.

Every result carries the SQL that produced it, so any figure on screen can be
traced back to the exact statement that computed it.
"""
from __future__ import annotations

import re
from typing import Any

from . import db

# ---------------------------------------------------------------------------
# Field registry - the only columns this module will ever read.
# ---------------------------------------------------------------------------
# better: "high" = a larger value is better, "low" = smaller is better,
#         None   = neither (descriptive only)
FIELDS: dict[str, dict[str, Any]] = {
    "on_time_delivery": {
        "aliases": ["on-time delivery", "on time delivery", "otd", "punctual",
                    "delivery record", "delivery performance", "delivery history"],
        "sql": "s.on_time_delivery", "label": "on-time delivery", "unit": "%",
        "better": "high"},
    "lead_time_variability": {
        "aliases": ["lead time variability", "lead-time variability",
                    "lead time variance", "schedule variability"],
        "sql": "s.lead_time_variability", "label": "lead-time variability",
        "unit": " days", "better": "low"},
    "order_fulfillment_accuracy": {
        "aliases": ["fulfilment accuracy", "fulfillment accuracy", "order accuracy"],
        "sql": "s.order_fulfillment_accuracy", "label": "order fulfilment accuracy",
        "unit": "%", "better": "high"},
    "field_failure_rate": {
        "aliases": ["field failure", "failure rate", "failures"],
        "sql": "s.field_failure_rate", "label": "field failure rate", "unit": "%",
        "better": "low"},
    "batch_rejection_rate": {
        "aliases": ["batch rejection", "rejection rate"],
        "sql": "s.batch_rejection_rate", "label": "batch rejection rate", "unit": "%",
        "better": "low"},
    "complaint_rate": {
        "aliases": ["complaint rate", "complaints"],
        "sql": "s.complaint_rate", "label": "complaint rate",
        "unit": " per 1000 units", "better": "low"},
    "warranty_claim_rate": {
        "aliases": ["warranty claim", "warranty claims"],
        "sql": "s.warranty_claim_rate", "label": "warranty claim rate", "unit": "%",
        "better": "low"},
    "mtbf_hours": {
        "aliases": ["mtbf", "mean time between failures", "reliability"],
        "sql": "s.mtbf_hours", "label": "MTBF", "unit": " h", "better": "high"},
    "recalls_3y": {
        "aliases": ["recall", "recalls"],
        "sql": "s.recalls_3y", "label": "recalls (3 years)", "unit": "", "better": "low"},
    "adverse_events": {
        "aliases": ["adverse event", "adverse events"],
        "sql": "s.adverse_events", "label": "adverse events", "unit": "", "better": "low"},
    "capacity_utilization": {
        "aliases": ["capacity utilisation", "capacity utilization", "utilisation"],
        "sql": "s.capacity_utilization", "label": "capacity utilisation", "unit": "%",
        "better": "low"},
    "demand_to_capacity": {
        "aliases": ["demand to capacity", "demand-to-capacity"],
        "sql": "s.demand_to_capacity", "label": "demand-to-capacity ratio", "unit": "%",
        "better": "low"},
    "country_risk": {
        "aliases": ["country risk", "geographic risk", "geopolitical"],
        "sql": "s.country_risk", "label": "country risk score", "unit": "", "better": "low"},
    "payment_history": {
        "aliases": ["payment history", "payment record"],
        "sql": "s.payment_history", "label": "payment history score", "unit": "",
        "better": "high"},
    "debt_to_equity": {
        "aliases": ["debt to equity", "leverage", "gearing"],
        "sql": "s.debt_to_equity", "label": "debt-to-equity ratio", "unit": "",
        "better": "low"},
    "liquidity_ratio": {
        "aliases": ["liquidity", "current ratio"],
        "sql": "s.liquidity_ratio", "label": "liquidity ratio", "unit": "", "better": "high"},
    "revenue_growth": {
        "aliases": ["revenue growth", "growth"],
        "sql": "s.revenue_growth", "label": "revenue growth", "unit": "%", "better": "high"},
    "alternate_suppliers": {
        "aliases": ["alternate suppliers", "alternative suppliers", "backups"],
        "sql": "s.alternate_suppliers", "label": "alternate suppliers available",
        "unit": "", "better": "high"},
    "manufacturing_sites": {
        "aliases": ["manufacturing sites", "factories", "plants", "sites"],
        "sql": "s.manufacturing_sites", "label": "manufacturing sites", "unit": "",
        "better": "high"},
    "distance_km": {
        "aliases": ["distance", "how far"],
        "sql": "s.distance_km", "label": "distance to buyer", "unit": " km", "better": "low"},
    "transit_time_days": {
        "aliases": ["transit time", "shipping time"],
        "sql": "s.transit_time_days", "label": "historical transit time", "unit": " days",
        "better": "low"},
    "historical_performance_raw": {
        "aliases": ["historical performance", "track record", "past performance"],
        "sql": "s.historical_performance_raw", "label": "historical performance score",
        "unit": "/100", "better": "high"},
    "regulatory_compliance_raw": {
        "aliases": ["regulatory compliance score", "compliance score"],
        "sql": "s.regulatory_compliance_raw", "label": "regulatory compliance score",
        "unit": "/100", "better": "high"},
    "risk_score": {
        "aliases": ["risk score", "risk", "riskiest", "disruption risk"],
        "sql": "p.risk_score", "label": "predicted risk score", "unit": "/100",
        "better": "low"},
    "risk_probability": {
        "aliases": ["risk probability", "probability of disruption"],
        "sql": "p.risk_probability", "label": "disruption probability", "unit": "",
        "better": "low"},
    "model_confidence": {
        "aliases": ["model confidence", "confidence"],
        "sql": "p.model_confidence", "label": "model confidence", "unit": "%",
        "better": "high"},
}

# ---------------------------------------------------------------------------
# Categorical filters
# ---------------------------------------------------------------------------
FILTERS: dict[str, dict[str, Any]] = {
    "fda_suspended": {
        "phrases": ["suspended fda", "fda suspended", "fda certification suspended",
                    "suspended certification", "suspended regulatory"],
        "sql": "LOWER(s.fda_status) IN ('suspended','certification suspended')",
        "label": "FDA certification suspended"},
    "fda_major_findings": {
        "phrases": ["major findings", "fda major"],
        "sql": "LOWER(s.fda_status) = 'certified - major findings'",
        "label": "FDA certified with major findings"},
    "ce_expired": {
        "phrases": ["ce expired", "expired ce", "expired ce marking"],
        "sql": "LOWER(s.ce_status) = 'expired'", "label": "CE marking expired"},
    "ce_under_review": {
        "phrases": ["ce under review", "under review"],
        "sql": "LOWER(s.ce_status) = 'under review'", "label": "CE marking under review"},
    "iso_missing": {
        "phrases": ["iso 13485 not certified", "not iso certified", "no iso",
                    "iso not certified", "missing iso"],
        "sql": "LOWER(s.iso_13485_status) = 'not certified'",
        "label": "ISO 13485 not certified"},
    "iso_conditional": {
        "phrases": ["iso conditional", "conditional iso"],
        "sql": "LOWER(s.iso_13485_status) = 'certified - conditional'",
        "label": "ISO 13485 conditional"},
    "clearance_missing": {
        "phrases": ["not cleared", "missing clearance", "no 510", "510(k) not cleared"],
        "sql": "LOWER(s.clearance_510k_status) = 'not cleared'",
        "label": "510(k) clearance missing"},
    "clearance_pending": {
        "phrases": ["clearance pending", "510(k) pending", "pending clearance"],
        "sql": "LOWER(s.clearance_510k_status) = 'pending'",
        "label": "510(k) clearance pending"},
    "consent_decree": {
        "phrases": ["consent decree", "under decree"],
        "sql": "LOWER(s.last_inspection_outcome) = 'consent decree'",
        "label": "under a regulatory consent decree"},
    "warning_letter": {
        "phrases": ["warning letter", "warning letters"],
        "sql": "LOWER(s.last_inspection_outcome) = 'warning letter'",
        "label": "most recent inspection produced a warning letter"},
    "has_recalls": {
        "phrases": ["have recalls", "with recalls", "any recalls"],
        "sql": "s.recalls_3y > 0", "label": "recalls in the past 3 years"},
    "blocked": {
        "phrases": ["blocked", "cannot be approved", "cannot be auto-approved",
                    "not auto-approvable", "barred", "excluded"],
        "sql": ("EXISTS (SELECT 1 FROM supplier_scores sc "
                "WHERE sc.supplier_id = s.supplier_id AND sc.eligibility = 'BLOCKED')"),
        "label": "BLOCKED on at least one RFQ"},
    "review_required": {
        "phrases": ["review required", "needs review", "need review",
                    "requires review", "needing review", "flagged for review",
                    "to review", "under review by"],
        "sql": ("EXISTS (SELECT 1 FROM supplier_scores sc "
                "WHERE sc.supplier_id = s.supplier_id AND sc.eligibility = 'REVIEW_REQUIRED')"),
        "label": "REVIEW_REQUIRED on at least one RFQ"},
    "no_backup": {
        "phrases": ["no backup", "without backup", "no backup facility"],
        "sql": "LOWER(s.backup_facility) = 'no'", "label": "no backup facility"},
}

RISK_LEVELS = ("CRITICAL", "HIGH", "MEDIUM", "LOW")

SUPERLATIVE_HIGH = ("best", "highest", "most", "top", "greatest", "largest", "maximum")
SUPERLATIVE_LOW = ("worst", "lowest", "least", "cheapest", "smallest", "minimum",
                   "riskiest", "poorest")

COUNT_WORDS = ("how many", "count", "number of", "how much")
AGG_WORDS = {"average": "AVG", "mean": "AVG", "avg": "AVG", "total": "SUM",
             "sum": "SUM", "maximum": "MAX", "minimum": "MIN"}

LIST_WORDS = ("list", "show", "which suppliers", "what suppliers", "who are",
              "give me", "name the", "any suppliers", "are there")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt(value, field: dict) -> str:
    if value is None:
        return "n/a"
    unit = field.get("unit", "")
    if unit == "/100":
        return f"{float(value):.0f}/100"
    if unit == " h":
        return f"{float(value):,.0f} h"
    if unit == " km":
        return f"{float(value):,.0f} km"
    if isinstance(value, float):
        return f"{value:,.2f}".rstrip("0").rstrip(".") + unit
    return f"{value}{unit}"


def _inr(v) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "n/a"
    if v >= 1e7:
        return f"INR {v/1e7:.2f} Cr"
    if v >= 1e5:
        return f"INR {v/1e5:.2f} L"
    return f"INR {v:,.0f}"


def detect_field(question: str) -> tuple[str, dict] | None:
    """Longest alias wins, so 'lead time variability' beats 'delivery'."""
    q = question.lower()
    best = None
    for key, f in FIELDS.items():
        for alias in f["aliases"]:
            if alias in q and (best is None or len(alias) > best[0]):
                best = (len(alias), key, f)
    return (best[1], best[2]) if best else None


def detect_filters(question: str) -> list[tuple[str, dict]]:
    q = question.lower()
    out = []
    for key, f in FILTERS.items():
        if any(p in q for p in f["phrases"]):
            out.append((key, f))
    return out


def detect_risk_level(question: str) -> str | None:
    q = question.lower()
    for lvl in RISK_LEVELS:
        if re.search(rf"\b{lvl.lower()}\b", q):
            return lvl
    return None


BASE_JOIN = """
    FROM suppliers s
    LEFT JOIN supplier_risk_predictions p ON p.supplier_id = s.supplier_id
"""


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------

def supplier_profile(conn, supplier_id: str) -> dict | None:
    """Everything known about one supplier - works for any of the 50."""
    sql = f"""SELECT s.*, p.risk_score, p.risk_level, p.risk_probability,
                     p.model_confidence {BASE_JOIN}
              WHERE s.supplier_id = ?"""
    row = db.query_one(conn, sql, (supplier_id,))
    if not row:
        return None
    quotes = db.query(conn, """
        SELECT q.rfq_id, r.equipment, q.quoted_unit_price, q.quoted_delivery_days,
               sc.decision_score, sc.eligibility
        FROM rfq_quotes q
        JOIN rfqs r ON r.rfq_id = q.rfq_id
        LEFT JOIN supplier_scores sc
               ON sc.rfq_id = q.rfq_id AND sc.supplier_id = q.supplier_id
        WHERE q.supplier_id = ? ORDER BY q.rfq_id""", (supplier_id,))

    facts = [
        (f"{row['supplier_name']} ({row['supplier_id']}) - "
         f"{row['primary_product_category']}. Contact {row['contact_name']}, "
         f"{row['contact_email']}, {row['contact_phone']}."),
        (f"Regulatory: FDA {row['fda_status']}; CE {row['ce_status']}; "
         f"ISO 13485 {row['iso_13485_status']}; 510(k) {row['clearance_510k_status']}; "
         f"last inspection {row['last_inspection_outcome']} "
         f"({row['months_since_inspection']} months ago); "
         f"{row['recalls_3y']} recalls and {row['adverse_events']} adverse events."),
        (f"Delivery: {row['on_time_delivery']:.1f}% on time, lead-time variability "
         f"{row['lead_time_variability']:.0f} days, fulfilment accuracy "
         f"{row['order_fulfillment_accuracy']:.1f}%, transit "
         f"{row['transit_time_days']:.0f} days over {row['distance_km']:,.0f} km."),
        (f"Quality: field failure {row['field_failure_rate']}%, batch rejection "
         f"{row['batch_rejection_rate']}%, complaints {row['complaint_rate']} per 1000, "
         f"warranty claims {row['warranty_claim_rate']}%, MTBF {row['mtbf_hours']:,.0f} h."),
        (f"Resilience: credit {row['credit_rating']}, capacity utilisation "
         f"{row['capacity_utilization']:.0f}%, demand-to-capacity "
         f"{row['demand_to_capacity']:.0f}%, {row['alternate_suppliers']} alternates, "
         f"{row['manufacturing_sites']} sites, backup facility {row['backup_facility']}, "
         f"country risk {row['country_risk']:.0f}."),
    ]
    if row.get("risk_level"):
        facts.append(
            f"Predicted disruption risk: {row['risk_level']} "
            f"({row['risk_score']:.0f}/100, probability {row['risk_probability']:.0%}), "
            f"model confidence {row['model_confidence']:.0f}%.")
    if quotes:
        facts.append(f"Quoted on {len(quotes)} RFQ(s): " + "; ".join(
            f"{q['rfq_id']} {q['equipment']} at {_inr(q['quoted_unit_price'])}/unit, "
            f"{q['quoted_delivery_days']} days"
            + (f", score {q['decision_score']:.1f}/100 ({q['eligibility']})"
               if q["decision_score"] is not None else "")
            for q in quotes))
    else:
        facts.append("This supplier has not quoted on any current RFQ.")

    return {"facts": facts, "table": quotes, "sql": sql.strip(),
            "supplier_id": row["supplier_id"], "supplier_name": row["supplier_name"]}


def filter_suppliers(conn, question: str, limit: int = 25) -> dict | None:
    """"Which suppliers have X?" - categorical filters and risk levels."""
    where, labels = [], []
    for _, f in detect_filters(question):
        where.append(f["sql"])
        labels.append(f["label"])

    level = detect_risk_level(question)
    if level and any(w in question.lower() for w in
                     ("risk", "riskiest", "supplier", "suppliers", "vendor")):
        where.append("p.risk_level = ?")
        labels.append(f"{level} predicted risk")

    if not where:
        return None

    params = [level] if level and "p.risk_level = ?" in where else []
    sql = f"""SELECT s.supplier_id, s.supplier_name, s.primary_product_category,
                     s.fda_status, s.ce_status, s.iso_13485_status,
                     s.clearance_510k_status, s.last_inspection_outcome,
                     p.risk_level, p.risk_score {BASE_JOIN}
              WHERE {' AND '.join(where)}
              ORDER BY COALESCE(p.risk_score, 0) DESC"""
    rows = db.query(conn, sql, params)

    criteria = " and ".join(labels)
    if not rows:
        return {"facts": [f"No supplier matches: {criteria}."],
                "table": [], "sql": sql.strip()}

    facts = [f"{len(rows)} supplier(s) match: {criteria}."]
    for r in rows[:limit]:
        facts.append(
            f"  - {r['supplier_name']} ({r['supplier_id']}, "
            f"{r['primary_product_category']})"
            + (f" - risk {r['risk_level']} {r['risk_score']:.0f}/100"
               if r["risk_level"] else ""))
    if len(rows) > limit:
        facts.append(f"  ... and {len(rows) - limit} more.")
    return {"facts": facts, "table": rows, "sql": sql.strip()}


def count_or_aggregate(conn, question: str) -> dict | None:
    """"How many...", "what is the average...", "total budget..."."""
    q = question.lower()
    wants_count = any(w in q for w in COUNT_WORDS)
    agg = next((fn for word, fn in AGG_WORDS.items() if word in q), None)
    if not wants_count and not agg:
        return None

    # Portfolio-level counts that need no field.
    if wants_count:
        if "rfq" in q:
            if "open" in q:
                sql = "SELECT COUNT(*) n FROM rfqs WHERE LOWER(status)='open'"
                n = db.query_one(conn, sql, ())["n"]
                return {"facts": [f"{n} RFQs are currently open."], "table": None,
                        "sql": sql}
            sql = "SELECT COUNT(*) n FROM rfqs"
            n = db.query_one(conn, sql, ())["n"]
            return {"facts": [f"There are {n} RFQs in total."], "table": None, "sql": sql}
        if "quot" in q:
            sql = "SELECT COUNT(*) n FROM rfq_quotes"
            n = db.query_one(conn, sql, ())["n"]
            return {"facts": [f"{n} quotations are on file."], "table": None, "sql": sql}
        if "blocked" in q:
            sql = """SELECT COUNT(DISTINCT supplier_id) n FROM supplier_scores
                     WHERE eligibility = 'BLOCKED'"""
            n = db.query_one(conn, sql, ())["n"]
            return {"facts": [f"{n} distinct supplier(s) are BLOCKED on at least one RFQ."],
                    "table": None, "sql": sql.strip()}

        filtered = filter_suppliers(conn, question)
        if filtered is not None and filtered["table"] is not None:
            n = len(filtered["table"])
            return {"facts": [filtered["facts"][0]] + filtered["facts"][1:],
                    "table": filtered["table"], "sql": filtered["sql"],
                    "count": n}
        sql = "SELECT COUNT(*) n FROM suppliers"
        n = db.query_one(conn, sql, ())["n"]
        return {"facts": [f"There are {n} suppliers in the master data."],
                "table": None, "sql": sql}

    # Aggregations over a numeric field.
    if "budget" in q:
        sql = """SELECT SUM(budget_per_unit * quantity) total,
                        AVG(budget_per_unit) avg_unit, COUNT(*) n FROM rfqs"""
        r = db.query_one(conn, sql, ())
        return {"facts": [
            f"Across {r['n']} RFQs the total budgeted value is {_inr(r['total'])} "
            f"(average {_inr(r['avg_unit'])} per unit)."],
            "table": None, "sql": sql.strip()}

    found = detect_field(question)
    if not found:
        return None
    key, field = found
    sql = f"SELECT {agg}({field['sql']}) v, COUNT(*) n {BASE_JOIN}"
    r = db.query_one(conn, sql, ())
    word = {"AVG": "average", "SUM": "total", "MAX": "highest", "MIN": "lowest"}[agg]
    return {"facts": [f"The {word} {field['label']} across {r['n']} suppliers is "
                      f"{_fmt(r['v'], field)}."],
            "table": None, "sql": sql.strip()}


def rank_suppliers(conn, question: str, limit: int = 5) -> dict | None:
    """"Which supplier has the best on-time delivery?", "who is riskiest?"."""
    q = question.lower()
    high = any(w in q for w in SUPERLATIVE_HIGH)
    low = any(w in q for w in SUPERLATIVE_LOW)
    if not (high or low):
        return None

    # "cheapest quote" is a quotation question, not a supplier attribute.
    if "cheapest" in q or ("price" in q and (high or low)):
        sql = """SELECT q.rfq_id, r.equipment, q.supplier_id, q.supplier_name,
                        q.quoted_unit_price, q.quoted_delivery_days
                 FROM rfq_quotes q JOIN rfqs r ON r.rfq_id = q.rfq_id
                 ORDER BY q.quoted_unit_price """ + ("DESC" if high and not low else "ASC") + " LIMIT ?"
        rows = db.query(conn, sql, (limit,))
        word = "highest" if (high and not low) else "lowest"
        facts = [f"The {word}-priced quotations on file:"]
        facts += [f"  - {r['supplier_name']} on {r['rfq_id']} ({r['equipment']}): "
                  f"{_inr(r['quoted_unit_price'])}/unit, {r['quoted_delivery_days']} days"
                  for r in rows]
        facts.append("Unit prices are not comparable across different equipment types; "
                     "price is scored relative to competing quotations on the same RFQ.")
        return {"facts": facts, "table": rows, "sql": sql.strip()}

    found = detect_field(question)
    if not found:
        return None
    key, field = found

    # "best X" means the good end of X, which depends on the field's direction.
    if high and not low:
        descending = field["better"] == "high"
    else:
        descending = field["better"] == "low"
    # "riskiest"/"highest risk" is literal, not directional.
    if any(w in q for w in ("riskiest", "highest risk", "most risk")):
        descending = True
    if any(w in q for w in ("lowest risk", "least risk", "safest")):
        descending = False

    order = "DESC" if descending else "ASC"
    sql = (f"SELECT s.supplier_id, s.supplier_name, s.primary_product_category, "
           f"{field['sql']} AS value, p.risk_level {BASE_JOIN} "
           f"WHERE {field['sql']} IS NOT NULL ORDER BY value {order} LIMIT ?")
    rows = db.query(conn, sql, (limit,))
    if not rows:
        return None

    lead = rows[0]
    facts = [f"{lead['supplier_name']} ({lead['supplier_id']}) has the "
             f"{'highest' if descending else 'lowest'} {field['label']} at "
             f"{_fmt(lead['value'], field)}."]
    facts.append(f"Top {len(rows)} by {field['label']}:")
    facts += [f"  - {r['supplier_name']} ({r['supplier_id']}): "
              f"{_fmt(r['value'], field)}" for r in rows]
    return {"facts": facts, "table": rows, "sql": sql.strip()}


def compare_suppliers(conn, supplier_ids: list[str]) -> dict | None:
    """Side-by-side on the fields that drive a procurement decision."""
    if len(supplier_ids) < 2:
        return None
    marks = ",".join("?" for _ in supplier_ids)
    sql = f"""SELECT s.supplier_id, s.supplier_name, s.primary_product_category,
                     s.fda_status, s.ce_status, s.iso_13485_status,
                     s.clearance_510k_status, s.on_time_delivery,
                     s.lead_time_variability, s.field_failure_rate, s.mtbf_hours,
                     s.credit_rating, s.historical_performance_raw,
                     p.risk_level, p.risk_score, p.model_confidence {BASE_JOIN}
              WHERE s.supplier_id IN ({marks})"""
    rows = db.query(conn, sql, supplier_ids)
    if len(rows) < 2:
        return None

    facts = ["Side-by-side comparison:"]
    for r in rows:
        facts.append(
            f"  {r['supplier_name']} ({r['supplier_id']}, {r['primary_product_category']}): "
            f"risk {r['risk_level'] or 'n/a'} "
            f"{('%.0f/100' % r['risk_score']) if r['risk_score'] is not None else ''}, "
            f"on-time {r['on_time_delivery']:.1f}%, lead-time variability "
            f"{r['lead_time_variability']:.0f} d, field failure {r['field_failure_rate']}%, "
            f"MTBF {r['mtbf_hours']:,.0f} h, historical "
            f"{r['historical_performance_raw']:.0f}/100, credit {r['credit_rating']}, "
            f"FDA {r['fda_status']}, ISO {r['iso_13485_status']}.")

    # Where they actually differ, in decision terms.
    for key in ("on_time_delivery", "field_failure_rate", "risk_score",
                "historical_performance_raw"):
        f = FIELDS[key]
        col = f["sql"].split(".")[-1]
        vals = [(r["supplier_name"], r.get(col)) for r in rows if r.get(col) is not None]
        if len(vals) < 2:
            continue
        best = (min if f["better"] == "low" else max)(vals, key=lambda kv: kv[1])
        facts.append(f"  Better {f['label']}: {best[0]} ({_fmt(best[1], f)}).")

    # Any RFQ they both quoted on is the comparison that actually matters.
    shared = db.query(conn, f"""
        SELECT q.rfq_id, r.equipment, q.supplier_id, q.supplier_name,
               q.quoted_unit_price, q.quoted_delivery_days,
               sc.decision_score, sc.eligibility
        FROM rfq_quotes q
        JOIN rfqs r ON r.rfq_id = q.rfq_id
        LEFT JOIN supplier_scores sc
               ON sc.rfq_id = q.rfq_id AND sc.supplier_id = q.supplier_id
        WHERE q.supplier_id IN ({marks})
          AND q.rfq_id IN (SELECT rfq_id FROM rfq_quotes WHERE supplier_id IN ({marks})
                           GROUP BY rfq_id HAVING COUNT(DISTINCT supplier_id) > 1)
        ORDER BY q.rfq_id, sc.decision_score DESC""",
        supplier_ids + supplier_ids)
    if shared:
        facts.append("Both quoted on the same RFQ:")
        for r in shared:
            facts.append(
                f"  - {r['rfq_id']} ({r['equipment']}) {r['supplier_name']}: "
                f"{_inr(r['quoted_unit_price'])}/unit, {r['quoted_delivery_days']} days"
                + (f", score {r['decision_score']:.1f}/100 ({r['eligibility']})"
                   if r["decision_score"] is not None else ""))
    else:
        facts.append("These suppliers have no RFQ in common, so their quotations "
                     "cannot be compared directly.")
    return {"facts": facts, "table": rows, "sql": sql.strip()}


def portfolio_overview(conn, question: str) -> dict | None:
    """Cross-RFQ questions: "which RFQ has the most blocked suppliers?" etc."""
    q = question.lower()
    if "rfq" not in q:
        return None
    # Counts, aggregations and superlatives are handled by their own operations;
    # this one only produces listings, so it must not intercept them.
    if any(w in q for w in COUNT_WORDS) or any(w in q for w in AGG_WORDS):
        return None
    if any(w in q for w in SUPERLATIVE_LOW) and "blocked" not in q:
        return None

    if "blocked" in q:
        sql = """SELECT sc.rfq_id, r.equipment,
                        SUM(CASE WHEN sc.eligibility='BLOCKED' THEN 1 ELSE 0 END) blocked,
                        COUNT(*) quotes
                 FROM supplier_scores sc JOIN rfqs r ON r.rfq_id = sc.rfq_id
                 GROUP BY sc.rfq_id ORDER BY blocked DESC, sc.rfq_id"""
        rows = db.query(conn, sql, ())
        top = rows[0]
        facts = [f"{top['rfq_id']} ({top['equipment']}) has the most blocked "
                 f"quotations: {top['blocked']} of {top['quotes']}."]
        facts += [f"  - {r['rfq_id']} {r['equipment']}: {r['blocked']}/{r['quotes']} blocked"
                  for r in rows if r["blocked"]]
        return {"facts": facts, "table": rows, "sql": sql.strip()}

    if any(w in q for w in ("all rfq", "every rfq", "list", "which rfq", "what rfq",
                            "how many rfq", "open rfq")):
        sql = """SELECT r.rfq_id, r.equipment, r.quantity, r.budget_per_unit,
                        r.required_delivery_days, r.status,
                        (SELECT COUNT(*) FROM rfq_quotes q WHERE q.rfq_id=r.rfq_id) quotes,
                        (SELECT MAX(decision_score) FROM supplier_scores sc
                          WHERE sc.rfq_id=r.rfq_id) best_score
                 FROM rfqs r ORDER BY r.rfq_id"""
        rows = db.query(conn, sql, ())
        facts = [f"{len(rows)} RFQs on file:"]
        facts += [f"  - {r['rfq_id']} {r['equipment']}: {r['quantity']} units, budget "
                  f"{_inr(r['budget_per_unit'])}/unit, {r['quotes']} quotations"
                  + (f", best score {r['best_score']:.1f}/100" if r["best_score"] else "")
                  for r in rows]
        return {"facts": facts, "table": rows, "sql": sql.strip()}
    return None


def risk_distribution(conn) -> dict:
    sql = """SELECT risk_level, COUNT(*) n, ROUND(AVG(risk_score),1) avg_score
             FROM supplier_risk_predictions GROUP BY risk_level"""
    rows = db.query(conn, sql, ())
    order = {l: i for i, l in enumerate(RISK_LEVELS)}
    rows.sort(key=lambda r: order.get(r["risk_level"], 9))
    total = sum(r["n"] for r in rows)
    facts = [f"Predicted risk across all {total} suppliers: " + ", ".join(
        f"{r['risk_level']} {r['n']}" for r in rows) + "."]
    facts += [f"  - {r['risk_level']}: {r['n']} suppliers, average score {r['avg_score']}/100"
              for r in rows]
    return {"facts": facts, "table": rows, "sql": sql.strip()}
