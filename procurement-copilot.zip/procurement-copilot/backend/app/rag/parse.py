"""PDF ingestion, cleaning and section-aware chunking for the buyer knowledge base.

Scope is enforced here, not merely documented: `discover_documents()` only ever
returns the three permitted document types (policy POL-MED-001 §9).  Supplier
contracts do not exist in this system and cannot enter the index.

Chunking is section-aware rather than fixed-width.  The buyer documents are
numbered clause documents ("4. Risk thresholds", "§7 Pricing..."), and a clause
is the unit a procurement officer cites, so clause boundaries make far better
retrieval units - and far better citations - than an arbitrary character window.
Long clauses are split further with overlap to respect the size budget.
"""
from __future__ import annotations

import re
from pathlib import Path

from .. import config

try:
    from pypdf import PdfReader
    HAVE_PYPDF = True
except Exception:                            # pragma: no cover
    try:
        from PyPDF2 import PdfReader          # type: ignore
        HAVE_PYPDF = True
    except Exception:
        HAVE_PYPDF = False


SECTION_RE = re.compile(r"^\s*(\d{1,2})\.\s+([A-Z][^\n]{2,80})\s*$")


def clean_text(text: str) -> str:
    text = text.replace("­", "").replace("\xa0", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    # De-hyphenate words broken across a line break.
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    return text.strip()


def read_pdf_pages(path: Path) -> list[str]:
    if not HAVE_PYPDF:
        raise RuntimeError(
            "pypdf is required to parse the buyer knowledge base "
            "(pip install pypdf).")
    reader = PdfReader(str(path))
    return [clean_text(p.extract_text() or "") for p in reader.pages]


def discover_documents() -> list[dict]:
    """Return the metadata records for every permitted knowledge-base document."""
    docs: list[dict] = []
    if config.POLICY_PDF.exists():
        docs.append({
            "document_type": "buyer_policy",
            "document_id": "POL-MED-001",
            "title": "Buyer Procurement Policy - Medical Equipment",
            "short_title": "Procurement Policy",
            "path": config.POLICY_PDF,
            "rfq_id": None,
            "buyer_id": config.BUYER_ID,
        })
    if config.CONTRACT_PDF.exists():
        docs.append({
            "document_type": "buyer_master_contract",
            "document_id": "CON-MED-001",
            "title": "Buyer Master Procurement Contract",
            "short_title": "Master Contract",
            "path": config.CONTRACT_PDF,
            "rfq_id": None,
            "buyer_id": config.BUYER_ID,
        })
    if config.RFQ_PDF_DIR.exists():
        for p in sorted(config.RFQ_PDF_DIR.glob("RFQ-*.pdf")):
            rid = p.stem
            docs.append({
                "document_type": "buyer_rfq",
                "document_id": rid,
                "title": f"{rid} - Request for Quotation",
                "short_title": rid,
                "path": p,
                "rfq_id": rid,
                "buyer_id": config.BUYER_ID,
            })

    bad = [d for d in docs if d["document_type"] not in config.ALLOWED_RAG_DOC_TYPES]
    if bad:
        raise RuntimeError(f"Disallowed document types in knowledge base: {bad}")
    return docs


def split_rfq_page(page_text: str) -> list[tuple[str, str]]:
    """RFQs are `Label: value` sheets, not numbered clause documents.

    They are split into the requirement block and the evaluation note so that a
    citation points at a meaningful part of the RFQ rather than "page 1".
    """
    lines = [l for l in page_text.split("\n") if l.strip()]
    req, note, in_note = [], [], False
    for line in lines:
        if line.lower().startswith("evaluation note"):
            in_note = True
            continue
        (note if in_note else req).append(line.strip())
    out = []
    if req:
        out.append(("Requirement details", "\n".join(req)))
    if note:
        out.append(("Evaluation note", " ".join(note)))
    return out


def split_sections(page_text: str) -> list[tuple[str, str]]:
    """Split one page into (section_heading, body) pairs on numbered clauses."""
    lines = page_text.split("\n")
    sections: list[tuple[str, list[str]]] = []
    current = ("Preamble", [])
    for line in lines:
        m = SECTION_RE.match(line)
        if m:
            if current[1]:
                sections.append(current)
            current = (f"{m.group(1)}. {m.group(2).strip()}", [])
        else:
            current[1].append(line)
    if current[1]:
        sections.append(current)
    return [(h, clean_text("\n".join(b))) for h, b in sections if clean_text("\n".join(b))]


def _window(text: str, size: int, overlap: int) -> list[str]:
    if len(text) <= size:
        return [text]
    out, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):                      # prefer a sentence boundary
            dot = text.rfind(". ", start + size // 2, end)
            if dot != -1:
                end = dot + 1
        out.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return [c for c in out if c]


def chunk_documents(docs: list[dict] | None = None) -> list[dict]:
    """Produce the full chunk list with retrieval metadata attached."""
    docs = docs or discover_documents()
    chunks: list[dict] = []
    for d in docs:
        pages = read_pdf_pages(d["path"])
        for pno, page in enumerate(pages, start=1):
            if not page:
                continue
            splitter = (split_rfq_page if d["document_type"] == "buyer_rfq"
                        else split_sections)
            for heading, body in splitter(page):
                for i, piece in enumerate(_window(body,
                                                  config.RAG_CHUNK_TARGET_CHARS,
                                                  config.RAG_CHUNK_OVERLAP_CHARS)):
                    chunks.append({
                        "chunk_id": f"{d['document_id']}#p{pno}#{len(chunks)}",
                        "document_type": d["document_type"],
                        "document_id": d["document_id"],
                        "document_title": d["title"],
                        "short_title": d["short_title"],
                        "rfq_id": d["rfq_id"],
                        "buyer_id": d["buyer_id"],
                        "page": pno,
                        "section": heading,
                        "part": i + 1,
                        "source_file": d["path"].name,
                        "text": piece,
                    })
    return chunks
