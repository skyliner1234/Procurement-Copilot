"""Retrieval + citation formatting on top of the hybrid index.

Every retrieved passage is returned with the metadata a procurement auditor
needs: document type, document id, page, clause/section heading and the exact
supporting sentence.  Nothing reaches the Copilot without a citation attached.
"""
from __future__ import annotations

import re

from .. import config
from . import index as index_mod


def _label(chunk: dict) -> str:
    if chunk["document_type"] == "buyer_policy":
        return f"Procurement Policy {chunk['document_id']} - {chunk['section']} (p.{chunk['page']})"
    if chunk["document_type"] == "buyer_master_contract":
        return f"Master Contract {chunk['document_id']} - {chunk['section']} (p.{chunk['page']})"
    return f"{chunk['document_id']} - {chunk['section']} (p.{chunk['page']})"


def _units(text: str) -> list[str]:
    """Candidate evidence units: sentences, and - for RFQ sheets - label lines.

    Splitting on newlines as well as sentence terminators matters because the RFQ
    documents are `Label: value` sheets with no full stops; without it the quoted
    evidence for "what warranty does RFQ-102 require" would be the whole sheet.
    """
    out: list[str] = []
    for line in text.split("\n"):
        line = line.strip()
        if not line:
            continue
        # Split on sentence terminators only - never on ':', which would tear a
        # "Warranty requirement: 24 months" line away from its value.
        for s in re.split(r"(?<=[.;])\s+(?=[A-Z0-9])", line):
            s = re.sub(r"\s+", " ", s).strip()
            if s:
                out.append(s)
    return out


def _best_sentence(text: str, query: str, document_id: str | None = None) -> str:
    """Pick the single most query-relevant unit as the quoted evidence.

    Two corrections make this behave like a human picking a supporting line:

    * Overlap is IDF-weighted, so common connective words do not decide it.
    * Tokens belonging to the document's own identifier are ignored.  The
      document a passage came from is already known; "RFQ ID: RFQ-102" is not
      evidence about warranty just because the question said "RFQ-102".
    """
    units = _units(text)
    if not units:
        return re.sub(r"\s+", " ", text)[:240]
    try:
        idf = index_mod.get_index().idf
    except Exception:
        idf = {}
    identity = set(index_mod.tokenize(document_id or ""))
    qt = set(index_mod.expand_query(index_mod.tokenize(query))) - identity

    best, best_score = units[0], -1.0
    for s in units:
        st = set(index_mod.tokenize(s))
        if not st:
            continue
        gain = sum(idf.get(w, 1.0) for w in (qt & st))
        score = gain / (len(st) ** 0.5)
        if len(st) < 3:                       # a bare label carries little evidence
            score *= 0.5
        if score > best_score:
            best, best_score = s, score
    return best[:400]


def retrieve(query: str, k: int | None = None, filters: dict | None = None
             ) -> list[dict]:
    """Return top-k cited passages for a query."""
    try:
        idx = index_mod.get_index()
    except Exception as exc:                    # graceful degradation
        return [{"error": f"Knowledge base unavailable: {exc}"}]

    hits = idx.search(query, k or config.RAG_TOP_K, filters)
    out = []
    for h in hits:
        out.append({
            "citation": _label(h),
            "document_type": h["document_type"],
            "document_id": h["document_id"],
            "document_title": h["document_title"],
            "short_title": h["short_title"],
            "rfq_id": h["rfq_id"],
            "page": h["page"],
            "section": h["section"],
            "source_file": h["source_file"],
            "evidence": _best_sentence(h["text"], query, h["document_id"]),
            "passage": h["text"],
            "score": h["score"],
        })
    return out


def retrieve_for_rfq(rfq_id: str, query: str, k: int | None = None) -> list[dict]:
    """Retrieve across policy + master contract + *this* RFQ only.

    Prevents a different RFQ's clauses being cited as evidence for this award.
    """
    try:
        idx = index_mod.get_index()
    except Exception as exc:
        return [{"error": f"Knowledge base unavailable: {exc}"}]

    k = k or config.RAG_TOP_K
    hits = idx.search(query, k * 3)
    keep = [h for h in hits
            if h["document_type"] != "buyer_rfq" or h["rfq_id"] == rfq_id]

    # Guarantee the RFQ itself is represented in the evidence set.
    if not any(h["document_type"] == "buyer_rfq" for h in keep):
        rfq_hits = idx.search(query, 2, {"document_type": "buyer_rfq",
                                         "rfq_id": rfq_id})
        keep = rfq_hits + keep

    seen, dedup = set(), []
    for h in keep:
        if h["chunk_id"] in seen:
            continue
        seen.add(h["chunk_id"])
        dedup.append(h)

    out = []
    for h in dedup[:k]:
        out.append({
            "citation": _label(h),
            "document_type": h["document_type"],
            "document_id": h["document_id"],
            "document_title": h["document_title"],
            "short_title": h["short_title"],
            "rfq_id": h["rfq_id"],
            "page": h["page"],
            "section": h["section"],
            "source_file": h["source_file"],
            "evidence": _best_sentence(h["text"], query, h["document_id"]),
            "passage": h["text"],
            "score": h["score"],
        })
    return out


def clause_lookup(document_id: str, needle: str) -> dict | None:
    """Fetch a specific clause by document + text fragment (used by flag links)."""
    idx = index_mod.get_index()
    needle_l = needle.lower()
    for c in idx.chunks:
        if c["document_id"] == document_id and needle_l in c["text"].lower():
            return {"citation": _label(c), "section": c["section"],
                    "page": c["page"], "document_id": c["document_id"],
                    "evidence": _best_sentence(c["text"], needle, c["document_id"]),
                    "passage": c["text"]}
    return None


def knowledge_base_manifest() -> dict:
    """What is actually in the index - shown on the Contracts & Policy screen."""
    idx = index_mod.get_index()
    docs: dict[str, dict] = {}
    for c in idx.chunks:
        d = docs.setdefault(c["document_id"], {
            "document_id": c["document_id"],
            "document_type": c["document_type"],
            "title": c["document_title"],
            "source_file": c["source_file"],
            "pages": 0, "chunks": 0, "sections": [],
        })
        d["chunks"] += 1
        d["pages"] = max(d["pages"], c["page"])
        if c["section"] not in d["sections"]:
            d["sections"].append(c["section"])
    return {
        "retriever": idx.retriever_name(),
        "embedding_model": config.HF_EMBED_MODEL if idx.embeddings else None,
        "total_chunks": idx.N,
        "allowed_document_types": sorted(config.ALLOWED_RAG_DOC_TYPES),
        "excluded": "Supplier contracts are out of scope and are never indexed "
                    "(policy POL-MED-001 §9).",
        "documents": sorted(docs.values(),
                            key=lambda d: (d["document_type"], d["document_id"])),
    }
