"""Vector / lexical index over the buyer knowledge base.

Retrieval design decision (master prompt §2 permits a justified alternative)
---------------------------------------------------------------------------
The specification suggested Chroma or FAISS with a neural embedding model.  This
implementation uses a **hybrid BM25 + TF-IDF-cosine retriever** as the default
instead, for three reasons specific to this corpus:

1. Size.  The knowledge base is 17 short, highly structured documents (~90
   clause-level chunks).  Approximate-nearest-neighbour indexing solves a
   problem - scaling past exact search - that does not exist at this scale;
   exact scoring over ~90 chunks is instant.
2. Vocabulary.  The decisive queries are regulatory and contractual terms with
   exact surface forms: "510(k)", "ISO 13485", "consent decree", "RFQ-102",
   "warranty months".  Lexical scoring matches these exactly, whereas a general
   embedding model routinely conflates near-synonyms - which in a compliance
   setting means citing the wrong clause.
3. Demo reliability.  No model download, no GPU, no service to start, identical
   results on every machine and every run.

Dense retrieval is not ruled out - it is made pluggable.  `EmbeddingBackend`
defines the interface; supply any encoder (sentence-transformers, an API
embedder) and `HybridIndex` will fuse its cosine scores into the ranking via
reciprocal rank fusion.  Swapping in Chroma/FAISS later touches this file only.
"""
from __future__ import annotations

import json
import math
import re
import urllib.request
from collections import Counter

from .. import config
from . import parse

TOKEN_RE = re.compile(r"[a-z0-9]+(?:\([a-z0-9]+\))?", re.I)

STOPWORDS = {
    "the", "a", "an", "and", "or", "of", "to", "in", "for", "on", "is", "are",
    "be", "by", "with", "as", "at", "this", "that", "it", "from", "may", "must",
    "shall", "will", "not", "any", "all", "which", "where", "when", "than",
    "such", "these", "those", "their", "its", "we", "you",
}

# Domain synonyms: expands a query so that a buyer's phrasing reaches the clause
# that uses the formal term.  Deliberately small and auditable.
SYNONYMS = {
    "certification": ["certified", "clearance", "registration", "accreditation"],
    "clearance": ["510", "510(k)", "certification", "cleared"],
    "510": ["510(k)", "clearance"],
    "warranty": ["warranties", "guarantee", "months"],
    "delivery": ["deliver", "lead", "time", "days", "schedule"],
    "late": ["delay", "delays", "disruption", "overdue"],
    "risk": ["risks", "critical", "high", "disruption", "threshold", "thresholds"],
    "approve": ["approval", "approved", "award", "authority", "approver"],
    "approval": ["approve", "award", "authority", "human"],
    "price": ["pricing", "cost", "commercial", "lowest", "evaluated"],
    "quality": ["failure", "defect", "conformance", "non-conforming", "rejection"],
    "safety": ["patient", "clinical", "adverse"],
    "audit": ["records", "retain", "evidence"],
    "supplier": ["suppliers", "vendor", "manufacturer"],
    "compliance": ["regulatory", "certification", "compliant"],
    "sla": ["service", "response", "acknowledgement", "hours"],
    "score": ["scoring", "weight", "weights", "evaluation", "decision"],
    "consent": ["suspend", "suspension", "compliance", "concerns", "terminate"],
    "decree": ["suspend", "suspension", "compliance", "concerns"],
    "suspended": ["suspend", "suspension", "terminate", "concerns"],
    "recall": ["recalls", "safety", "non-conforming", "corrective"],
    "budget": ["price", "pricing", "cost", "commercial"],
    "quantity": ["units", "volume"],
}


def tokenize(text: str) -> list[str]:
    return [t.lower() for t in TOKEN_RE.findall(text or "")
            if t.lower() not in STOPWORDS and len(t) > 1]


def expand_query(tokens: list[str]) -> list[str]:
    out = list(tokens)
    for t in tokens:
        out.extend(SYNONYMS.get(t, []))
    return out


class EmbeddingBackend:
    """Interface for an optional dense retriever.

    Implement `encode(list[str]) -> list[list[float]]` and pass an instance to
    HybridIndex to add semantic recall on top of the lexical signal.
    """

    name = "none"

    def encode(self, texts: list[str]) -> list[list[float]]:  # pragma: no cover
        raise NotImplementedError


class SentenceTransformerBackend(EmbeddingBackend):  # pragma: no cover
    """Local embeddings, if sentence-transformers happens to be installed."""

    name = "sentence-transformers"

    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)

    def encode(self, texts):
        return self.model.encode(texts, normalize_embeddings=True).tolist()


def _l2_normalise(vec: list[float]) -> list[float]:
    """Cosine similarity is a dot product only for unit vectors."""
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _mean_pool(value):
    """Reduce whatever the endpoint returns to one vector per input.

    Feature-extraction may return a sentence vector (list[float]) or per-token
    vectors (list[list[float]]) depending on the model; mean-pooling the token
    case is the standard reduction and leaves the sentence case untouched.
    """
    if value and isinstance(value[0], (int, float)):
        return list(value)
    if value and isinstance(value[0], list) and value[0] and isinstance(value[0][0], (int, float)):
        cols = len(value[0])
        return [sum(row[i] for row in value) / len(value) for i in range(cols)]
    raise ValueError("unrecognised embedding response shape")


class HuggingFaceEmbeddingBackend(EmbeddingBackend):   # pragma: no cover - network
    """Embeddings via the Hugging Face feature-extraction endpoint.

    Uses only the standard library, so no extra dependency is introduced. The
    constructor does no network I/O - it only checks that a key exists - so
    building the index stays cheap when the backend ends up unused.
    """

    name = "huggingface"

    def __init__(self, model: str | None = None, api_key: str | None = None):
        self.model = model or config.HF_EMBED_MODEL
        self.api_key = api_key if api_key is not None else config.HF_API_KEY
        if not self.api_key:
            raise RuntimeError("HF_API_KEY is required for Hugging Face embeddings")
        self.url = (f"{config.HF_ROUTER}/hf-inference/models/{self.model}"
                    f"/pipeline/feature-extraction")

    def _post(self, batch: list[str]) -> list[list[float]]:
        req = urllib.request.Request(
            self.url,
            data=json.dumps({"inputs": batch,
                             "options": {"wait_for_model": True}}).encode(),
            headers={"content-type": "application/json",
                     "authorization": f"Bearer {self.api_key}"})
        with urllib.request.urlopen(req, timeout=config.HF_TIMEOUT) as r:
            payload = json.loads(r.read())
        if not isinstance(payload, list):
            raise ValueError(f"unexpected embedding response: {str(payload)[:200]}")
        return [_l2_normalise(_mean_pool(v)) for v in payload]

    def encode(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        size = max(1, config.HF_EMBED_BATCH)
        for i in range(0, len(texts), size):
            out.extend(self._post(texts[i:i + size]))
        return out


def try_dense_backend() -> EmbeddingBackend | None:
    """Hugging Face first (one key enables it), then a local model, else none."""
    if config.HF_API_KEY:
        try:                                   # pragma: no cover - env dependent
            return HuggingFaceEmbeddingBackend()
        except Exception:
            pass
    try:                                       # pragma: no cover - env dependent
        return SentenceTransformerBackend()
    except Exception:
        return None


class HybridIndex:
    """Exact BM25 + TF-IDF cosine over the clause chunks, optionally fused with
    dense cosine similarity when an embedding backend is supplied."""

    K1 = 1.5
    B = 0.75

    def __init__(self, chunks: list[dict], dense: EmbeddingBackend | None = None,
                 embeddings: list[list[float]] | None = None):
        self.chunks = chunks
        self.dense = dense
        self.tokens = [tokenize(c["text"] + " " + c["section"] + " "
                                + c["document_title"]) for c in chunks]
        self.tf = [Counter(t) for t in self.tokens]
        self.lengths = [len(t) for t in self.tokens]
        self.avg_len = (sum(self.lengths) / len(self.lengths)) if self.lengths else 1.0
        self.N = len(chunks)
        df = Counter()
        for t in self.tokens:
            df.update(set(t))
        self.df = df
        self.idf = {w: math.log(1.0 + (self.N - c + 0.5) / (c + 0.5))
                    for w, c in df.items()}
        self.norms = []
        for tf in self.tf:
            s = math.sqrt(sum((v * self.idf.get(w, 0.0)) ** 2 for w, v in tf.items()))
            self.norms.append(s or 1.0)
        # Chunk vectors are computed once at build time and cached in the index
        # file, so starting the server never triggers an embedding API call.
        # Only the query is embedded live, and a failure there simply drops the
        # dense signal and leaves the lexical ranking intact.
        self.embeddings = embeddings
        self.embedding_error = None
        if self.embeddings is None and dense is not None:
            try:                               # pragma: no cover - network
                self.embeddings = dense.encode([c["text"] for c in chunks])
            except Exception as exc:           # pragma: no cover - network
                self.embeddings = None
                self.embedding_error = f"{type(exc).__name__}: {exc}"

    # ------------------------------------------------------------- scoring
    def _bm25(self, q: list[str]) -> list[float]:
        out = [0.0] * self.N
        for i, tf in enumerate(self.tf):
            dl = self.lengths[i] or 1
            s = 0.0
            for w in q:
                f = tf.get(w, 0)
                if not f:
                    continue
                idf = self.idf.get(w, 0.0)
                s += idf * f * (self.K1 + 1) / (f + self.K1 * (1 - self.B + self.B * dl / self.avg_len))
            out[i] = s
        return out

    def _tfidf_cosine(self, q: list[str]) -> list[float]:
        qtf = Counter(q)
        qvec = {w: v * self.idf.get(w, 0.0) for w, v in qtf.items()}
        qnorm = math.sqrt(sum(v * v for v in qvec.values())) or 1.0
        out = []
        for i, tf in enumerate(self.tf):
            dot = sum(qv * tf.get(w, 0) * self.idf.get(w, 0.0)
                      for w, qv in qvec.items())
            out.append(dot / (qnorm * self.norms[i]))
        return out

    def _dense_cosine(self, query: str) -> list[float] | None:  # pragma: no cover
        if self.embeddings is None or self.dense is None:
            return None
        try:
            qv = self.dense.encode([query])[0]
        except Exception:
            return None
        out = []
        for e in self.embeddings:
            out.append(sum(a * b for a, b in zip(qv, e)))
        return out

    @staticmethod
    def _rrf(rankings: list[list[int]], n: int, k: int = 60,
             weights: list[float] | None = None) -> list[float]:
        """Weighted reciprocal rank fusion.

        Plain RRF gives every ranking an equal vote, which is wrong here: the
        dense signal would get a third of the say and could displace the exact
        clause that lexical matching found.  On a regulatory corpus where the
        decisive terms are exact surface forms ("510(k)", "consent decree"),
        embeddings should add recall, never override precision - so the dense
        ranking is down-weighted (config.DENSE_FUSION_WEIGHT) and acts as a
        tie-breaker among candidates the lexical signals already rate highly.
        """
        weights = weights or [1.0] * len(rankings)
        score = [0.0] * n
        for ranking, w in zip(rankings, weights):
            for pos, idx in enumerate(ranking):
                score[idx] += w / (k + pos + 1)
        return score

    # ------------------------------------------------------------- search
    def search(self, query: str, k: int = None, filters: dict | None = None
               ) -> list[dict]:
        k = k or config.RAG_TOP_K
        q = expand_query(tokenize(query))
        if not q:
            return []

        bm = self._bm25(q)
        tf = self._tfidf_cosine(q)
        rankings = [sorted(range(self.N), key=lambda i: -bm[i]),
                    sorted(range(self.N), key=lambda i: -tf[i])]
        weights = [1.0, 1.0]
        dn = self._dense_cosine(query)
        if dn is not None:
            rankings.append(sorted(range(self.N), key=lambda i: -dn[i]))
            weights.append(config.DENSE_FUSION_WEIGHT)
        fused = self._rrf(rankings, self.N, weights=weights)

        # Metadata boosts: an RFQ named in the query, and a requested doc type.
        for i, c in enumerate(self.chunks):
            if filters:
                if filters.get("document_type") and c["document_type"] != filters["document_type"]:
                    fused[i] = -1.0
                    continue
                if filters.get("rfq_id") and c["document_type"] == "buyer_rfq" \
                        and c["rfq_id"] != filters["rfq_id"]:
                    fused[i] = -1.0
                    continue
            if c["rfq_id"] and c["rfq_id"].lower() in query.lower():
                fused[i] += 0.05

        order = sorted(range(self.N), key=lambda i: -fused[i])
        out = []
        for i in order[:k]:
            if fused[i] <= 0 or bm[i] <= 0 and tf[i] <= 0:
                continue
            c = self.chunks[i]
            out.append({
                **{key: c[key] for key in
                   ("chunk_id", "document_type", "document_id", "document_title",
                    "short_title", "rfq_id", "page", "section", "source_file", "text")},
                "score": round(float(fused[i]), 5),
                "bm25": round(float(bm[i]), 4),
                "tfidf_cosine": round(float(tf[i]), 4),
            })
        return out

    # ------------------------------------------------------------- persist
    def retriever_name(self) -> str:
        base = "hybrid-bm25+tfidf"
        if self.embeddings:
            return f"{base}+dense({self.dense.name if self.dense else 'cached'})"
        return base

    def to_dict(self) -> dict:
        out = {"chunks": self.chunks,
               "retriever": self.retriever_name(),
               "n_chunks": self.N}
        if self.embeddings:
            out["embedding_model"] = config.HF_EMBED_MODEL
            out["embeddings"] = [[round(float(v), 6) for v in vec]
                                 for vec in self.embeddings]
        return out

    def save(self, path=None) -> None:
        path = path or config.RAG_INDEX
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_dict(), fh, indent=1)


_INDEX: HybridIndex | None = None


def build_index(verbose: bool = True, use_dense: bool | None = None) -> HybridIndex:
    """Parse, chunk and index the buyer documents.

    `use_dense` defaults to config.USE_DENSE_RETRIEVAL, which is on whenever a
    Hugging Face key is configured.
    """
    global _INDEX
    if use_dense is None:
        use_dense = config.USE_DENSE_RETRIEVAL
    chunks = parse.chunk_documents()
    dense = try_dense_backend() if use_dense else None
    idx = HybridIndex(chunks, dense)
    idx.save()
    _INDEX = idx
    if verbose:
        by_type: dict[str, int] = {}
        for c in chunks:
            by_type[c["document_type"]] = by_type.get(c["document_type"], 0) + 1
        print(f"  indexed {len(chunks)} chunks ({idx.retriever_name()}): {by_type}")
        if use_dense and idx.embeddings:
            print(f"  embedded with {config.HF_EMBED_MODEL} "
                  f"({len(idx.embeddings[0])} dimensions, cached in the index)")
        elif use_dense:
            print(f"  dense retrieval requested but unavailable "
                  f"({idx.embedding_error or 'no backend'}); using lexical only")
    return idx


def get_index() -> HybridIndex:
    """Load the persisted index, rebuilding from the PDFs if it is missing.

    Cached chunk vectors are restored from disk; the dense backend is only
    reattached so that *queries* can be embedded at search time.
    """
    global _INDEX
    if _INDEX is not None:
        return _INDEX
    try:
        with open(config.RAG_INDEX, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        embeddings = data.get("embeddings")
        dense = try_dense_backend() if embeddings else None
        _INDEX = HybridIndex(data["chunks"], dense, embeddings)
        return _INDEX
    except Exception:
        return build_index(verbose=False)
