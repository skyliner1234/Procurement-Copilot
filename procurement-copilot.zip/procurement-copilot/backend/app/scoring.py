"""Medical procurement decision-score engine.

Deterministic and fully auditable - no model inference happens here.  The ML risk
prediction is a *separate* quantity that the recommendation engine consumes
alongside this score; the two are never blended into one number, because a buyer
must be able to see "good commercial offer, but risky supplier".

    decision_score = 0.25*price + 0.20*delivery + 0.20*historical
                   + 0.15*quality + 0.15*compliance + 0.05*resilience

Weights come from config.active_weights() (backed by data/scoring_spec.json) so
they are configurable without code changes, and the engine is industry-agnostic:
swapping the sub-score functions is enough to retarget it.

Price is scored *relative to the competing quotations on the same RFQ*, which is
why scoring is always performed per-RFQ over the full quote set rather than per
supplier in isolation.
"""
from __future__ import annotations

import json
import statistics
from datetime import datetime, timezone

from . import config, db, features


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clamp(x: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, x))


# ---------------------------------------------------------------------------
# Price
# ---------------------------------------------------------------------------

def price_scores(quotes: list[dict], rfq: dict) -> dict[str, dict]:
    """Relative price scoring across one RFQ's quotations.

    * Cheapest compliant-looking quote anchors the top of the scale, the most
      expensive the bottom, so the score is genuinely comparative.
    * A quote below `SUSPICIOUS_LOW_BID_RATIO` x peer median stops earning extra
      points and is flagged: an implausibly low bid on medical equipment is a
      risk signal, not a bargain (master prompt section 16).
    * Quotes above the RFQ budget are flagged separately.
    """
    prices = [float(q["quoted_unit_price"]) for q in quotes
              if q.get("quoted_unit_price")]
    if not prices:
        return {}
    median = statistics.median(prices)
    lo, hi = min(prices), max(prices)
    budget = float(rfq.get("budget_per_unit") or 0) or None
    floor = median * config.SUSPICIOUS_LOW_BID_RATIO

    out: dict[str, dict] = {}
    for q in quotes:
        price = float(q.get("quoted_unit_price") or 0)
        qty = float(rfq.get("quantity") or 1)
        flags: list[dict] = []

        # A suspiciously low bid is treated as if it were priced at the floor:
        # it keeps a strong (but not unbounded) score and raises a review flag.
        effective = max(price, floor)
        if hi > lo:
            score = (hi - effective) / (hi - lo) * 100.0
        else:
            score = 100.0
        score = _clamp(score)

        if price < floor:
            flags.append({
                "code": "SUSPICIOUS_LOW_BID", "severity": "REVIEW",
                "message": (f"Quoted INR {price:,.0f} is {1 - price / median:.0%} below the "
                            f"peer median of INR {median:,.0f} for this RFQ."),
                "clause": "CON-MED-001 §7 - lowest price alone does not guarantee award",
            })
        if budget and price > budget:
            flags.append({
                "code": "OVER_BUDGET", "severity": "REVIEW",
                "message": (f"Quoted INR {price:,.0f} exceeds the RFQ budget of "
                            f"INR {budget:,.0f} per unit by {price / budget - 1:.0%}."),
                "clause": "CON-MED-001 §7 - commercial evaluation against RFQ terms",
            })

        out[q["supplier_id"]] = {
            "score": round(score, 2),
            "unit_price": price,
            "total_evaluated_cost": round(price * qty, 2),
            "peer_median": round(median, 2),
            "vs_median_pct": round((price / median - 1) * 100.0, 1) if median else 0.0,
            "cheapest_in_rfq": abs(price - lo) < 1e-9,
            "flags": flags,
        }
    return out


# ---------------------------------------------------------------------------
# Eligibility routing (policy hard rules)
# ---------------------------------------------------------------------------

def eligibility(flags: list[dict], risk_level: str) -> tuple[str, list[str]]:
    """Route a supplier to AUTO_APPROVABLE / REVIEW_REQUIRED / BLOCKED.

    Policy POL-MED-001 §4 and §7, contract CON-MED-001 §8 and §11.
    Regulatory failure is routed on its own merits and is never offset by a
    strong price or delivery score.
    """
    reasons: list[str] = []
    blocking = [f for f in flags if f.get("severity") == "BLOCKING"]
    review = [f for f in flags if f.get("severity") == "REVIEW"]

    if blocking:
        reasons += [f["message"] for f in blocking]
        return "BLOCKED", reasons

    if risk_level == "CRITICAL":
        reasons.append("Predicted disruption risk is CRITICAL; policy forbids auto-approval.")
        return "BLOCKED", reasons
    if risk_level == "HIGH":
        reasons.append("Predicted disruption risk is HIGH; procurement manager approval required.")
    if review:
        reasons += [f["message"] for f in review]

    return ("REVIEW_REQUIRED" if reasons else "AUTO_APPROVABLE"), reasons


# ---------------------------------------------------------------------------
# Per-RFQ scoring
# ---------------------------------------------------------------------------

def score_rfq(conn, rfq_id: str, weights: dict | None = None,
              persist: bool = True) -> list[dict]:
    """Score every quotation on one RFQ.  Returns rows sorted best-first."""
    w = weights or config.active_weights()
    rfq = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rfq_id,))
    if not rfq:
        raise KeyError(f"Unknown RFQ '{rfq_id}'")

    quotes = db.query(conn, """
        SELECT q.*, s.supplier_name AS master_name
        FROM rfq_quotes q JOIN suppliers s ON s.supplier_id = q.supplier_id
        WHERE q.rfq_id = ? ORDER BY q.supplier_id""", (rfq_id,))
    if not quotes:
        return []

    suppliers = {s["supplier_id"]: s for s in db.query(
        conn, "SELECT * FROM suppliers")}
    risks = {r["supplier_id"]: r for r in db.query(
        conn, "SELECT * FROM supplier_risk_predictions")}

    pscores = price_scores(quotes, rfq)
    rows: list[dict] = []

    for q in quotes:
        sid = q["supplier_id"]
        sup = suppliers.get(sid)
        if not sup:
            continue
        risk = risks.get(sid) or {}
        flags: list[dict] = []

        p = pscores.get(sid, {"score": 50.0, "flags": [], "total_evaluated_cost": 0.0})
        flags += p.get("flags", [])

        d_score, d_parts, d_flags = features.delivery_subscore(sup, q, rfq)
        flags += d_flags

        h_score, h_parts = features.historical_subscore(sup)
        qa_score, qa_parts = features.quality_subscore(sup)

        rfq_ctx = dict(rfq)
        rfq_ctx["_compliance_docs"] = q.get("compliance_docs")
        c_score, c_parts, c_flags = features.compliance_subscore(sup, rfq_ctx)
        flags += c_flags

        r_score, r_parts = features.resilience_subscore(sup)
        flags += features.warranty_sla_flags(q, rfq)

        decision = (p["score"] * w["price"]
                    + d_score * w["delivery"]
                    + h_score * w["historical_performance"]
                    + qa_score * w["quality_reliability"]
                    + c_score * w["regulatory_compliance"]
                    + r_score * w["financial_service_resilience"])
        decision = round(_clamp(decision), 1)

        risk_level = risk.get("risk_level") or "UNKNOWN"
        elig, elig_reasons = eligibility(flags, risk_level)

        rows.append({
            "rfq_id": rfq_id,
            "supplier_id": sid,
            "supplier_name": q.get("supplier_name") or q.get("master_name"),
            "primary_product_category": sup.get("primary_product_category"),
            "quoted_unit_price": q.get("quoted_unit_price"),
            "quoted_delivery_days": q.get("quoted_delivery_days"),
            "warranty_months": q.get("warranty_months"),
            "service_sla_hours": q.get("service_sla_hours"),
            "compliance_docs": q.get("compliance_docs"),
            "total_evaluated_cost": p.get("total_evaluated_cost"),
            "vs_median_pct": p.get("vs_median_pct"),
            "price_score": p["score"],
            "delivery_score": d_score,
            "historical_score": h_score,
            "quality_score": qa_score,
            "compliance_score": c_score,
            "resilience_score": r_score,
            "decision_score": decision,
            "weighted_contributions": {
                "price": round(p["score"] * w["price"], 2),
                "delivery": round(d_score * w["delivery"], 2),
                "historical_performance": round(h_score * w["historical_performance"], 2),
                "quality_reliability": round(qa_score * w["quality_reliability"], 2),
                "regulatory_compliance": round(c_score * w["regulatory_compliance"], 2),
                "financial_service_resilience": round(r_score * w["financial_service_resilience"], 2),
            },
            "subscore_detail": {
                "delivery": d_parts, "historical_performance": h_parts,
                "quality_reliability": qa_parts, "regulatory_compliance": c_parts,
                "financial_service_resilience": r_parts,
            },
            "risk_probability": risk.get("risk_probability"),
            "risk_score": risk.get("risk_score"),
            "risk_level": risk_level,
            "model_confidence": risk.get("model_confidence"),
            "top_drivers": json.loads(risk.get("top_drivers_json") or "[]"),
            "flags": flags,
            "eligibility": elig,
            "eligibility_reasons": elig_reasons,
        })

    # Best-first: decision score, then lower risk, then higher confidence.
    rows.sort(key=lambda r: (-r["decision_score"],
                             r.get("risk_score") if r.get("risk_score") is not None else 100,
                             -(r.get("model_confidence") or 0)))
    for i, r in enumerate(rows, start=1):
        r["rank"] = i

    if persist:
        conn.executemany("""
            INSERT OR REPLACE INTO supplier_scores
              (rfq_id, supplier_id, price_score, delivery_score, historical_score,
               quality_score, compliance_score, resilience_score, decision_score,
               total_evaluated_cost, flags_json, eligibility, computed_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            [(r["rfq_id"], r["supplier_id"], r["price_score"], r["delivery_score"],
              r["historical_score"], r["quality_score"], r["compliance_score"],
              r["resilience_score"], r["decision_score"], r["total_evaluated_cost"],
              json.dumps(r["flags"]), r["eligibility"], _now()) for r in rows])
    return rows


def score_all_rfqs(verbose: bool = True) -> dict[str, int]:
    counts: dict[str, int] = {}
    with db.session() as conn:
        db.init_schema(conn)
        for r in db.query(conn, "SELECT rfq_id FROM rfqs ORDER BY rfq_id"):
            rows = score_rfq(conn, r["rfq_id"])
            counts[r["rfq_id"]] = len(rows)
    if verbose:
        print(f"  scored {sum(counts.values())} quotations across {len(counts)} RFQs")
    return counts


def weight_sensitivity(conn, rfq_id: str) -> list[dict]:
    """Does the winner survive a reweighting?  Used by the recommendation panel.

    Re-scores the RFQ under alternative weightings (price-led, safety-led, equal)
    and reports which supplier tops each.  A recommendation that holds across all
    of them is materially more defensible than one that only wins on the default
    weights.
    """
    scenarios = {
        "policy_default": config.active_weights(),
        "price_led": {"price": 0.45, "delivery": 0.15, "historical_performance": 0.15,
                      "quality_reliability": 0.10, "regulatory_compliance": 0.10,
                      "financial_service_resilience": 0.05},
        "safety_led": {"price": 0.10, "delivery": 0.15, "historical_performance": 0.20,
                       "quality_reliability": 0.25, "regulatory_compliance": 0.25,
                       "financial_service_resilience": 0.05},
        "equal": {k: 1 / 6 for k in config.DECISION_WEIGHTS},
    }
    out = []
    for name, w in scenarios.items():
        rows = score_rfq(conn, rfq_id, weights=w, persist=False)
        eligible = [r for r in rows if r["eligibility"] != "BLOCKED"] or rows
        top = eligible[0]
        out.append({"scenario": name, "winner_id": top["supplier_id"],
                    "winner_name": top["supplier_name"],
                    "score": top["decision_score"]})
    return out
