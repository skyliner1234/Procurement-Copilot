"""Framework-agnostic API handlers.

Each handler is a plain function `(params: dict, body: dict) -> dict`.  Two thin
adapters serve them:

* `backend/api_fastapi.py`  - FastAPI (primary; OpenAPI docs at /docs)
* `backend/serve_stdlib.py` - Python standard library http.server

Keeping the logic here means the two servers can never drift apart, and the whole
API surface is unit-testable without starting either one.

Every handler is defensive: a missing model artefact, an unbuilt index or an
unknown id produces a structured error object, never a stack trace that takes
the dashboard down (master prompt §42).
"""
from __future__ import annotations

import json

from . import audit, config, copilot, db, ingest, recommender, scoring
from .rag import retrieve as rag


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message, self.status = message, status


def _int(v, default=None):
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

def dashboard_summary(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        counts = {
            "active_rfqs": db.query_one(conn,
                "SELECT COUNT(*) c FROM rfqs WHERE LOWER(status)='open'")["c"],
            "total_rfqs": db.query_one(conn, "SELECT COUNT(*) c FROM rfqs")["c"],
            "suppliers": db.query_one(conn, "SELECT COUNT(*) c FROM suppliers")["c"],
            "quotations": db.query_one(conn, "SELECT COUNT(*) c FROM rfq_quotes")["c"],
        }
        dist_rows = db.query(conn, """
            SELECT risk_level, COUNT(*) c FROM supplier_risk_predictions
            GROUP BY risk_level""")
        dist = {r["risk_level"]: r["c"] for r in dist_rows}
        for lvl in ("LOW", "MEDIUM", "HIGH", "CRITICAL"):
            dist.setdefault(lvl, 0)
        counts["high_risk_suppliers"] = dist["HIGH"] + dist["CRITICAL"]

        pending = audit.pending_approvals(conn)
        counts["pending_approval"] = len(pending)

        recent_rfqs = db.query(conn, """
            SELECT r.rfq_id, r.equipment, r.quantity, r.budget_per_unit,
                   r.required_delivery_days, r.status, r.issue_date,
                   (SELECT COUNT(*) FROM rfq_quotes q WHERE q.rfq_id = r.rfq_id) quotes
            FROM rfqs r ORDER BY r.issue_date DESC, r.rfq_id DESC LIMIT 6""")

        recs = db.query(conn, """
            SELECT rc.rfq_id, rc.supplier_id, s.supplier_name, rc.decision_score,
                   rc.risk_level, rc.risk_score, rc.model_confidence, rc.outcome,
                   rc.created_at, q.equipment
            FROM recommendations rc
            JOIN suppliers s ON s.supplier_id = rc.supplier_id
            JOIN rfqs q ON q.rfq_id = rc.rfq_id
            WHERE rc.recommendation_id IN (
                SELECT MAX(recommendation_id) FROM recommendations GROUP BY rfq_id)
            ORDER BY rc.created_at DESC LIMIT 6""")

        top_risk = db.query(conn, """
            SELECT p.supplier_id, s.supplier_name, s.primary_product_category,
                   p.risk_score, p.risk_level, p.risk_probability, p.model_confidence
            FROM supplier_risk_predictions p
            JOIN suppliers s ON s.supplier_id = p.supplier_id
            ORDER BY p.risk_score DESC LIMIT 6""")

    return {
        "buyer": buyer(params, body),
        "counts": counts,
        "risk_distribution": dist,
        "recent_rfqs": recent_rfqs,
        "recent_recommendations": recs,
        "pending_approvals": pending[:6],
        "highest_risk_suppliers": top_risk,
        "model": model_info(params, body),
        "default_rfq": config.DEFAULT_RFQ,
        "golden_path_rfqs": config.GOLDEN_PATH_RFQS,
        "copilot_suggestions": copilot.SUGGESTIONS,
        "disclaimer": config.PROTOTYPE_BANNER,
    }


def buyer(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        row = db.query_one(conn, "SELECT * FROM buyers LIMIT 1")
    return row or {"buyer_id": config.BUYER_ID, "buyer_name": "Buyer"}


def model_info(params, body) -> dict:
    try:
        with open(config.METRICS_ARTIFACT, "r", encoding="utf-8") as fh:
            report = json.load(fh)
    except Exception:
        return {"available": False,
                "message": "Model has not been trained yet - run scripts/build_all.py."}
    return {
        "available": True,
        "selected_model": report.get("selected_model_name"),
        "selection_rule": report.get("selection_rule"),
        "prediction_basis": report.get("prediction_basis"),
        "explainability_method": report.get("explainability_method"),
        "cv_design": report.get("cv_design"),
        "n_samples": report.get("n_samples"),
        "n_features": report.get("n_features"),
        "positive_rate": report.get("positive_rate"),
        "data_note": report.get("data_note"),
        "models": {k: v["metrics"] for k, v in report.get("models", {}).items()},
        "model_names": {k: v["display_name"] for k, v in report.get("models", {}).items()},
        "backends": {k: v.get("backend") for k, v in report.get("models", {}).items()},
        "global_feature_importance": report.get("global_feature_importance", [])[:10],
        "limitations": report.get("limitations", []),
        "compute_backend": report.get("compute_backend", {}),
    }


def model_evaluation(params, body) -> dict:
    try:
        with open(config.METRICS_ARTIFACT, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception as exc:
        raise ApiError(f"Evaluation report unavailable: {exc}", 503)


# --------------------------------------------------------------------------
# RFQs
# --------------------------------------------------------------------------

def list_rfqs(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        rows = db.query(conn, """
            SELECT r.*,
                   (SELECT COUNT(*) FROM rfq_quotes q WHERE q.rfq_id = r.rfq_id) quotes,
                   (SELECT MAX(decision_score) FROM supplier_scores s
                     WHERE s.rfq_id = r.rfq_id) best_score
            FROM rfqs r ORDER BY r.rfq_id""")
    return {"rfqs": rows, "count": len(rows)}


def get_rfq(params, body) -> dict:
    rid = params.get("rfq_id")
    with db.session() as conn:
        db.init_schema(conn)
        row = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rid,))
        if not row:
            raise ApiError(f"RFQ '{rid}' not found", 404)
        row["quotes"] = db.query(conn,
            "SELECT * FROM rfq_quotes WHERE rfq_id = ? ORDER BY supplier_id", (rid,))
    row["documents"] = [d for d in rag.knowledge_base_manifest()["documents"]
                        if d["document_id"] == rid]
    return row


def rfq_suppliers(params, body) -> dict:
    rid = params.get("rfq_id")
    with db.session() as conn:
        db.init_schema(conn)
        try:
            rows = scoring.score_rfq(conn, rid)
        except KeyError:
            raise ApiError(f"RFQ '{rid}' not found", 404)
        rfq = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rid,))
    return {"rfq": rfq, "suppliers": rows, "count": len(rows),
            "weights": config.active_weights(),
            "weight_labels": config.WEIGHT_LABELS}


def rfq_recommendation(params, body) -> dict:
    rid = params.get("rfq_id")
    with db.session() as conn:
        db.init_schema(conn)
        try:
            return recommender.recommend(conn, rid, persist=True)
        except KeyError:
            raise ApiError(f"RFQ '{rid}' not found", 404)


def supplier_explanation(params, body) -> dict:
    rid, sid = params.get("rfq_id"), params.get("supplier_id")
    with db.session() as conn:
        db.init_schema(conn)
        try:
            return recommender.explain_supplier(conn, rid, sid)
        except KeyError as exc:
            raise ApiError(str(exc), 404)


# --------------------------------------------------------------------------
# Suppliers
# --------------------------------------------------------------------------

def list_suppliers(params, body) -> dict:
    q = (params.get("q") or "").lower()
    level = (params.get("risk_level") or "").upper()
    with db.session() as conn:
        db.init_schema(conn)
        rows = db.query(conn, """
            SELECT s.supplier_id, s.supplier_name, s.primary_product_category,
                   s.contact_name, s.contact_email, s.contact_phone,
                   s.fda_status, s.ce_status, s.iso_13485_status,
                   s.clearance_510k_status, s.on_time_delivery,
                   s.lead_time_variability, s.field_failure_rate,
                   s.historical_performance_raw, s.regulatory_compliance_raw,
                   p.risk_score, p.risk_level, p.risk_probability, p.model_confidence
            FROM suppliers s
            LEFT JOIN supplier_risk_predictions p ON p.supplier_id = s.supplier_id
            ORDER BY s.supplier_id""")
    if q:
        rows = [r for r in rows if q in (r["supplier_name"] or "").lower()
                or q in (r["supplier_id"] or "").lower()
                or q in (r["primary_product_category"] or "").lower()]
    if level:
        rows = [r for r in rows if (r["risk_level"] or "") == level]
    return {"suppliers": rows, "count": len(rows)}


def get_supplier(params, body) -> dict:
    sid = params.get("supplier_id")
    with db.session() as conn:
        db.init_schema(conn)
        row = db.query_one(conn, "SELECT * FROM suppliers WHERE supplier_id = ?", (sid,))
        if not row:
            raise ApiError(f"Supplier '{sid}' not found", 404)
        row["risk"] = supplier_risk({"supplier_id": sid}, {})
        row["quotes"] = db.query(conn, """
            SELECT q.*, r.equipment, s.decision_score, s.eligibility
            FROM rfq_quotes q
            JOIN rfqs r ON r.rfq_id = q.rfq_id
            LEFT JOIN supplier_scores s
                   ON s.rfq_id = q.rfq_id AND s.supplier_id = q.supplier_id
            WHERE q.supplier_id = ? ORDER BY q.rfq_id""", (sid,))
        from . import features
        row["subscores"] = {
            "historical_performance": features.historical_subscore(row)[0],
            "quality_reliability": features.quality_subscore(row)[0],
            "regulatory_compliance": features.compliance_subscore(row)[0],
            "financial_service_resilience": features.resilience_subscore(row)[0],
        }
    return row


def supplier_risk(params, body) -> dict:
    sid = params.get("supplier_id")
    with db.session() as conn:
        db.init_schema(conn)
        row = db.query_one(conn, """
            SELECT * FROM supplier_risk_predictions WHERE supplier_id = ?""", (sid,))
    if not row:
        return {"supplier_id": sid, "available": False,
                "message": "No risk prediction on file - run scripts/build_all.py."}
    row["available"] = True
    row["top_drivers"] = json.loads(row.pop("top_drivers_json") or "[]")
    row["confidence_breakdown"] = json.loads(row.pop("confidence_breakdown_json") or "{}")
    row["bands"] = {"LOW": "0-25", "MEDIUM": ">25-50", "HIGH": ">50-75", "CRITICAL": ">75"}
    row["confidence_note"] = ("Confidence measures evidence strength and consistency. "
                              "It is not 100 minus risk.")
    return row


def risk_dashboard(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        rows = db.query(conn, """
            SELECT p.*, s.supplier_name, s.primary_product_category,
                   s.on_time_delivery, s.lead_time_variability, s.field_failure_rate,
                   s.capacity_utilization, s.fda_status, s.ce_status,
                   s.iso_13485_status, s.clearance_510k_status
            FROM supplier_risk_predictions p
            JOIN suppliers s ON s.supplier_id = p.supplier_id
            ORDER BY p.risk_score DESC""")
    for r in rows:
        r["top_drivers"] = json.loads(r.pop("top_drivers_json") or "[]")
        r.pop("confidence_breakdown_json", None)
    dist: dict[str, int] = {"LOW": 0, "MEDIUM": 0, "HIGH": 0, "CRITICAL": 0}
    for r in rows:
        dist[r["risk_level"]] = dist.get(r["risk_level"], 0) + 1
    by_cat: dict[str, dict] = {}
    for r in rows:
        c = by_cat.setdefault(r["primary_product_category"] or "Other",
                              {"category": r["primary_product_category"] or "Other",
                               "n": 0, "sum": 0.0})
        c["n"] += 1
        c["sum"] += r["risk_score"] or 0
    categories = sorted(
        ({"category": v["category"], "suppliers": v["n"],
          "avg_risk": round(v["sum"] / v["n"], 1)} for v in by_cat.values()),
        key=lambda x: -x["avg_risk"])
    return {"suppliers": rows, "distribution": dist, "by_category": categories,
            "model": model_info(params, body)}


# --------------------------------------------------------------------------
# Knowledge base
# --------------------------------------------------------------------------

def knowledge_base(params, body) -> dict:
    try:
        return rag.knowledge_base_manifest()
    except Exception as exc:
        raise ApiError(f"Knowledge base unavailable: {exc}", 503)


def search_documents(params, body) -> dict:
    q = params.get("q") or (body or {}).get("query") or ""
    if not q.strip():
        raise ApiError("A query is required")
    filters = {}
    if params.get("document_type"):
        filters["document_type"] = params["document_type"]
    if params.get("rfq_id"):
        filters["rfq_id"] = params["rfq_id"]
    k = _int(params.get("k"), config.RAG_TOP_K)
    return {"query": q, "results": rag.retrieve(q, k, filters or None)}


# --------------------------------------------------------------------------
# Copilot
# --------------------------------------------------------------------------

def copilot_query(params, body) -> dict:
    body = body or {}
    question = (body.get("question") or params.get("q") or "").strip()
    if not question:
        raise ApiError("A question is required")
    with db.session() as conn:
        db.init_schema(conn)
        return copilot.answer(conn, question,
                              body.get("rfq_id") or params.get("rfq_id"),
                              body.get("supplier_id") or params.get("supplier_id"))


# --------------------------------------------------------------------------
# Approvals and audit
# --------------------------------------------------------------------------

def create_approval(params, body) -> dict:
    body = body or {}
    required = ("rfq_id", "supplier_id", "decision", "approver")
    missing = [f for f in required if not (body.get(f) or "").strip()]
    if missing:
        raise ApiError(f"Missing required field(s): {', '.join(missing)}")
    with db.session() as conn:
        db.init_schema(conn)
        try:
            return audit.record_decision(
                conn, rfq_id=body["rfq_id"], supplier_id=body["supplier_id"],
                decision=body["decision"], approver=body["approver"],
                reason=body.get("reason", ""))
        except (ValueError, KeyError) as exc:
            raise ApiError(str(exc), 400)


def create_review(params, body) -> dict:
    body = body or {}
    if not body.get("rfq_id") or not body.get("supplier_id"):
        raise ApiError("rfq_id and supplier_id are required")
    with db.session() as conn:
        db.init_schema(conn)
        return audit.mark_reviewed(conn, rfq_id=body["rfq_id"],
                                   supplier_id=body["supplier_id"],
                                   reviewer=body.get("reviewer", "procurement"),
                                   note=body.get("note", ""))


def list_approvals(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        return {"approvals": audit.approvals(conn, params.get("rfq_id")),
                "pending": audit.pending_approvals(conn)}


def list_audit(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        return {"events": audit.trail(conn, params.get("rfq_id"),
                                      _int(params.get("limit"), 200))}


# --------------------------------------------------------------------------
# Analytics
# --------------------------------------------------------------------------

def analytics(params, body) -> dict:
    with db.session() as conn:
        db.init_schema(conn)
        spend = db.query(conn, """
            SELECT r.rfq_id, r.equipment, r.quantity, r.budget_per_unit,
                   MIN(q.quoted_unit_price) min_price,
                   MAX(q.quoted_unit_price) max_price,
                   AVG(q.quoted_unit_price) avg_price,
                   COUNT(q.quote_id) quotes
            FROM rfqs r LEFT JOIN rfq_quotes q ON q.rfq_id = r.rfq_id
            GROUP BY r.rfq_id ORDER BY r.rfq_id""")
        for s in spend:
            s["budget_total"] = round((s["budget_per_unit"] or 0) * (s["quantity"] or 0), 2)
            s["best_quote_total"] = round((s["min_price"] or 0) * (s["quantity"] or 0), 2)
            s["headroom_pct"] = (round((1 - (s["min_price"] or 0) /
                                        (s["budget_per_unit"] or 1)) * 100, 1)
                                 if s["budget_per_unit"] else None)
        score_spread = db.query(conn, """
            SELECT rfq_id, COUNT(*) n, ROUND(MIN(decision_score),1) min_score,
                   ROUND(AVG(decision_score),1) avg_score,
                   ROUND(MAX(decision_score),1) max_score,
                   SUM(CASE WHEN eligibility='BLOCKED' THEN 1 ELSE 0 END) blocked
            FROM supplier_scores GROUP BY rfq_id ORDER BY rfq_id""")
        compliance = db.query(conn, """
            SELECT fda_status, COUNT(*) n FROM suppliers GROUP BY fda_status""")
        elig = db.query(conn, """
            SELECT eligibility, COUNT(*) n FROM supplier_scores GROUP BY eligibility""")
    return {"spend_by_rfq": spend, "score_spread": score_spread,
            "fda_status_mix": compliance, "eligibility_mix": elig,
            "model": model_info(params, body),
            "weights": config.active_weights(),
            "weight_labels": config.WEIGHT_LABELS}


def settings(params, body) -> dict:
    return {
        "weights": config.active_weights(),
        "weight_labels": config.WEIGHT_LABELS,
        "risk_bands": {"LOW": "0-25", "MEDIUM": ">25-50",
                       "HIGH": ">50-75", "CRITICAL": ">75"},
        "confidence_weights": config.CONFIDENCE_WEIGHTS,
        "suspicious_low_bid_ratio": config.SUSPICIOUS_LOW_BID_RATIO,
        "llm_enabled": config.llm_enabled(),
        "llm_provider": config.LLM_PROVIDER or "none (deterministic grounded answers)",
        "llm_model": config.LLM_MODEL or None,
        "dense_retrieval_enabled": config.USE_DENSE_RETRIEVAL,
        "embedding_model": config.HF_EMBED_MODEL if config.USE_DENSE_RETRIEVAL else None,
        "retriever": (rag.knowledge_base_manifest().get("retriever")
                      if config.RAG_INDEX.exists() else "not built"),
        "hugging_face_key_present": bool(config.HF_API_KEY),
        "rag_top_k": config.RAG_TOP_K,
        "allowed_rag_document_types": sorted(config.ALLOWED_RAG_DOC_TYPES),
        "supplier_contracts_in_rag": False,
        "random_seed": config.RANDOM_SEED,
        "golden_path_rfqs": config.GOLDEN_PATH_RFQS,
        "data_integrity": ingest.integrity_report(),
        "disclaimer": config.PROTOTYPE_BANNER,
    }


def health(params, body) -> dict:
    checks: dict[str, object] = {}
    try:
        checks["database"] = ingest.integrity_report()
    except Exception as exc:
        checks["database"] = {"error": str(exc)}
    checks["model"] = model_info(params, body).get("available", False)
    try:
        checks["knowledge_base_chunks"] = rag.knowledge_base_manifest()["total_chunks"]
    except Exception as exc:
        checks["knowledge_base_chunks"] = f"error: {exc}"
    checks["llm"] = "configured" if config.llm_enabled() else "deterministic fallback"
    ok = (isinstance(checks["database"], dict)
          and checks["database"].get("suppliers", 0) > 0
          and checks["model"] is True
          and isinstance(checks["knowledge_base_chunks"], int))
    return {"status": "ok" if ok else "degraded", "checks": checks}


# --------------------------------------------------------------------------
# Route table:  (method, path-template) -> handler
# --------------------------------------------------------------------------
ROUTES: list[tuple[str, str, callable]] = [
    ("GET",  "/api/health", health),
    ("GET",  "/api/dashboard/summary", dashboard_summary),
    ("GET",  "/api/buyer", buyer),
    ("GET",  "/api/rfqs", list_rfqs),
    ("GET",  "/api/rfqs/{rfq_id}", get_rfq),
    ("GET",  "/api/rfqs/{rfq_id}/suppliers", rfq_suppliers),
    ("GET",  "/api/rfqs/{rfq_id}/suppliers/{supplier_id}", supplier_explanation),
    ("POST", "/api/rfqs/{rfq_id}/recommendation", rfq_recommendation),
    ("GET",  "/api/suppliers", list_suppliers),
    ("GET",  "/api/suppliers/{supplier_id}", get_supplier),
    ("GET",  "/api/suppliers/{supplier_id}/risk", supplier_risk),
    ("GET",  "/api/risk", risk_dashboard),
    ("GET",  "/api/model", model_info),
    ("GET",  "/api/model/evaluation", model_evaluation),
    ("GET",  "/api/knowledge-base", knowledge_base),
    ("GET",  "/api/documents/search", search_documents),
    ("POST", "/api/copilot/query", copilot_query),
    ("POST", "/api/approvals", create_approval),
    ("GET",  "/api/approvals", list_approvals),
    ("POST", "/api/reviews", create_review),
    ("GET",  "/api/audit", list_audit),
    ("GET",  "/api/analytics", analytics),
    ("GET",  "/api/settings", settings),
]
