"""Procurement Copilot.

Answering contract
------------------
* Structured supplier / quotation / score / risk facts come from SQLite only.
* Policy, contract and RFQ claims come from the RAG index only, always cited.
* The Copilot never invents a supplier fact and never asserts a contractual
  requirement without a citation.

Architecture: intent routing builds a *grounded answer frame* - a set of verified
facts plus retrieved citations.  The frame alone is enough to render a complete,
correct answer (the deterministic path).  When an LLM is configured, the same
frame is handed to it as the only permitted source material, so the LLM changes
the prose, never the facts.  If the LLM call fails for any reason the
deterministic rendering is returned instead, so the demo cannot break.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request

from . import config, db, query_engine, scoring
from .rag import retrieve as rag

# Phrases that mean "across the whole portfolio", not "about the current RFQ".
# Without this the UI's selected RFQ would silently narrow a global question.
PORTFOLIO_HINTS = (
    "all rfq", "every rfq", "across rfq", "across all", "all suppliers",
    "every supplier", "any supplier", "which suppliers", "what suppliers",
    "how many", "list all", "overall", "in total", "portfolio", "anywhere",
    "each rfq", "the master", "on file", "in the database", "we have",
)

RFQ_RE = re.compile(r"\bRFQ[-\s]?(\d{3})\b", re.I)
SUPPLIER_ID_RE = re.compile(r"\bMED[-\s]?(\d{3})\b", re.I)

# --------------------------------------------------------------------------
# Scope
# --------------------------------------------------------------------------
# This Copilot answers from the procurement database and the buyer's own
# documents, and from nothing else.  A question outside that scope must be
# declined plainly rather than answered from a language model's general
# knowledge - answering "who is the prime minister of India" would be exactly
# the ungrounded behaviour the whole design exists to prevent.
DOMAIN_TERMS = {
    # commercial
    "rfq", "rfqs", "quote", "quotes", "quotation", "quotations", "bid", "bids",
    "price", "prices", "pricing", "cost", "costs", "budget", "cheapest",
    "expensive", "spend", "award", "tender", "procure", "procurement",
    # parties
    "supplier", "suppliers", "vendor", "vendors", "manufacturer", "buyer",
    "medicore", "aarogyacare",
    # evaluation
    "score", "scores", "scoring", "rank", "ranking", "compare", "comparison",
    "recommend", "recommended", "recommendation", "shortlist", "select",
    "evaluate", "evaluation", "weight", "weights", "weighting",
    # risk / model
    "risk", "risks", "risky", "disruption", "probability", "confidence",
    "model", "shap", "driver", "drivers", "prediction", "predict", "forecast",
    # quality / delivery
    "delivery", "deliver", "lead", "warranty", "sla", "quality", "defect",
    "failure", "failures", "recall", "recalls", "mtbf", "complaint",
    "complaints", "batch", "rejection", "capacity", "fulfilment", "fulfillment",
    # regulatory
    "compliance", "compliant", "regulatory", "certification", "certified",
    "clearance", "fda", "ce", "iso", "13485", "510", "510(k)", "inspection",
    "consent", "decree", "audit", "policy", "contract", "clause", "governance",
    # equipment
    "equipment", "device", "devices", "pump", "pumps", "monitor", "monitors",
    "ventilator", "ventilators", "defibrillator", "ultrasound", "ecg",
    "autoclave", "incubator", "oximeter", "infusion", "syringe", "anesthesia",
    "anaesthesia", "electrosurgical", "x-ray", "xray", "table", "medical",
    # workflow
    "approve", "approval", "approvals", "approver", "reject", "rejected",
    "review", "pending", "decision", "decisions", "trail",
}

# Word stems, so inflections are covered without listing every form:
# "risk / risks / risky / riskiest", "block / blocked / blocking",
# "comply / compliant / compliance", "certify / certified / certification".
DOMAIN_PREFIXES = (
    "risk", "block", "flag", "compl", "certif", "cleara", "cleared", "deliver",
    "quot", "suppl", "vendor", "procur", "recommend", "approv", "reject",
    "award", "audit", "polic", "contract", "clause", "score", "scoring",
    "rank", "price", "pricing", "cost", "budget", "warrant", "invent",
    "capacit", "qualit", "defect", "fail", "recall", "inspect", "regulat",
    "equipment", "devic", "monitor", "pump", "ventilat", "eligib", "disrupt",
    "confiden", "predict", "evaluat", "weight", "shortlist",
)

# Words that appear across many supplier names and so identify nobody.
GENERIC_NAME_WORDS = {
    # shared across many supplier names, so they identify nobody
    "biomedical", "systems", "medical", "devices", "healthcare", "medtech",
    "ltd", "limited", "inc", "the",
    # supplier-name words that are also ordinary English words: matching these
    # alone would admit "who is the prime minister" or "precision engineering"
    "prime", "precision", "pulse", "nova", "apex", "orion",
}

GREETING_RE = re.compile(
    r"^\s*(hi|hey|hello|yo|good\s+(morning|afternoon|evening)|thanks?|thank\s+you|"
    r"ok|okay|cool|nice|great|bye|goodbye)\b[\s!.?]*$", re.I)

CAPABILITIES = [
    "Compare the quotations on an RFQ and explain the ranking",
    "Explain why a supplier is recommended, flagged or blocked",
    "Break down a supplier's predicted risk and its drivers",
    "Explain model confidence and how it differs from risk",
    "Quote the buyer policy, master contract or an RFQ, with citations",
]

EXAMPLE_QUESTIONS = [
    "Which supplier should I select for RFQ-102?",
    "Why is the recommended supplier recommended?",
    "What does the buyer policy say about suspended certifications?",
]


# --------------------------------------------------------------------------
# Entity resolution
# --------------------------------------------------------------------------

def _find_rfq(conn, text: str, default: str | None = None) -> str | None:
    m = RFQ_RE.search(text or "")
    if m:
        rid = f"RFQ-{m.group(1)}"
        if db.query_one(conn, "SELECT 1 FROM rfqs WHERE rfq_id = ?", (rid,)):
            return rid
    return default


def _find_supplier(conn, text: str, rfq_id: str | None) -> dict | None:
    text = text or ""
    m = SUPPLIER_ID_RE.search(text)
    if m:
        sid = f"MED-{m.group(1)}"
        row = db.query_one(conn, "SELECT * FROM suppliers WHERE supplier_id = ?", (sid,))
        if row:
            return row

    # Positional references against the current RFQ's ranking ("supplier A",
    # "the second one", "the recommended supplier").
    if rfq_id:
        rows = scoring.score_rfq(conn, rfq_id, persist=False)
        low = text.lower()
        for i, letter in enumerate("abcdefgh"):
            if re.search(rf"\bsupplier {letter}\b", low) and i < len(rows):
                return db.query_one(conn, "SELECT * FROM suppliers WHERE supplier_id = ?",
                                    (rows[i]["supplier_id"],))
        for word, i in (("first", 0), ("top", 0), ("recommended", 0), ("best", 0),
                        ("second", 1), ("runner", 1), ("third", 2), ("last", -1),
                        ("worst", -1), ("cheapest", None)):
            if word in low:
                if word == "cheapest":
                    r = min(rows, key=lambda r: r["quoted_unit_price"] or 1e18)
                else:
                    r = rows[i]
                return db.query_one(conn, "SELECT * FROM suppliers WHERE supplier_id = ?",
                                    (r["supplier_id"],))

    # Name match against the supplier master.
    for s in db.query(conn, "SELECT * FROM suppliers"):
        name = (s["supplier_name"] or "").lower()
        if len(name) > 4 and name in text.lower():
            return s
        stem = name.split(" ")[0]
        if len(stem) > 5 and re.search(rf"\b{re.escape(stem)}\b", text.lower()):
            return s
    return None


def is_greeting(question: str) -> bool:
    return bool(GREETING_RE.match(question or ""))


_NAME_WORDS_CACHE: set[str] | None = None


def _supplier_name_words(conn) -> set[str]:
    """Distinctive words from supplier names ("cura", "helix", "solaris").

    Generic words shared across many names are excluded, so "medical" does not
    admit an unrelated question while "Cura" does. Computed once per process.
    """
    global _NAME_WORDS_CACHE
    if _NAME_WORDS_CACHE is None:
        words: set[str] = set()
        for row in db.query(conn, "SELECT supplier_name FROM suppliers"):
            for w in re.findall(r"[A-Za-z]+", (row["supplier_name"] or "").lower()):
                if len(w) > 3 and w not in GENERIC_NAME_WORDS:
                    words.add(w)
        _NAME_WORDS_CACHE = words
    return _NAME_WORDS_CACHE


def scope_check(conn, question: str) -> tuple[bool, str]:
    """Decide whether a question is answerable from this system's sources.

    Layered so that a genuine procurement question is never rejected: any one
    positive signal admits it.  Ordered cheapest-first.

    Returns (in_scope, reason) - the reason names the signal that admitted it,
    which makes the decision auditable rather than a black box.
    """
    q = (question or "").strip()
    if not q:
        return False, "empty"

    # 1. An explicit RFQ or supplier identifier.
    if RFQ_RE.search(q):
        return True, "names an RFQ"
    if SUPPLIER_ID_RE.search(q):
        return True, "names a supplier id"

    # 2. Domain vocabulary, exact then by stem so inflections are covered.
    tokens = set(re.findall(r"[a-z0-9()]+", q.lower()))
    hit = tokens & DOMAIN_TERMS
    if hit:
        return True, f"procurement vocabulary ({', '.join(sorted(hit)[:3])})"
    stemmed = {t for t in tokens if t.startswith(DOMAIN_PREFIXES)}
    if stemmed:
        return True, f"procurement vocabulary ({', '.join(sorted(stemmed)[:3])})"

    # 3. A supplier named, in full or by its distinctive word ("Cura", "Helix").
    try:
        if _find_supplier(conn, q, None):
            return True, "names a supplier"
        distinctive = {w for name in _supplier_name_words(conn)
                       for w in [name] if w in tokens}
        if distinctive:
            return True, f"names a supplier ({sorted(distinctive)[0]})"
    except Exception:
        pass

    # 4. Last resort: does the knowledge base actually contain anything for it?
    try:
        if rag.retrieve(q, 1):
            return True, "matches a buyer document"
    except Exception:
        pass

    return False, "no procurement entity, vocabulary or document match"


def classify(question: str) -> str:
    """Route a question to an answer frame.

    Order matters and is deliberate.  "Why is supplier C high risk?" and "Why is
    supplier A recommended?" both start with "why is", so the topic words decide
    first and the "why" phrasing only decides among what is left.  Likewise a
    question naming the policy or contract is a documentation question even when
    it also mentions a requirement word such as "certification".
    """
    q = f" {(question or '').lower()} "

    def has(*keys: str) -> bool:
        return any(k in q for k in keys)

    # 1. Explicit documentation questions win outright.
    if has("policy", "contract", "clause", "master contract", "knowledge base",
           "auto-approve", "auto approve", "approval authority", "who approves",
           "weighting", "weights", "threshold"):
        return "policy"

    # 2. Model-internals questions, before the generic "why".
    if has("confidence", "confident", "how sure", "how certain", "how reliable",
           "reliable is", "certainty"):
        return "confidence"
    if has("driver", "shap", "contribut", "feature", "what makes", "influenc",
           "which factors", "explain the model", "attribut"):
        return "drivers"
    if has("risk", "disruption", "late deliver", "risky", "likely to fail"):
        return "risk"

    # 3. Recommendation rationale.
    if has("why is", "why was", "why did", "why should", "why recommend",
           "reason for", "justify", "rationale", "on what basis"):
        return "why_recommended"

    # 4. Choice / comparison.
    if has("compare", "comparison", "versus", " vs ", "which supplier",
           "who should", "rank", "shortlist", "best supplier", "select",
           "should i choose", "recommend"):
        return "compare"

    if has("alternative", "instead", "other option", "backup", "second choice",
           "if we reject", "fallback"):
        return "alternatives"
    if has("tell me about", "profile", "who is", "details on", "history of",
           "background on"):
        return "supplier_profile"
    if has("requirement", "require", "specification", " spec ", "warranty",
           "sla", "delivery days", "budget", "quantity", "certification",
           "how many units"):
        return "requirements"
    return "general"


# --------------------------------------------------------------------------
# Frame builders - each returns verified facts + citations
# --------------------------------------------------------------------------

def _fmt_inr(v) -> str:
    try:
        return f"INR {float(v):,.0f}"
    except Exception:
        return "n/a"


def _supplier_facts(conn, rfq_id: str, supplier_id: str) -> dict | None:
    rows = scoring.score_rfq(conn, rfq_id, persist=False)
    return next((r for r in rows if r["supplier_id"] == supplier_id), None)


def _is_portfolio_question(question: str) -> bool:
    q = f" {(question or '').lower()} "
    return any(h in q for h in PORTFOLIO_HINTS)


def _all_supplier_ids(conn, text: str) -> list[str]:
    """Every supplier id or distinctive supplier name mentioned, in order."""
    found: list[str] = []
    for m in SUPPLIER_ID_RE.finditer(text or ""):
        sid = f"MED-{m.group(1)}"
        if sid not in found and db.query_one(
                conn, "SELECT 1 FROM suppliers WHERE supplier_id = ?", (sid,)):
            found.append(sid)
    low = (text or "").lower()
    rows = db.query(conn, "SELECT supplier_id, supplier_name FROM suppliers")

    # Full-name matches are unambiguous.
    for row in rows:
        name = (row["supplier_name"] or "").lower()
        if len(name) > 4 and name in low and row["supplier_id"] not in found:
            found.append(row["supplier_id"])

    # A first-word stem only identifies a supplier if it is unique. Several
    # names share a stem ("MediCore Medical Systems 19" and "MediCore
    # Biomedical 39"), and treating an ambiguous stem as two separate mentions
    # would turn a single-supplier question into a comparison.
    stem_owners: dict[str, list[str]] = {}
    for row in rows:
        stem = (row["supplier_name"] or "").lower().split(" ")[0]
        if len(stem) > 4 and stem not in GENERIC_NAME_WORDS:
            stem_owners.setdefault(stem, []).append(row["supplier_id"])
    for stem, owners in stem_owners.items():
        if len(owners) == 1 and owners[0] not in found:
            if re.search(rf"\b{re.escape(stem)}\b", low):
                found.append(owners[0])
    return found


def _structured_frame(kind: str, question: str, result: dict,
                      rfq_id: str | None, citations: list) -> dict:
    return {
        "intent": kind, "rfq_id": rfq_id, "question": question,
        "facts": result["facts"], "table": result.get("table"),
        "citations": citations, "in_scope": True,
        "supplier_id": result.get("supplier_id"),
        "supplier_name": result.get("supplier_name"),
        "sql": result.get("sql"),
        "source": "structured retrieval (SQLite)",
    }


def _structured_answer(conn, question: str, rfq_id: str | None,
                       supplier_id: str | None) -> dict | None:
    """Route a question to the structured retriever when it needs computing.

    Returns a frame, or None to let the intent-based path handle it.  Ordered
    most specific first so "compare MED-024 and MED-030" is not swallowed by the
    generic per-RFQ comparison.
    """
    q = (question or "").lower()
    named_rfq = _find_rfq(conn, question, None)
    mentioned = _all_supplier_ids(conn, question)

    # 1. Explicit comparison of two or more named suppliers.
    if len(mentioned) >= 2 and any(w in q for w in
                                   ("compare", "versus", " vs ", "difference", "against",
                                    "better", "or ")):
        res = query_engine.compare_suppliers(conn, mentioned)
        if res:
            return _structured_frame("compare_suppliers", question, res, named_rfq,
                                     rag.retrieve(
                                         "evaluation priorities decision score weighting", 2))

    # 2. A single supplier named with no RFQ context: a profile question.
    if len(mentioned) == 1 and not named_rfq:
        wants_profile = any(w in q for w in
                            ("tell me about", "who is", "profile", "details", "about",
                             "category", "supply", "supplies", "contact", "background",
                             "history of", "what does", "information"))
        if wants_profile:
            res = query_engine.supplier_profile(conn, mentioned[0])
            if res:
                return _structured_frame("supplier_lookup", question, res, None,
                                         rag.retrieve("supplier eligibility regulatory evidence", 2))

    # A question about one named supplier belongs to the per-supplier intent
    # path, not to a portfolio filter. Without this, "why is X critical risk?"
    # would be answered with a list of every critical-risk supplier.
    if len(mentioned) == 1 and not _is_portfolio_question(question):
        if any(w in q for w in ("why", "how", "explain", "driver", "confidence",
                                "score", "recommend", "risk of", "reason")):
            return None

    # 3. Counts and aggregations ("how many...", "average...", "total budget").
    #    Ahead of the listing operations, which would otherwise answer "how many
    #    RFQs are open?" by listing all fifteen.
    res = query_engine.count_or_aggregate(conn, question)
    if res:
        return _structured_frame("aggregate", question, res, None,
                                 rag.retrieve(question, 2))

    # 4. Superlatives / rankings ("best on-time delivery", "cheapest quote").
    if not named_rfq or _is_portfolio_question(question):
        res = query_engine.rank_suppliers(conn, question)
        if res:
            return _structured_frame("rank", question, res, None,
                                     rag.retrieve(question, 2))

    # 5. Categorical filters ("suppliers with a consent decree", "blocked").
    if not named_rfq or _is_portfolio_question(question):
        res = query_engine.filter_suppliers(conn, question)
        if res:
            cites = rag.retrieve("supplier eligibility regulatory evidence review", 2)
            return _structured_frame("filter", question, res, None, cites)

    # 6. Portfolio-level RFQ listings, last because it is the broadest.
    res = query_engine.portfolio_overview(conn, question)
    if res and (_is_portfolio_question(question) or not named_rfq):
        return _structured_frame("portfolio", question, res, None,
                                 rag.retrieve("evaluation priorities award", 2))

    # 7. Portfolio-wide risk distribution.
    if ("risk" in q and _is_portfolio_question(question)
            and not named_rfq and not mentioned):
        res = query_engine.risk_distribution(conn)
        return _structured_frame("risk_distribution", question, res, None,
                                 rag.retrieve("risk thresholds critical high approval", 2))
    return None


def build_frame(conn, question: str, rfq_id: str | None = None,
                supplier_id: str | None = None) -> dict:
    """Build the grounded answer frame.

    `supplier_id` carries UI context - the row the user currently has selected -
    so a follow-up like "how confident is that?" resolves to the supplier on
    screen instead of silently defaulting to the top-ranked one.  A supplier
    named in the question always overrides the context.
    """
    # ---------------------------------------------------------------- scope
    # Handled before anything else: a greeting or an out-of-scope question must
    # not be answered with a procurement summary the user did not ask for.
    if is_greeting(question):
        return {
            "intent": "greeting", "rfq_id": rfq_id or config.DEFAULT_RFQ,
            "question": question, "table": None, "citations": [],
            "supplier_id": supplier_id, "supplier_name": None,
            "in_scope": True,
            "facts": ["I'm the Procurement Copilot for AarogyaCare's medical "
                      "equipment sourcing. I can help with:"]
                     + [f"  - {c}" for c in CAPABILITIES]
                     + ["Try: " + EXAMPLE_QUESTIONS[0]],
        }

    ok, reason = scope_check(conn, question)
    if not ok:
        return {
            "intent": "out_of_scope", "rfq_id": rfq_id or config.DEFAULT_RFQ,
            "question": question, "table": None, "citations": [],
            "supplier_id": supplier_id, "supplier_name": None,
            "in_scope": False, "scope_reason": reason,
            "facts": [
                "That question is outside what this system can answer.",
                "I answer only from AarogyaCare's procurement database (suppliers, "
                "RFQs, quotations, scores and risk predictions) and the buyer's own "
                "documents (procurement policy POL-MED-001, master contract "
                "CON-MED-001, and RFQ-101 to RFQ-115).",
                "I don't answer general-knowledge questions, because every answer "
                "here has to be traceable to a record or a cited clause.",
                "Things I can answer:",
            ] + [f"  - {c}" for c in CAPABILITIES]
              + ["For example: " + EXAMPLE_QUESTIONS[0]],
        }

    # ---------------------------------------------------------------- routing
    # Structured retrieval first: questions that must be *computed* from the
    # database (filters, counts, rankings, comparisons, portfolio views) are
    # answered from SQL, not from documents and not from the current RFQ.
    structured = _structured_answer(conn, question, rfq_id, supplier_id)
    if structured is not None:
        return structured

    intent = classify(question)
    # An RFQ context is bound only when the question implies one. Defaulting
    # every question to RFQ-102 was silently answering portfolio-wide questions
    # with one RFQ's data.
    named = _find_rfq(conn, question, None)
    if named:
        rfq_id = named
    elif _is_portfolio_question(question):
        rfq_id = None
    else:
        rfq_id = rfq_id or config.DEFAULT_RFQ
    rfq = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rfq_id,)) if rfq_id else None
    supplier = _find_supplier(conn, question, rfq_id)
    if supplier is None and supplier_id:
        supplier = db.query_one(conn, "SELECT * FROM suppliers WHERE supplier_id = ?",
                                (supplier_id,))

    frame = {"intent": intent, "rfq_id": rfq_id, "question": question,
             "facts": [], "table": None, "citations": [], "in_scope": True,
             "supplier_id": supplier["supplier_id"] if supplier else None,
             "supplier_name": supplier["supplier_name"] if supplier else None}

    if not rfq:
        # A portfolio-wide question that no structured operation matched. Answer
        # with what is actually known across the whole portfolio rather than
        # reporting a missing RFQ context, which tells the user nothing.
        counts = db.query_one(conn, """
            SELECT (SELECT COUNT(*) FROM suppliers) suppliers,
                   (SELECT COUNT(*) FROM rfqs) rfqs,
                   (SELECT COUNT(*) FROM rfq_quotes) quotes""") or {}
        dist = {r["risk_level"]: r["n"] for r in db.query(
            conn, "SELECT risk_level, COUNT(*) n FROM supplier_risk_predictions "
                  "GROUP BY risk_level")}
        blocked = db.query_one(conn, """
            SELECT COUNT(DISTINCT supplier_id) n FROM supplier_scores
            WHERE eligibility = 'BLOCKED'""") or {"n": 0}
        frame["facts"] = [
            (f"Across the portfolio: {counts.get('suppliers', 0)} suppliers, "
             f"{counts.get('rfqs', 0)} RFQs and {counts.get('quotes', 0)} quotations."),
            ("Predicted risk: " + ", ".join(
                f"{lvl} {dist.get(lvl, 0)}"
                for lvl in ("LOW", "MEDIUM", "HIGH", "CRITICAL")) + "."),
            (f"{blocked['n']} supplier(s) are BLOCKED on at least one RFQ under "
             f"buyer policy."),
            "Ask about a specific RFQ (RFQ-101 to RFQ-115) or supplier "
            "(MED-001 to MED-050) for a detailed answer.",
        ]
        frame["citations"] = rag.retrieve(question, 3)
        return frame

    rows = scoring.score_rfq(conn, rfq_id, persist=False)
    row = _supplier_facts(conn, rfq_id, supplier["supplier_id"]) if supplier else None

    head = (f"{rfq_id} - {rfq['equipment']} for {rfq['clinical_use']}; "
            f"{rfq['quantity']} units, budget {_fmt_inr(rfq['budget_per_unit'])}/unit, "
            f"required delivery {rfq['required_delivery_days']} days, warranty "
            f"{rfq['warranty_months']} months, service SLA {rfq['service_sla_hours']}h.")

    # ---------------------------------------------------------------- compare
    if intent in ("compare", "general") and not row:
        top = rows[0]
        frame["facts"] = [
            head,
            f"{len(rows)} quotations received.",
            (f"Highest decision score: {top['supplier_name']} at {top['decision_score']}/100, "
             f"risk {top['risk_level']} ({top['risk_score']:.0f}/100, "
             f"probability {top['risk_probability']:.0%}), model confidence "
             f"{top['model_confidence']:.0f}%, eligibility {top['eligibility']}."),
            (f"{sum(1 for r in rows if r['eligibility'] == 'BLOCKED')} quotation(s) cannot be "
             f"auto-approved under buyer policy."),
        ]
        cheapest = min(rows, key=lambda r: r["quoted_unit_price"] or 1e18)
        if cheapest["supplier_id"] != top["supplier_id"]:
            frame["facts"].append(
                f"The cheapest quotation ({cheapest['supplier_name']}, "
                f"{_fmt_inr(cheapest['quoted_unit_price'])}/unit) is NOT the highest scorer - it "
                f"ranks #{cheapest['rank']} with {cheapest['decision_score']}/100 "
                f"and {cheapest['risk_level']} risk.")
        frame["table"] = [{
            "supplier": r["supplier_name"], "supplier_id": r["supplier_id"],
            "unit_price": r["quoted_unit_price"], "delivery_days": r["quoted_delivery_days"],
            "quality": r["quality_score"], "risk_level": r["risk_level"],
            "risk_score": r["risk_score"], "confidence": r["model_confidence"],
            "score": r["decision_score"], "eligibility": r["eligibility"],
        } for r in rows]
        frame["citations"] = rag.retrieve_for_rfq(
            rfq_id, "evaluation priorities decision score weighting lowest price award", 3)

    # ------------------------------------------------------- why recommended
    elif intent == "why_recommended":
        target = row or next((r for r in rows if r["eligibility"] != "BLOCKED"), rows[0])
        frame["supplier_id"], frame["supplier_name"] = target["supplier_id"], target["supplier_name"]
        w = config.active_weights()
        contrib = ", ".join(
            f"{config.WEIGHT_LABELS[k]} {v} pts (weight {int(w[k]*100)}%)"
            for k, v in sorted(target["weighted_contributions"].items(),
                               key=lambda kv: -kv[1]))
        frame["facts"] = [
            head,
            (f"{target['supplier_name']} scores {target['decision_score']}/100 and ranks "
             f"#{target['rank']} of {len(rows)}."),
            f"Score composition: {contrib}.",
            (f"Predicted disruption risk {target['risk_level']} "
             f"({target['risk_score']:.0f}/100, probability {target['risk_probability']:.0%}); "
             f"model confidence {target['model_confidence']:.0f}% - confidence measures evidence "
             f"strength and is a separate quantity from risk."),
            f"Policy routing: {target['eligibility']}.",
        ]
        if target["eligibility_reasons"]:
            frame["facts"].append("Outstanding exceptions: "
                                  + " ".join(target["eligibility_reasons"]))
        frame["citations"] = rag.retrieve_for_rfq(
            rfq_id, "evaluation priorities patient safety compliance price weighting approval", 4)

    # ---------------------------------------------------------------- risk
    elif intent == "risk":
        if row:
            drivers = ", ".join(
                f"{d['label']} = {d['value']} ({d['direction']}, "
                f"{d['contribution_pp']:+.1f} pp)" for d in row["top_drivers"][:4])
            frame["supplier_id"], frame["supplier_name"] = row["supplier_id"], row["supplier_name"]
            frame["facts"] = [
                (f"{row['supplier_name']} - predicted disruption risk {row['risk_level']}: "
                 f"score {row['risk_score']:.0f}/100, probability {row['risk_probability']:.0%}, "
                 f"model confidence {row['model_confidence']:.0f}%."),
                f"Largest model drivers: {drivers}." if drivers else "",
                (f"Deterministic sub-scores - historical {row['historical_score']}/100, "
                 f"quality {row['quality_score']}/100, compliance {row['compliance_score']}/100, "
                 f"resilience {row['resilience_score']}/100."),
                f"Policy routing: {row['eligibility']}.",
            ]
            # Correct a false premise rather than answering around it.
            asserted = next((lvl for lvl in ("critical", "high", "medium", "low")
                             if f"{lvl} risk" in (question or "").lower()), None)
            if asserted and asserted.upper() != row["risk_level"]:
                frame["facts"].insert(
                    0, (f"Correction: {row['supplier_name']} is not {asserted.upper()} risk on "
                        f"{rfq_id}. The model predicts {row['risk_level']} risk "
                        f"({row['risk_score']:.0f}/100)."))
        else:
            dist: dict[str, int] = {}
            for r in rows:
                dist[r["risk_level"]] = dist.get(r["risk_level"], 0) + 1
            frame["facts"] = [head,
                              "Risk levels across this RFQ's quotations: "
                              + ", ".join(f"{k} {v}" for k, v in sorted(dist.items()))]
        frame["facts"] = [f for f in frame["facts"] if f]
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, "risk thresholds critical high approval", 3)

    # ------------------------------------------------------------ confidence
    elif intent == "confidence":
        target = row or rows[0]
        cb = db.query_one(conn, """SELECT confidence_breakdown_json FROM
                                   supplier_risk_predictions WHERE supplier_id = ?""",
                          (target["supplier_id"],)) or {}
        parts = json.loads(cb.get("confidence_breakdown_json") or "{}")
        detail = ", ".join(f"{k.replace('_', ' ')} {v['value']:.0f}% "
                           f"(weight {int(v['weight']*100)}%)" for k, v in parts.items())
        frame["supplier_id"], frame["supplier_name"] = target["supplier_id"], target["supplier_name"]
        frame["facts"] = [
            (f"Model confidence for {target['supplier_name']} is "
             f"{target['model_confidence']:.0f}%."),
            ("Confidence is the strength and consistency of the evidence behind the "
             "prediction. It is NOT 100 minus risk: this supplier's risk is "
             f"{target['risk_score']:.0f}/100 while confidence is "
             f"{target['model_confidence']:.0f}%."),
            f"Components: {detail}." if detail else "",
        ]
        frame["facts"] = [f for f in frame["facts"] if f]

    # --------------------------------------------------------------- drivers
    elif intent == "drivers":
        target = row or rows[0]
        frame["supplier_id"], frame["supplier_name"] = target["supplier_id"], target["supplier_name"]
        frame["facts"] = [
            (f"Feature attributions for {target['supplier_name']} "
             f"(risk {target['risk_score']:.0f}/100):")]
        for d in target["top_drivers"]:
            frame["facts"].append(
                f"  - {d['label']} = {d['value']}: {d['contribution_pp']:+.1f} "
                f"percentage points, {d['direction']}.")
        frame["facts"].append(
            "Attributions are Shapley values: each is that feature's average marginal "
            "effect on the predicted probability, and together they account for the "
            "gap between this supplier and the population baseline.")
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, "explainability factors contributing score", 2)

    # ---------------------------------------------------------- requirements
    elif intent == "requirements":
        frame["facts"] = [head,
                          f"Required certifications: {rfq['required_certifications']}.",
                          f"Status: {rfq['status']}, issued {rfq['issue_date']}."]
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, question, 4)

    # --------------------------------------------------------------- policy
    elif intent == "policy":
        frame["citations"] = rag.retrieve(question, 4)
        w = config.active_weights()
        frame["facts"] = [
            "Decision-score weighting currently in force: "
            + ", ".join(f"{config.WEIGHT_LABELS[k]} {int(v*100)}%" for k, v in w.items())
            + ".",
            "Risk bands: LOW 0-25, MEDIUM >25-50, HIGH >50-75, CRITICAL >75.",
        ]

    # --------------------------------------------------------- alternatives
    elif intent == "alternatives":
        approvable = [r for r in rows if r["eligibility"] != "BLOCKED"]
        frame["facts"] = [head]
        for r in approvable[:3]:
            frame["facts"].append(
                f"#{r['rank']} {r['supplier_name']}: {r['decision_score']}/100, "
                f"{_fmt_inr(r['quoted_unit_price'])}/unit, {r['quoted_delivery_days']} days, "
                f"risk {r['risk_level']}, {r['eligibility']}.")
        blocked = [r for r in rows if r["eligibility"] == "BLOCKED"]
        if blocked:
            frame["facts"].append(
                "Not available for automatic approval: "
                + "; ".join(f"{r['supplier_name']} ({r['eligibility_reasons'][0]})"
                            for r in blocked))
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, "risk approval defer condition reject award", 3)

    # ------------------------------------------------------ supplier profile
    elif intent == "supplier_profile" and supplier:
        s = supplier
        frame["facts"] = [
            (f"{s['supplier_name']} ({s['supplier_id']}) - {s['primary_product_category']}; "
             f"contact {s['contact_name']}, {s['contact_email']}, {s['contact_phone']}."),
            (f"Regulatory: FDA {s['fda_status']}; CE {s['ce_status']}; "
             f"ISO 13485 {s['iso_13485_status']}; 510(k) {s['clearance_510k_status']}; "
             f"last inspection {s['last_inspection_outcome']}; "
             f"{s['recalls_3y']} recalls in 3 years."),
            (f"Delivery: {s['on_time_delivery']:.1f}% on time, lead-time variability "
             f"{s['lead_time_variability']:.0f} days, fulfilment accuracy "
             f"{s['order_fulfillment_accuracy']:.1f}%."),
            (f"Quality: field failure {s['field_failure_rate']}%, batch rejection "
             f"{s['batch_rejection_rate']}%, MTBF {s['mtbf_hours']:,.0f} h, warranty claims "
             f"{s['warranty_claim_rate']}%."),
            (f"Resilience: credit {s['credit_rating']}, capacity utilisation "
             f"{s['capacity_utilization']:.0f}%, {s['alternate_suppliers']} alternates, "
             f"backup facility {s['backup_facility']}."),
        ]
        if row:
            frame["facts"].append(
                f"On {rfq_id}: {_fmt_inr(row['quoted_unit_price'])}/unit, "
                f"{row['quoted_delivery_days']} days, decision score "
                f"{row['decision_score']}/100, risk {row['risk_level']}, {row['eligibility']}.")

    else:
        frame["facts"] = [head]
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, question, 4)

    if not frame["citations"]:
        frame["citations"] = rag.retrieve_for_rfq(rfq_id, question, 3)
    return frame


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------

def render_deterministic(frame: dict) -> str:
    lines = [f for f in frame["facts"] if f]
    body = "\n".join(lines)
    if frame["citations"] and not any(c.get("error") for c in frame["citations"]):
        body += "\n\nBuyer documentation:\n" + "\n".join(
            f"  - [{c['citation']}] \"{c['evidence']}\"" for c in frame["citations"])
    # The decision-support disclaimer belongs on procurement answers only -
    # appending it to a greeting or a refusal reads as boilerplate.
    if frame.get("intent") not in ("greeting", "out_of_scope"):
        body += ("\n\nThis is decision support. Final award authority remains with the "
                 "authorised procurement approver.")
    return body


LLM_SYSTEM = (
    "You are a procurement analyst assistant for a hospital network buying medical "
    "equipment. Answer ONLY from the VERIFIED FACTS and BUYER DOCUMENTATION given to "
    "you. Never invent a number, supplier attribute, clause or citation. If the facts "
    "do not answer the question, say so plainly. Cite buyer documents in square "
    "brackets exactly as provided. Be concise and specific: 3-6 sentences, no "
    "preamble. Never state or imply that the AI selects the supplier - the buyer's "
    "procurement approver makes the final decision.\n\n"
    "You must REFUSE any question that is not about this buyer's procurement data or "
    "documents - general knowledge, current affairs, arithmetic, coding, creative "
    "writing. Do not answer such questions even if you know the answer: say that it "
    "is outside the scope of this procurement system and name what you can help with. "
    "Your knowledge of the outside world is not a permitted source here."
)


def _llm_prompt(frame: dict) -> str:
    facts = "\n".join(f"- {f}" for f in frame["facts"] if f)
    cites = "\n".join(f'- [{c["citation"]}] "{c["evidence"]}"'
                      for c in frame["citations"] if not c.get("error"))
    return (f"QUESTION: {frame['question']}\n\n"
            f"VERIFIED FACTS (from the procurement database and scoring engine):\n{facts}\n\n"
            f"BUYER DOCUMENTATION (retrieved, cite these verbatim):\n{cites or '(none)'}\n")


def _call_anthropic(prompt: str) -> str | None:      # pragma: no cover - network
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=json.dumps({
            "model": config.LLM_MODEL, "max_tokens": 700,
            "system": LLM_SYSTEM,
            "messages": [{"role": "user", "content": prompt}],
        }).encode(),
        headers={"content-type": "application/json",
                 "x-api-key": config.ANTHROPIC_API_KEY,
                 "anthropic-version": "2023-06-01"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.loads(r.read())
    return "".join(b.get("text", "") for b in data.get("content", [])) or None


def _call_openai_compatible(prompt: str) -> str | None:   # pragma: no cover - network
    """Chat completion for any provider using the OpenAI request shape.

    Hugging Face's router implements this format, so OpenAI and Hugging Face
    differ only by endpoint and bearer token.
    """
    url = config.CHAT_COMPLETIONS_URL.get(config.LLM_PROVIDER)
    if not url:
        return None
    req = urllib.request.Request(
        url,
        data=json.dumps({
            "model": config.LLM_MODEL, "max_tokens": 700,
            "messages": [{"role": "system", "content": LLM_SYSTEM},
                         {"role": "user", "content": prompt}],
        }).encode(),
        headers={"content-type": "application/json",
                 "authorization": f"Bearer {config.llm_api_key()}"})
    with urllib.request.urlopen(req, timeout=config.HF_TIMEOUT) as r:
        data = json.loads(r.read())
    choices = data.get("choices") or []
    if not choices:
        return None
    return (choices[0].get("message") or {}).get("content")


def _response(question: str, text: str, mode: str, frame: dict) -> dict:
    """Uniform response envelope for every answer path."""
    return {
        "question": question,
        "answer": text,
        "mode": mode,
        "intent": frame["intent"],
        "in_scope": frame.get("in_scope", True),
        "scope_reason": frame.get("scope_reason"),
        "rfq_id": frame.get("rfq_id"),
        "supplier_id": frame.get("supplier_id"),
        "supplier_name": frame.get("supplier_name"),
        "facts": [f for f in frame["facts"] if f],
        "table": frame.get("table"),
        "citations": [c for c in frame.get("citations", []) if not c.get("error")],
        "suggestions": EXAMPLE_QUESTIONS if not frame.get("in_scope", True) else [],
        # Provenance: which retriever produced the facts, and - for structured
        # retrieval - the exact statement, so any figure can be traced.
        "source": frame.get("source", "procurement database + buyer documents"),
        "sql": frame.get("sql"),
        "disclaimer": config.PROTOTYPE_BANNER,
    }


def answer(conn, question: str, rfq_id: str | None = None,
           supplier_id: str | None = None) -> dict:
    frame = build_frame(conn, question, rfq_id, supplier_id)
    text = render_deterministic(frame)
    mode = "grounded-deterministic"

    # An out-of-scope question is never forwarded to a language model. Relying on
    # the system prompt alone would leave the refusal at the model's discretion;
    # not making the call at all makes it a property of the system.
    gated = frame.get("intent") in ("out_of_scope", "greeting")
    if gated:
        return _response(question, text, "scope-guard", frame)

    if config.llm_enabled():                          # pragma: no cover - network
        try:
            prompt = _llm_prompt(frame)
            out = (_call_anthropic(prompt) if config.LLM_PROVIDER == "anthropic"
                   else _call_openai_compatible(prompt))
            if out and out.strip():
                text = out.strip()
                mode = f"llm:{config.LLM_PROVIDER}:{config.LLM_MODEL}"
        except Exception:
            # Never let a network or quota problem break the demo: the
            # deterministic rendering computed above is already correct.
            mode = f"grounded-deterministic ({config.LLM_PROVIDER} unavailable)"

    return _response(question, text, mode, frame)


SUGGESTIONS = [
    "Which supplier should I select for RFQ-102?",
    "Why is the recommended supplier recommended?",
    "Why is supplier C high risk?",
    "What does the buyer policy say about suspended certifications?",
    "What warranty and delivery does RFQ-102 require?",
    "How confident is the model in that risk prediction?",
    "What are the alternatives if we reject the top supplier?",
]
