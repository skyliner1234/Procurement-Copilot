"""Recommendation engine.

Combines four independent signals, deliberately kept separate all the way to the
UI so a reviewer can see where a recommendation comes from:

  decision score   deterministic, from scoring.py       "which offer is best?"
  ML risk          learned, from the risk model         "what is likely to happen?"
  policy rules     hard rules over regulatory evidence  "what is permitted?"
  RAG evidence     buyer policy / contract / RFQ text   "what does the buyer require?"

The engine never awards.  It produces RECOMMENDED / RECOMMENDED_WITH_REVIEW /
FLAGGED plus reasons and citations, and routes everything through a human
(policy POL-MED-001 §7, contract CON-MED-001 §11).

The worked example from the specification - the model predicts low risk but a
mandatory certification is missing, so the supplier must still be flagged - is
implemented by `scoring.eligibility`: BLOCKING regulatory flags override a strong
score and a low predicted risk.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from . import audit, config, db, scoring
from .rag import retrieve as rag


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# Reason construction
# --------------------------------------------------------------------------

def _positive_reasons(row: dict, peers: list[dict]) -> list[dict]:
    out: list[dict] = []
    others = [p for p in peers if p["supplier_id"] != row["supplier_id"]]

    def better_than_most(key: str, floor: float = 60.0) -> bool:
        """Beats the peer median *and* clears an absolute floor.

        Without the floor, "best of a weak field" would be presented as a
        strength - which is exactly the kind of claim a reviewer should not have
        to catch for themselves.
        """
        vals = [p.get(key) or 0 for p in others]
        v = row.get(key) or 0
        return bool(vals) and v >= sorted(vals)[len(vals) // 2] and v >= floor

    if row["risk_level"] in ("LOW", "MEDIUM"):
        out.append({
            "text": f"Predicted disruption risk is {row['risk_level']} "
                    f"({row['risk_score']:.0f}/100, probability {row['risk_probability']:.0%}).",
            "kind": "risk"})
    if better_than_most("historical_score"):
        out.append({
            "text": f"Delivery and fulfilment history scores {row['historical_score']:.0f}/100, "
                    f"at or above the median of the competing quotations.",
            "kind": "history"})
    if better_than_most("quality_score"):
        out.append({
            "text": f"Quality and reliability scores {row['quality_score']:.0f}/100 on field "
                    f"failure, batch rejection, complaints and MTBF.",
            "kind": "quality"})
    if row["compliance_score"] >= 80:
        out.append({
            "text": f"Regulatory evidence is complete and current "
                    f"(compliance {row['compliance_score']:.0f}/100).",
            "kind": "compliance"})
    if (row.get("vs_median_pct") or 0) <= 0:
        out.append({
            "text": f"Priced {abs(row['vs_median_pct']):.0f}% below the peer median for this RFQ "
                    f"(total evaluated cost INR {row['total_evaluated_cost']:,.0f}).",
            "kind": "price"})
    if row["delivery_score"] >= 70:
        out.append({
            "text": f"Delivery commitment scores {row['delivery_score']:.0f}/100 against the "
                    f"RFQ window and the supplier's lead-time history.",
            "kind": "delivery"})
    return out[:5]


def _concerns(row: dict) -> list[dict]:
    return [{"text": f["message"], "severity": f["severity"], "clause": f.get("clause")}
            for f in row.get("flags", []) if f.get("severity") in ("BLOCKING", "REVIEW")]


def _outcome(row: dict) -> tuple[str, str]:
    if row["eligibility"] == "BLOCKED":
        return "FLAGGED", ("Cannot be auto-approved under buyer policy; requires "
                           "procurement-manager decision or exclusion.")
    if row["eligibility"] == "REVIEW_REQUIRED":
        return "RECOMMENDED_WITH_REVIEW", ("Best-scoring offer, subject to human "
                                           "review of the noted exceptions.")
    return "RECOMMENDED", "Best-scoring offer with no outstanding exceptions."


def _evidence_for(row: dict, rfq: dict) -> list[dict]:
    """Assemble the citation set backing this recommendation."""
    ev: list[dict] = []
    seen: set[str] = set()

    def add(item: dict | None, why: str):
        if not item or item.get("citation") in seen:
            return
        seen.add(item["citation"])
        ev.append({**item, "why": why})

    # 1. The RFQ's own requirements (restricted to this RFQ's document).
    for h in rag.retrieve(
            f"required delivery days warranty months certifications budget per unit "
            f"{rfq['equipment']}",
            2, {"document_type": "buyer_rfq", "rfq_id": rfq["rfq_id"]}):
        add(h, "RFQ requirement being evaluated against")

    # 2. The clause behind the evaluation weighting.
    add(rag.clause_lookup("POL-MED-001", "Price competitiveness"),
        "Policy weighting used to compute the decision score")

    # 3. Whichever rule actually drove the routing decision.
    if row["eligibility"] == "BLOCKED":
        add(rag.clause_lookup("POL-MED-001", "must not be auto-approved"),
            "Policy rule that blocked automatic approval")
    elif row["risk_level"] in ("HIGH", "CRITICAL"):
        add(rag.clause_lookup("POL-MED-001", "procurement manager must approve"),
            "Policy rule requiring human approval at this risk level")
    else:
        add(rag.clause_lookup("CON-MED-001", "Lowest price alone"),
            "Contract rule that price alone cannot decide the award")

    # 4. Human authority - always shown, this is the product's core principle.
    add(rag.clause_lookup("CON-MED-001", "Final award authority"),
        "Final decision authority remains with the buyer")
    return ev


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

def recommend(conn, rfq_id: str, persist: bool = True) -> dict:
    rfq = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rfq_id,))
    if not rfq:
        raise KeyError(f"Unknown RFQ '{rfq_id}'")

    rows = scoring.score_rfq(conn, rfq_id)
    if not rows:
        return {"rfq": rfq, "recommendation": None, "candidates": [],
                "message": "No quotations are on file for this RFQ."}

    # Blocked suppliers cannot be *recommended*, however well they score.  If
    # every quotation is blocked, the top scorer is surfaced as FLAGGED so the
    # buyer sees the situation rather than an empty panel.
    approvable = [r for r in rows if r["eligibility"] != "BLOCKED"]
    top = (approvable or rows)[0]
    runner_up = (approvable or rows)[1] if len(approvable or rows) > 1 else None

    outcome, outcome_note = _outcome(top)
    reasons = _positive_reasons(top, rows)
    concerns = _concerns(top)
    evidence = _evidence_for(top, rfq)
    sensitivity = scoring.weight_sensitivity(conn, rfq_id)
    robust = all(s["winner_id"] == top["supplier_id"] for s in sensitivity)

    margin = round(top["decision_score"] - runner_up["decision_score"], 1) if runner_up else None

    rec = {
        "rfq_id": rfq_id,
        "supplier_id": top["supplier_id"],
        "supplier_name": top["supplier_name"],
        "decision_score": top["decision_score"],
        "risk_score": top["risk_score"],
        "risk_probability": top["risk_probability"],
        "risk_level": top["risk_level"],
        "model_confidence": top["model_confidence"],
        "outcome": outcome,
        "outcome_note": outcome_note,
        "eligibility": top["eligibility"],
        "reasons": reasons,
        "concerns": concerns,
        "evidence": evidence,
        "weighted_contributions": top["weighted_contributions"],
        "top_drivers": top["top_drivers"],
        "runner_up": ({"supplier_id": runner_up["supplier_id"],
                       "supplier_name": runner_up["supplier_name"],
                       "decision_score": runner_up["decision_score"],
                       "risk_level": runner_up["risk_level"]} if runner_up else None),
        "margin_over_runner_up": margin,
        "weight_sensitivity": sensitivity,
        "robust_to_reweighting": robust,
        "blocked_count": sum(1 for r in rows if r["eligibility"] == "BLOCKED"),
        "requires_human_approval": True,
        "human_authority_note": ("AI output is decision support only. Final award "
                                 "authority remains with the authorised procurement "
                                 "approver (CON-MED-001 §11, POL-MED-001 §7)."),
        "created_at": _now(),
    }

    if persist:
        conn.execute("""
            INSERT INTO recommendations
              (rfq_id, supplier_id, decision_score, risk_score, risk_probability,
               risk_level, model_confidence, outcome, reasons_json, evidence_json,
               created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (rfq_id, top["supplier_id"], top["decision_score"], top["risk_score"],
             top["risk_probability"], top["risk_level"], top["model_confidence"],
             outcome, json.dumps(reasons), json.dumps(evidence), _now()))
        audit.log(conn, rfq_id=rfq_id, supplier_id=top["supplier_id"],
                  event_type="RECOMMENDATION_GENERATED",
                  decision_score=top["decision_score"], risk_score=top["risk_score"],
                  decision=outcome, actor="system",
                  reason=f"{outcome}: {top['supplier_name']} "
                         f"({top['decision_score']}/100, risk {top['risk_level']})")

    return {"rfq": rfq, "recommendation": rec, "candidates": rows}


def explain_supplier(conn, rfq_id: str, supplier_id: str) -> dict:
    """Full per-supplier explanation for the comparison drill-down."""
    rows = scoring.score_rfq(conn, rfq_id, persist=False)
    row = next((r for r in rows if r["supplier_id"] == supplier_id), None)
    if not row:
        raise KeyError(f"{supplier_id} did not quote on {rfq_id}")
    rfq = db.query_one(conn, "SELECT * FROM rfqs WHERE rfq_id = ?", (rfq_id,))
    conf = db.query_one(conn, """SELECT confidence_breakdown_json
                                 FROM supplier_risk_predictions WHERE supplier_id = ?""",
                        (supplier_id,)) or {}
    return {
        **row,
        "confidence_breakdown": json.loads(conf.get("confidence_breakdown_json") or "{}"),
        "evidence": _evidence_for(row, rfq),
        "weights": config.active_weights(),
        "weight_labels": config.WEIGHT_LABELS,
    }
