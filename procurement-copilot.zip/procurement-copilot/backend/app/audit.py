"""Approvals and the audit trail - the human-in-the-loop layer.

Two invariants:

1. AI never awards.  `record_decision` is the only path that sets an award
   outcome, and it requires an approver identity, a decision and a reason.
2. Nothing happens silently.  Recommendation generation, review, approval and
   rejection all append to `audit_events`, which is append-only in practice: the
   API exposes no update or delete.
"""
from __future__ import annotations

from datetime import datetime, timezone

from . import db


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def log(conn, *, rfq_id=None, supplier_id=None, event_type: str,
        decision_score=None, risk_score=None, decision=None,
        actor: str = "system", reason: str = "") -> int:
    cur = conn.execute("""
        INSERT INTO audit_events
          (rfq_id, supplier_id, event_type, decision_score, risk_score,
           decision, actor, reason, created_at)
        VALUES (?,?,?,?,?,?,?,?,?)""",
        (rfq_id, supplier_id, event_type, decision_score, risk_score,
         decision, actor, reason, _now()))
    return cur.lastrowid


def record_decision(conn, *, rfq_id: str, supplier_id: str, decision: str,
                    approver: str, reason: str = "") -> dict:
    """Persist a human approve/reject decision and mirror it into the audit log."""
    decision = (decision or "").strip().upper()
    if decision not in {"APPROVED", "REJECTED"}:
        raise ValueError("decision must be APPROVED or REJECTED")
    if not approver.strip():
        raise ValueError("an approver identity is required")

    score = db.query_one(conn, """
        SELECT decision_score, eligibility FROM supplier_scores
        WHERE rfq_id = ? AND supplier_id = ?""", (rfq_id, supplier_id))
    risk = db.query_one(conn, """
        SELECT risk_score, risk_probability, model_confidence
        FROM supplier_risk_predictions WHERE supplier_id = ?""", (supplier_id,))
    if not score:
        raise KeyError(f"{supplier_id} has no scored quotation on {rfq_id}")

    if decision == "APPROVED" and score.get("eligibility") == "BLOCKED" and not reason.strip():
        raise ValueError(
            "This supplier is BLOCKED under buyer policy. Approving it is an "
            "override and requires a written justification.")

    cur = conn.execute("""
        INSERT INTO approvals
          (rfq_id, supplier_id, recommendation_score, risk_score, risk_probability,
           model_confidence, approver, decision, reason, decided_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (rfq_id, supplier_id, score["decision_score"],
         (risk or {}).get("risk_score"), (risk or {}).get("risk_probability"),
         (risk or {}).get("model_confidence"), approver.strip(), decision,
         reason.strip(), _now()))

    note = reason.strip() or f"{decision.title()} by {approver.strip()}"
    if score.get("eligibility") == "BLOCKED" and decision == "APPROVED":
        note = "POLICY OVERRIDE - " + note
    log(conn, rfq_id=rfq_id, supplier_id=supplier_id,
        event_type="HUMAN_DECISION", decision_score=score["decision_score"],
        risk_score=(risk or {}).get("risk_score"), decision=decision,
        actor=approver.strip(), reason=note)

    return {"approval_id": cur.lastrowid, "rfq_id": rfq_id,
            "supplier_id": supplier_id, "decision": decision,
            "approver": approver.strip(), "reason": reason.strip(),
            "decided_at": _now(),
            "policy_override": score.get("eligibility") == "BLOCKED" and decision == "APPROVED"}


def mark_reviewed(conn, *, rfq_id: str, supplier_id: str, reviewer: str,
                  note: str = "") -> dict:
    log(conn, rfq_id=rfq_id, supplier_id=supplier_id, event_type="HUMAN_REVIEW",
        actor=reviewer.strip() or "reviewer",
        reason=note.strip() or "Opened for review")
    return {"status": "review_logged", "rfq_id": rfq_id, "supplier_id": supplier_id}


def trail(conn, rfq_id: str | None = None, limit: int = 200) -> list[dict]:
    if rfq_id:
        return db.query(conn, """
            SELECT * FROM audit_events WHERE rfq_id = ?
            ORDER BY event_id DESC LIMIT ?""", (rfq_id, limit))
    return db.query(conn, "SELECT * FROM audit_events ORDER BY event_id DESC LIMIT ?",
                    (limit,))


def approvals(conn, rfq_id: str | None = None) -> list[dict]:
    if rfq_id:
        return db.query(conn, """SELECT * FROM approvals WHERE rfq_id = ?
                                 ORDER BY approval_id DESC""", (rfq_id,))
    return db.query(conn, "SELECT * FROM approvals ORDER BY approval_id DESC")


def pending_approvals(conn) -> list[dict]:
    """RFQs with a live recommendation that no human has decided on yet."""
    return db.query(conn, """
        SELECT r.rfq_id, r.supplier_id, r.decision_score, r.risk_score,
               r.risk_level, r.model_confidence, r.outcome, r.created_at,
               q.equipment, s.supplier_name
        FROM recommendations r
        JOIN rfqs q ON q.rfq_id = r.rfq_id
        JOIN suppliers s ON s.supplier_id = r.supplier_id
        WHERE r.recommendation_id IN (
              SELECT MAX(recommendation_id) FROM recommendations GROUP BY rfq_id)
          AND NOT EXISTS (SELECT 1 FROM approvals a
                          WHERE a.rfq_id = r.rfq_id AND a.supplier_id = r.supplier_id)
        ORDER BY r.created_at DESC""")
