"""Build every artefact the application needs, in dependency order.

    python scripts/build_all.py

Idempotent and deterministic (fixed seed), so re-running it before a demo always
reproduces the same numbers.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.app import config, db, ingest, recommender, scoring   # noqa: E402
from backend.app.ml import train                                   # noqa: E402
from backend.app.rag import index as rag_index                     # noqa: E402


def step(n: int, total: int, title: str):
    print(f"\n[{n}/{total}] {title}")


def main(skip_train: bool = False) -> int:
    t0 = time.time()
    total = 6
    print("=" * 68)
    print("  Medical Equipment Procurement Copilot - build")
    print("=" * 68)

    step(1, total, "Ingesting synthetic dataset into SQLite")
    ingest.ingest_all()
    report = ingest.integrity_report()
    if report["orphan_quotes"]:
        print(f"  WARNING: {report['orphan_quotes']} quotations reference unknown suppliers")
    if report["supplier_contracts_table_present"]:
        print("  ERROR: a supplier_contracts table exists - this is out of scope")
        return 1

    step(2, total, "Indexing the buyer knowledge base (policy, contract, RFQs)")
    rag_index.build_index()

    step(3, total, "Training and comparing risk models")
    if skip_train and config.METRICS_ARTIFACT.exists():
        print("  skipped (--skip-train and an existing artefact was found)")
    else:
        train.train_and_predict()

    step(4, total, "Computing procurement decision scores for every quotation")
    scoring.score_all_rfqs()

    step(5, total, "Generating recommendations for the golden-path RFQs")
    with db.session() as conn:
        for rid in config.GOLDEN_PATH_RFQS:
            out = recommender.recommend(conn, rid)
            r = out["recommendation"]
            print(f"  {rid}: {r['supplier_name']} - {r['decision_score']}/100, "
                  f"risk {r['risk_level']} ({r['risk_score']:.0f}), "
                  f"confidence {r['model_confidence']:.0f}%, {r['outcome']}")

    step(6, total, "Verifying")
    from backend.app.routes import health
    h = health({}, {})
    print(f"  health: {h['status']}")
    for k, v in h["checks"].items():
        print(f"    {k}: {v}")

    print(f"\nBuild complete in {time.time() - t0:.1f}s.")
    print("Start the app with:  python run.py")
    return 0 if h["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main(skip_train="--skip-train" in sys.argv))
