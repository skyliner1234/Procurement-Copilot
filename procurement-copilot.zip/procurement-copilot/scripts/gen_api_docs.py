"""Regenerate docs/API.md from the live route table.

    python scripts/gen_api_docs.py

Each endpoint is actually called, so the documented response shape is the shape
the code really returns - the reference cannot drift from the implementation.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.app.routes import ROUTES, ApiError                      # noqa: E402

HEADER = """# API Reference

Auto-generated from `backend/app/routes.py` by `scripts/gen_api_docs.py`.
Regenerate after changing the route table so this file cannot drift.

Both server adapters register these same handlers, so FastAPI
(`uvicorn backend.api_fastapi:app`) and the standard-library server
(`python backend/serve_stdlib.py`) expose an identical surface. With FastAPI,
interactive docs are at `/docs`.

Errors are always JSON: `{"error": "..."}` with 400 for a bad request, 404 for an
unknown id, 503 for a missing artefact, and 500 for anything unhandled. No
endpoint returns an HTML error page.

---
"""

PARAMS = {"rfq_id": "RFQ-102", "supplier_id": "MED-024", "q": "warranty", "limit": 3}
BODIES = {
    "/api/copilot/query": {"question": "Which supplier should I select for RFQ-102?"},
    "/api/reviews": {"rfq_id": "RFQ-102", "supplier_id": "MED-024", "reviewer": "docs"},
}


def shape(v, depth=0):
    if depth > 1:
        return "…"
    if isinstance(v, dict):
        items = list(v.items())[:6]
        body = ", ".join(f"{k}: {shape(x, depth + 1)}" for k, x in items)
        return "{" + body + (", …}" if len(v) > 6 else "}")
    if isinstance(v, list):
        return "[]" if not v else f"[{shape(v[0], depth + 1)} × {len(v)}]"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "number"
    if v is None:
        return "null"
    s = str(v)
    return "string" if len(s) > 28 else f'"{s}"'


def main() -> int:
    out = [HEADER]
    for method, path, handler in ROUTES:
        doc = (handler.__doc__ or "").strip().split("\n")[0] or handler.__name__.replace("_", " ")
        out.append(f"### `{method} {path}`\n\n{doc}\n")

        if path == "/api/approvals" and method == "POST":
            out.append("Request body: "
                       "`{rfq_id, supplier_id, decision: APPROVED|REJECTED, approver, reason}`\n")
            out.append("Returns the persisted approval, including `policy_override: bool`. "
                       "Approving a BLOCKED supplier without a written reason is rejected "
                       "with 400.\n")
            out.append("---\n")
            continue
        if method == "POST":
            body = BODIES.get(path)
            out.append(f"Request body: `{json.dumps(body) if body else '{}'}`\n")

        try:
            resp = handler(PARAMS, BODIES.get(path, {}))
            lines = [f"{k}: {shape(v)}" for k, v in list(resp.items())[:14]]
            if len(resp) > 14:
                lines.append("…")
            out.append("Response shape:\n\n```\n" + "\n".join(lines) + "\n```\n")
        except ApiError as exc:
            out.append(f"_(example call returned {exc.status}: {exc.message})_\n")
        except Exception as exc:
            out.append(f"_(example call raised {type(exc).__name__})_\n")
        out.append("---\n")

    target = ROOT / "docs" / "API.md"
    target.write_text("\n".join(out), encoding="utf-8")
    print(f"  wrote {target.relative_to(ROOT)} "
          f"({sum(1 for m, p, h in ROUTES)} endpoints)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
