"""Export a single self-contained HTML build of the dashboard.

    python scripts/export_static.py

Every API response is captured by calling the route handlers directly, inlined
into the page, and served to the existing front-end code by a `fetch` shim.  The
result is one file that opens with a double-click - no Python, no server, no
network - which is useful as presentation-day insurance if anything goes wrong
with the live stack.

Limitations of the static build, stated on the page itself: approve/reject is
simulated in the browser and not persisted, and the Copilot answers only the
pre-computed question set.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.app import config, copilot, db, routes                # noqa: E402

DIST = ROOT / "dist"
# The offline build carries pre-computed answers.  Cover the questions an
# examiner is likely to ask, not just the rehearsed script: every RFQ, a spread
# of suppliers, and the portfolio-wide questions.
DEMO_QUESTIONS = list(copilot.SUGGESTIONS) + [
    "Why is Supplier A recommended?",
    "Why is supplier C high risk?",
    "Compare the top suppliers.",
    "What does the buyer contract say about warranty?",
    "Who has final approval authority?",
    "What are the risks on this RFQ?",
    "What are the alternatives?",
    "Which factors drive that risk?",
]

# Asked once each, without an RFQ context.
PORTFOLIO_QUESTIONS = [
    "How many suppliers have suspended FDA certification?",
    "Which suppliers are critical risk?",
    "List all blocked suppliers",
    "Which suppliers need review?",
    "Which suppliers are under a consent decree?",
    "Show me suppliers with ISO 13485 not certified",
    "What is the average risk score?",
    "How many RFQs are open?",
    "What is the total budget across all RFQs?",
    "Which supplier has the best on-time delivery?",
    "Which supplier is riskiest?",
    "What is the cheapest quote across all RFQs?",
    "Which RFQ has the most blocked suppliers?",
    "List all RFQs",
    "How many suppliers are blocked?",
    "who is pm of india",
    "hello",
]


def capture() -> dict:
    snap: dict[str, object] = {}

    def grab(path, handler, params=None, body=None):
        try:
            snap[path] = handler(params or {}, body or {})
        except Exception as exc:
            snap[path] = {"error": f"{type(exc).__name__}: {exc}"}

    grab("/api/health", routes.health)
    grab("/api/dashboard/summary", routes.dashboard_summary)
    grab("/api/rfqs", routes.list_rfqs)
    grab("/api/suppliers", routes.list_suppliers)
    grab("/api/risk", routes.risk_dashboard)
    grab("/api/knowledge-base", routes.knowledge_base)
    grab("/api/analytics", routes.analytics)
    grab("/api/settings", routes.settings)
    grab("/api/audit?limit=300", routes.list_audit, {"limit": 300})
    grab("/api/approvals", routes.list_approvals)
    grab("/api/model", routes.model_info)
    grab("/api/model/evaluation", routes.model_evaluation)

    with db.session() as conn:
        rfq_ids = [r["rfq_id"] for r in db.query(conn, "SELECT rfq_id FROM rfqs ORDER BY rfq_id")]
        sup_ids = [r["supplier_id"] for r in db.query(conn, "SELECT supplier_id FROM suppliers")]
        pairs = [(r["rfq_id"], r["supplier_id"]) for r in
                 db.query(conn, "SELECT rfq_id, supplier_id FROM rfq_quotes")]

    for rid in rfq_ids:
        grab(f"/api/rfqs/{rid}", routes.get_rfq, {"rfq_id": rid})
        grab(f"/api/rfqs/{rid}/suppliers", routes.rfq_suppliers, {"rfq_id": rid})
        grab(f"POST:/api/rfqs/{rid}/recommendation", routes.rfq_recommendation, {"rfq_id": rid})
    for sid in sup_ids:
        grab(f"/api/suppliers/{sid}", routes.get_supplier, {"supplier_id": sid})
        grab(f"/api/suppliers/{sid}/risk", routes.supplier_risk, {"supplier_id": sid})
    for rid, sid in pairs:
        grab(f"/api/rfqs/{rid}/suppliers/{sid}", routes.supplier_explanation,
             {"rfq_id": rid, "supplier_id": sid})

    # The document search the Contract Intelligence card issues on load.  The
    # key must match the URL the browser actually builds, which is percent-
    # encoded by encodeURIComponent.
    q = "delivery commitments warranty regulatory compliance award"
    grab(f"/api/documents/search?q={quote(q, safe='')}&k=4",
         routes.search_documents, {"q": q, "k": 4})

    # Pre-computed Copilot answers, keyed by question for every golden-path RFQ.
    canned: dict[str, dict] = {}

    def cache(question, rid):
        key = f"{rid or 'RFQ-102'}||{question.lower()}"
        try:
            canned[key] = copilot.answer(conn, question, rid)
        except Exception as exc:
            canned[key] = {"answer": f"Unavailable in the static build: {exc}",
                           "citations": [], "mode": "static", "intent": "error",
                           "in_scope": True, "suggestions": []}

    with db.session() as conn:
        # Every RFQ, so switching RFQ mid-demo still answers.
        for rid in rfq_ids:
            for question in DEMO_QUESTIONS:
                cache(question, rid)
        # Portfolio questions, keyed under every RFQ so the UI's current
        # selection never changes whether they resolve.
        for question in PORTFOLIO_QUESTIONS:
            for rid in rfq_ids:
                cache(question, rid)
        # A profile question for every supplier.
        for sid in sup_ids:
            for question in (f"Tell me about {sid}", f"What category does {sid} supply?"):
                for rid in rfq_ids[:1]:
                    cache(question, rid)
                cache(question, None)
    snap["__copilot__"] = canned
    return snap


SHIM = """
/* Static build: serve the captured snapshot instead of the network. */
(function () {
  const SNAP = window.__SNAPSHOT__;
  const canned = SNAP.__copilot__ || {};
  const localState = { approvals: [], audit: [] };

  function findCopilot(body) {
    const key = `${body.rfq_id || 'RFQ-102'}||${(body.question || '').toLowerCase().trim()}`;
    if (canned[key]) return canned[key];
    const q = (body.question || '').toLowerCase().trim();
    for (const k of Object.keys(canned)) {
      if (k.endsWith('||' + q)) return canned[k];
    }
    return {
      question: body.question,
      answer: 'This is the offline static build, which carries pre-computed answers to the '
        + 'demonstration question set only. Run the live application (python run.py) for '
        + 'free-form Copilot questions.\\n\\nTry one of the suggested questions below.',
      citations: [], mode: 'static build', intent: 'unsupported',
      rfq_id: body.rfq_id, supplier_id: body.supplier_id, facts: [], table: null,
    };
  }

  window.fetch = async function (path, opts) {
    opts = opts || {};
    const method = (opts.method || 'GET').toUpperCase();
    const body = opts.body ? JSON.parse(opts.body) : {};
    let data, ok = true;

    if (path === '/api/copilot/query') {
      data = findCopilot(body);
    } else if (path === '/api/approvals' && method === 'POST') {
      const now = new Date().toISOString();
      localState.approvals.unshift({
        rfq_id: body.rfq_id, supplier_id: body.supplier_id, decision: body.decision,
        approver: body.approver, reason: body.reason, decided_at: now,
        recommendation_score: null, risk_score: null,
      });
      localState.audit.unshift({
        created_at: now, event_type: 'HUMAN_DECISION', rfq_id: body.rfq_id,
        supplier_id: body.supplier_id, decision: body.decision, actor: body.approver,
        reason: (body.reason || 'Recorded in the static build (not persisted)'),
        decision_score: null, risk_score: null,
      });
      data = { approval_id: localState.approvals.length, ...body, decided_at: now,
               policy_override: false, static_build: true };
    } else if (path === '/api/approvals') {
      const base = SNAP['/api/approvals'] || { approvals: [], pending: [] };
      data = { approvals: localState.approvals.concat(base.approvals || []),
               pending: base.pending || [] };
    } else if (path.startsWith('/api/audit')) {
      const base = (SNAP['/api/audit?limit=300'] || { events: [] }).events || [];
      data = { events: localState.audit.concat(base) };
    } else if (path === '/api/reviews') {
      data = { status: 'review_logged' };
    } else {
      const key = method === 'POST' ? 'POST:' + path : path;
      data = SNAP[key] !== undefined ? SNAP[key] : SNAP[path];
      if (data === undefined) { ok = false; data = { error: 'Not captured in the static build: ' + path }; }
    }
    return { ok: ok && !(data && data.error), status: ok ? 200 : 404, json: async () => data };
  };
})();
"""

BANNER = """
<div style="background:#fdf3e0;border-bottom:1px solid #f5dfb2;color:#8a5a08;
  padding:9px 22px;font-size:12.5px;font-family:Inter,Segoe UI,sans-serif">
  <b>Offline static build.</b> All figures were computed by the full pipeline and frozen at export time.
  Approve/reject is simulated in the browser and not persisted, and the Copilot answers the
  pre-computed demonstration question set only. Run <code>python run.py</code> for the live application.
</div>
"""


def main() -> int:
    print("Capturing API snapshot...")
    snap = capture()
    print(f"  {len(snap) - 1} endpoint responses + "
          f"{len(snap['__copilot__'])} pre-computed Copilot answers")

    html = (config.FRONTEND_DIR / "index.html").read_text(encoding="utf-8")
    css = (config.FRONTEND_DIR / "styles.css").read_text(encoding="utf-8")
    js = (config.FRONTEND_DIR / "app.js").read_text(encoding="utf-8")

    html = html.replace('<link rel="stylesheet" href="styles.css">', f"<style>\n{css}\n</style>")
    payload = json.dumps(snap, default=str)
    html = html.replace(
        '<script src="app.js"></script>',
        f"<script>window.__SNAPSHOT__ = {payload};</script>\n"
        f"<script>{SHIM}</script>\n<script>\n{js}\n</script>")
    html = html.replace("<body>", "<body>\n" + BANNER)
    html = html.replace("<title>Procurement Copilot</title>",
                        "<title>Procurement Copilot (offline build)</title>")

    DIST.mkdir(exist_ok=True)
    out = DIST / "procurement-copilot-offline.html"
    out.write_text(html, encoding="utf-8")
    with open(config.STATIC_SNAPSHOT, "w", encoding="utf-8") as fh:
        json.dump(snap, fh, default=str)
    print(f"  wrote {out.relative_to(ROOT)}  ({out.stat().st_size / 1024:.0f} KB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
