# Architecture

## 1. Shape of the system

```
                    ┌──────────────────────────────────────────┐
   data/*.csv  ───►  ingest.py  ───►   SQLite (9 tables)        │
                    └──────────────────────┬───────────────────┘
                                           │ structured facts
        ┌──────────────────────────────────┼──────────────────────────────┐
        ▼                                  ▼                              ▼
   ml/train.py                        scoring.py                     rag/index.py
   risk probability                   decision score                 clause retrieval
   risk level                         price / delivery rules         (policy, contract,
   model confidence                   compliance hard rules           RFQs only)
   Shapley drivers                    eligibility routing
        │                                  │                              │
        └──────────────┬───────────────────┴──────────────┬───────────────┘
                       ▼                                  ▼
                 recommender.py                       copilot.py
             score + risk + policy + evidence     grounded answer frame
                       │                                  │
                       └───────────────┬──────────────────┘
                                       ▼
                                   routes.py
                          (one framework-agnostic table)
                            ┌──────────┴──────────┐
                            ▼                     ▼
                    api_fastapi.py         serve_stdlib.py
                            └──────────┬──────────┘
                                       ▼
                              frontend/ (10 screens)
                                       │
                                       ▼
                          human review → approve / reject
                                       │
                                       ▼
                          audit.py → approvals + audit_events
```

## 2. Decisions worth defending

### SQLite rather than PostgreSQL

The specification suggested PostgreSQL. The schema, the SQL and the access layer
are identical for this workload — the difference is a server process the demo
would depend on. `db.py` is written so the same schema can be pointed at
PostgreSQL later without touching call sites, and `PROCUREMENT_DB_PATH` allows
redirecting the file. For a single-buyer prototype scoring 120 quotations, a
network database adds a failure mode and nothing else.

### Two server adapters, one route table

`routes.py` holds every handler as a plain `(params, body) -> dict` function.
FastAPI is the primary adapter and gives OpenAPI docs at `/docs`. The
standard-library adapter serves the identical routes with nothing installed.

The point is not redundancy for its own sake — it is that the whole API surface
is unit-testable without starting a server, and the two adapters cannot drift
because neither owns any logic.

### A front end with no build step

Plain HTML, CSS and JavaScript. No npm, no bundler, no CDN — the artifact CSP and
demo-day network conditions both punish external dependencies. Ten screens, all
fed by the API, no hardcoded figures.

### Model backends: library first, reference implementation as fallback

`ml/backends.py` uses scikit-learn and XGBoost when importable. When they are
not, it falls back to the NumPy implementations in `ml/numpy_models.py` —
L2-regularised logistic regression, bagged CART with per-split feature
subsampling, and second-order gradient boosting with shrinkage and L2 leaf
regularisation. These are the same algorithms, not approximations, and the
evaluation report records which backend produced the reported metrics so results
are never ambiguous.

The same pattern applies to explainability (`shap`, else permutation Shapley).

### Retrieval: hybrid lexical rather than neural embeddings

The specification suggested Chroma or FAISS with an embedding model. This
implementation defaults to **BM25 + TF-IDF cosine fused by reciprocal rank
fusion**, over clause-level chunks. Three reasons, all specific to this corpus:

1. **Scale.** 17 short structured documents, 53 clause chunks. ANN indexing
   solves the problem of scaling past exact search; that problem does not exist
   here. Exact scoring over 53 chunks is instantaneous.
2. **Vocabulary.** The decisive queries are regulatory terms with exact surface
   forms — "510(k)", "ISO 13485", "consent decree", "RFQ-102". Lexical scoring
   matches these exactly. A general-purpose embedding model routinely conflates
   near-synonyms, which in a compliance setting means citing the wrong clause
   confidently.
3. **Reproducibility.** No model download, no GPU, identical results on every
   machine and every run — which is what an examiner re-running the repo needs.

Dense retrieval is not ruled out — it is now wired in as an **optional second
signal**, not a replacement. `EmbeddingBackend` in `rag/index.py` defines the
interface; `HuggingFaceEmbeddingBackend` activates whenever `HF_API_KEY` is set,
`SentenceTransformerBackend` if that package is installed instead. Its cosine
ranking joins the same reciprocal rank fusion. Swapping in Chroma or FAISS
touches that one file.

Three properties make the dense path safe to enable:

* **Down-weighted.** The dense ranking votes at `DENSE_FUSION_WEIGHT` (0.5)
  against 1.0 for each lexical ranking. Equal-weight fusion measurably hurt:
  a low-quality dense signal displaced the correct clause from the top 3 on a
  known-clause probe. Embeddings add recall; they do not override an exact
  regulatory term match.
* **Cached.** Chunk vectors are computed once at build time and stored in
  `models/rag_index.json`. Server startup makes no API call; only the query is
  embedded live.
* **Optional at every step.** A failed build-time embedding leaves a lexical
  index; a failed query embedding drops the dense signal for that query. Neither
  produces an error the user sees.

### Two retrievers, routed per question

The Copilot does not answer everything from documents.  It has two retrievers
and picks the right one:

| Question | Retriever | Why |
|---|---|---|
| "What does the policy say about suspended certifications?" | document (BM25 + TF-IDF, optional dense) | the answer *is written* in a clause |
| "How many suppliers have suspended FDA certification?" | structured (`query_engine.py`) | the answer must be *computed* from 50 records |
| "Which supplier should I select for RFQ-107?" | both | scores from SQL, the rule behind them from a cited clause |

**Numbers never pass through an embedding.**  Chunking supplier rows into text
and retrieving them by vector similarity is how a system ends up reporting the
wrong supplier's price with complete confidence.  Prices, risk scores and
certification statuses are read with a parameterised query; only prose is
retrieved semantically.  This is also what the specification requires:
structured supplier facts come from the database, never from retrieved text.

`query_engine.py` supports lookup, categorical filter, count, aggregation,
ranking with direction awareness ("best lead-time variability" means the
*lowest*), comparison, and portfolio views.  Column names come from a fixed
registry in that file and every user value is bound as a parameter, so the
question cannot alter the query's shape - there is no text-to-SQL surface to
attack.  Each result carries the SQL that produced it, so any figure on screen
is traceable to a statement.

### RFQ context is bound, not assumed

An earlier version defaulted every question to `DEFAULT_RFQ`.  That silently
answered "how many suppliers have suspended FDA certification?" with RFQ-102's
eight quotations.  An RFQ is now bound only when the question names one, or when
the UI has one selected *and* the question is not portfolio-wide.

### Section-aware chunking

The buyer documents are numbered clause documents. A clause is the unit a
procurement officer cites, so clause boundaries make better retrieval units —
and far better citations — than a fixed character window. RFQs are `Label: value`
sheets rather than prose, so they get their own splitter; that is why the system
can answer "what warranty does RFQ-102 require?" with the warranty line rather
than the whole sheet.

### Scoring runs per-RFQ, never per-supplier

Price is scored *relative to the competing quotations on the same RFQ*. That
makes the RFQ, not the supplier, the unit of scoring — which is why
`score_rfq(conn, rfq_id)` takes the whole quote set and returns a ranked list.

## 3. RAG scope enforcement

Enforced in three independent places, not just documented:

1. `rag/parse.discover_documents()` only ever constructs the three permitted
   document types and raises if anything else appears.
2. `config.ALLOWED_RAG_DOC_TYPES` is checked at index time.
3. `db.py` has no `supplier_contracts` table, and
   `ingest.integrity_report()` reports whether one has appeared. The build
   script fails if it has.

Supplier contact details are structured master data in the `suppliers` table and
are never treated as retrievable evidence.

## 4. Keeping the four quantities separate

The most important architectural property of this system is what it refuses to
combine.

- `scoring.py` computes the decision score and never calls a model.
- `ml/train.py` computes risk and confidence and never sees a price.
- `features.compliance_subscore` returns hard-rule flags *alongside* the score
  rather than folding them in, so policy can route on them independently.
- `recommender.py` is the only module that sees all four, and it presents them
  side by side rather than blending them into one number.

This is what makes "strong commercial offer, high predicted risk, blocked on
compliance" representable. A single blended score could not express it.

## 5. Determinism

Everything is seeded (`config.RANDOM_SEED = 42`): fold assignment, bootstrap
sampling, boosting subsampling, permutation-Shapley draws. Re-running
`scripts/build_all.py` reproduces identical numbers. The only non-deterministic
element is an optional LLM call, which cannot change any figure — it only
rephrases a frame that was already fully determined.

## 6. Failure behaviour

| Failure | Behaviour |
|---|---|
| Model not trained | API returns `{available: false, message}`; dashboard shows a prompt to build |
| Knowledge base missing | Retrieval returns a structured error; other screens unaffected |
| LLM unreachable or unconfigured | Deterministic grounded answer, mode string says so |
| Embedding API unreachable at build | Lexical index built, reason recorded in `embedding_error` |
| Embedding API unreachable at query | Dense signal dropped, lexical ranking stands |
| Unknown RFQ or supplier | 404 with a readable message |
| Unhandled exception in a handler | JSON error object, never an HTML error page |
| scikit-learn / XGBoost / shap absent | NumPy reference implementations, recorded in the report |
| FastAPI absent | Standard-library server, same routes |

No single failure takes the dashboard down; each screen degrades on its own.
