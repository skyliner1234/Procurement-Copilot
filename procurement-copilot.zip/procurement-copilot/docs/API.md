# API Reference

Auto-generated from `backend/app/routes.py` by `scripts/gen_api_docs.py`.
Regenerate after changing the route table so this file cannot drift.

Both server adapters register these same handlers, so FastAPI
(`uvicorn backend.api_fastapi:app`) and the standard-library server
(`python backend/serve_stdlib.py`) expose an identical surface. With FastAPI,
interactive docs are at `/docs`.

Errors are always JSON: `{"error": "..."}` with 400 for a bad request, 404 for an
unknown id, 503 for a missing artefact, and 500 for anything unhandled. No
endpoint returns an HTML error page.

---

### `GET /api/health`

health

Response shape:

```
status: "ok"
checks: {database: {buyers: …, suppliers: …, rfqs: …, rfq_quotes: …, orphan_quotes: …, rfqs_without_quotes: …, …}, model: bool, knowledge_base_chunks: number, llm: "deterministic fallback"}
```

---

### `GET /api/dashboard/summary`

dashboard summary

Response shape:

```
buyer: {buyer_id: "BUY-001", buyer_name: string, contact_name: "Priya Menon", contact_email: string, industry: string, country: "India", …}
counts: {active_rfqs: number, total_rfqs: number, suppliers: number, quotations: number, high_risk_suppliers: number, pending_approval: number}
risk_distribution: {CRITICAL: number, HIGH: number, LOW: number, MEDIUM: number}
recent_rfqs: [{rfq_id: …, equipment: …, quantity: …, budget_per_unit: …, required_delivery_days: …, status: …, …} × 6]
recent_recommendations: [{rfq_id: …, supplier_id: …, supplier_name: …, decision_score: …, risk_level: …, risk_score: …, …} × 6]
pending_approvals: [{rfq_id: …, supplier_id: …, decision_score: …, risk_score: …, risk_level: …, model_confidence: …, …} × 6]
highest_risk_suppliers: [{supplier_id: …, supplier_name: …, primary_product_category: …, risk_score: …, risk_level: …, risk_probability: …, …} × 6]
model: {available: bool, selected_model: "Random Forest", selection_rule: string, prediction_basis: string, explainability_method: "permutation-shapley", cv_design: string, …}
default_rfq: "RFQ-102"
golden_path_rfqs: ["RFQ-102" × 2]
copilot_suggestions: [string × 7]
disclaimer: string
```

---

### `GET /api/buyer`

buyer

Response shape:

```
buyer_id: "BUY-001"
buyer_name: string
contact_name: "Priya Menon"
contact_email: string
industry: string
country: "India"
procurement_policy_id: "POL-MED-001"
buyer_contract_id: "CON-MED-001"
```

---

### `GET /api/rfqs`

list rfqs

Response shape:

```
rfqs: [{rfq_id: …, buyer_id: …, equipment: …, clinical_use: …, quantity: …, budget_per_unit: …, …} × 15]
count: number
```

---

### `GET /api/rfqs/{rfq_id}`

get rfq

Response shape:

```
rfq_id: "RFQ-102"
buyer_id: "BUY-001"
equipment: "Infusion Pump"
clinical_use: string
quantity: number
budget_per_unit: number
required_delivery_days: number
required_certifications: string
warranty_months: number
service_sla_hours: number
issue_date: "2026-02-03"
status: "Open"
quotes: [{quote_id: …, rfq_id: …, supplier_id: …, supplier_name: …, quoted_unit_price: …, quoted_delivery_days: …, …} × 8]
documents: [{document_id: …, document_type: …, title: …, source_file: …, pages: …, chunks: …, …} × 1]
```

---

### `GET /api/rfqs/{rfq_id}/suppliers`

rfq suppliers

Response shape:

```
rfq: {rfq_id: "RFQ-102", buyer_id: "BUY-001", equipment: "Infusion Pump", clinical_use: string, quantity: number, budget_per_unit: number, …}
suppliers: [{rfq_id: …, supplier_id: …, supplier_name: …, primary_product_category: …, quoted_unit_price: …, quoted_delivery_days: …, …} × 8]
count: number
weights: {price: number, delivery: number, historical_performance: number, quality_reliability: number, regulatory_compliance: number, financial_service_resilience: number}
weight_labels: {price: "Price competitiveness", delivery: "Delivery performance", historical_performance: string, quality_reliability: string, regulatory_compliance: "Regulatory compliance", financial_service_resilience: string}
```

---

### `GET /api/rfqs/{rfq_id}/suppliers/{supplier_id}`

supplier explanation

Response shape:

```
rfq_id: "RFQ-102"
supplier_id: "MED-024"
supplier_name: "MediCore Medical Systems 19"
primary_product_category: "Ultrasound Systems"
quoted_unit_price: number
quoted_delivery_days: number
warranty_months: number
service_sla_hours: number
compliance_docs: "Yes"
total_evaluated_cost: number
vs_median_pct: number
price_score: number
delivery_score: number
historical_score: number
…
```

---

### `POST /api/rfqs/{rfq_id}/recommendation`

rfq recommendation

Request body: `{}`

Response shape:

```
rfq: {rfq_id: "RFQ-102", buyer_id: "BUY-001", equipment: "Infusion Pump", clinical_use: string, quantity: number, budget_per_unit: number, …}
recommendation: {rfq_id: "RFQ-102", supplier_id: "MED-024", supplier_name: "MediCore Medical Systems 19", decision_score: number, risk_score: number, risk_probability: number, …}
candidates: [{rfq_id: …, supplier_id: …, supplier_name: …, primary_product_category: …, quoted_unit_price: …, quoted_delivery_days: …, …} × 8]
```

---

### `GET /api/suppliers`

list suppliers

Response shape:

```
suppliers: []
count: number
```

---

### `GET /api/suppliers/{supplier_id}`

get supplier

Response shape:

```
supplier_id: "MED-024"
supplier_name: "MediCore Medical Systems 19"
contact_name: "Arjun Patel"
contact_email: string
contact_phone: "+91-9305718272"
primary_product_category: "Ultrasound Systems"
fda_status: "Certified"
ce_status: "Valid"
iso_13485_status: "Certified"
clearance_510k_status: "Cleared"
recalls_3y: number
adverse_events: number
months_since_inspection: number
last_inspection_outcome: "Warning letter"
…
```

---

### `GET /api/suppliers/{supplier_id}/risk`

supplier risk

Response shape:

```
supplier_id: "MED-024"
risk_probability: number
risk_score: number
risk_level: "LOW"
model_confidence: number
model_name: "Random Forest"
predicted_at: "2026-08-30T20:40:19+00:00"
available: bool
top_drivers: [{feature: …, label: …, value: …, contribution: …, contribution_pp: …, direction: …} × 6]
confidence_breakdown: {data_completeness: {value: …, weight: …, contribution: …}, probability_certainty: {value: …, weight: …, contribution: …}, model_agreement: {value: …, weight: …, contribution: …}, history_consistency: {value: …, weight: …, contribution: …}, rfq_data_completeness: {value: …, weight: …, contribution: …}}
bands: {LOW: "0-25", MEDIUM: ">25-50", HIGH: ">50-75", CRITICAL: ">75"}
confidence_note: string
```

---

### `GET /api/risk`

risk dashboard

Response shape:

```
suppliers: [{supplier_id: …, risk_probability: …, risk_score: …, risk_level: …, model_confidence: …, model_name: …, …} × 50]
distribution: {LOW: number, MEDIUM: number, HIGH: number, CRITICAL: number}
by_category: [{category: …, suppliers: …, avg_risk: …} × 8]
model: {available: bool, selected_model: "Random Forest", selection_rule: string, prediction_basis: string, explainability_method: "permutation-shapley", cv_design: string, …}
```

---

### `GET /api/model`

model info

Response shape:

```
available: bool
selected_model: "Random Forest"
selection_rule: string
prediction_basis: string
explainability_method: "permutation-shapley"
cv_design: string
n_samples: number
n_features: number
positive_rate: number
data_note: string
models: {logistic_regression: {accuracy: …, precision: …, recall: …, f1: …, roc_auc: …, brier: …}, random_forest: {accuracy: …, precision: …, recall: …, f1: …, roc_auc: …, brier: …}, xgboost: {accuracy: …, precision: …, recall: …, f1: …, roc_auc: …, brier: …}}
model_names: {logistic_regression: "Logistic Regression", random_forest: "Random Forest", xgboost: "XGBoost (gradient boosting)"}
backends: {logistic_regression: "numpy-reference", random_forest: "numpy-reference", xgboost: "numpy-reference"}
global_feature_importance: [{feature: …, label: …, mean_abs_contribution: …, mean_abs_pp: …} × 10]
…
```

---

### `GET /api/model/evaluation`

model evaluation

Response shape:

```
generated_at: "2026-08-30T20:40:19+00:00"
data_note: string
target: string
leakage_control: string
n_samples: number
n_features: number
positive_rate: number
cv_design: string
selection_rule: string
selected_model: "random_forest"
selected_model_name: "Random Forest"
prediction_basis: string
compute_backend: {sklearn_available: bool, xgboost_available: bool, note: string}
explainability_method: "permutation-shapley"
…
```

---

### `GET /api/knowledge-base`

knowledge base

Response shape:

```
retriever: "hybrid-bm25+tfidf"
embedding_model: null
total_chunks: number
allowed_document_types: ["buyer_master_contract" × 3]
excluded: string
documents: [{document_id: …, document_type: …, title: …, source_file: …, pages: …, chunks: …, …} × 17]
```

---

### `GET /api/documents/search`

search documents

Response shape:

```
query: "warranty"
results: [{citation: …, document_type: …, document_id: …, document_title: …, short_title: …, rfq_id: …, …} × 5]
```

---

### `POST /api/copilot/query`

copilot query

Request body: `{"question": "Which supplier should I select for RFQ-102?"}`

Response shape:

```
question: string
answer: string
mode: "grounded-deterministic"
intent: "compare"
in_scope: bool
scope_reason: null
rfq_id: "RFQ-102"
supplier_id: "MED-024"
supplier_name: "MediCore Medical Systems 19"
facts: [string × 1]
table: null
citations: [{citation: …, document_type: …, document_id: …, document_title: …, short_title: …, rfq_id: …, …} × 4]
suggestions: []
source: string
…
```

---

### `POST /api/approvals`

create approval

Request body: `{rfq_id, supplier_id, decision: APPROVED|REJECTED, approver, reason}`

Returns the persisted approval, including `policy_override: bool`. Approving a BLOCKED supplier without a written reason is rejected with 400.

---

### `GET /api/approvals`

list approvals

Response shape:

```
approvals: []
pending: [{rfq_id: …, supplier_id: …, decision_score: …, risk_score: …, risk_level: …, model_confidence: …, …} × 15]
```

---

### `POST /api/reviews`

create review

Request body: `{"rfq_id": "RFQ-102", "supplier_id": "MED-024", "reviewer": "docs"}`

Response shape:

```
status: "review_logged"
rfq_id: "RFQ-102"
supplier_id: "MED-024"
```

---

### `GET /api/audit`

list audit

Response shape:

```
events: [{event_id: …, rfq_id: …, supplier_id: …, event_type: …, decision_score: …, risk_score: …, …} × 3]
```

---

### `GET /api/analytics`

analytics

Response shape:

```
spend_by_rfq: [{rfq_id: …, equipment: …, quantity: …, budget_per_unit: …, min_price: …, max_price: …, …} × 15]
score_spread: [{rfq_id: …, n: …, min_score: …, avg_score: …, max_score: …, blocked: …} × 15]
fda_status_mix: [{fda_status: …, n: …} × 5]
eligibility_mix: [{eligibility: …, n: …} × 3]
model: {available: bool, selected_model: "Random Forest", selection_rule: string, prediction_basis: string, explainability_method: "permutation-shapley", cv_design: string, …}
weights: {price: number, delivery: number, historical_performance: number, quality_reliability: number, regulatory_compliance: number, financial_service_resilience: number}
weight_labels: {price: "Price competitiveness", delivery: "Delivery performance", historical_performance: string, quality_reliability: string, regulatory_compliance: "Regulatory compliance", financial_service_resilience: string}
```

---

### `GET /api/settings`

settings

Response shape:

```
weights: {price: number, delivery: number, historical_performance: number, quality_reliability: number, regulatory_compliance: number, financial_service_resilience: number}
weight_labels: {price: "Price competitiveness", delivery: "Delivery performance", historical_performance: string, quality_reliability: string, regulatory_compliance: "Regulatory compliance", financial_service_resilience: string}
risk_bands: {LOW: "0-25", MEDIUM: ">25-50", HIGH: ">50-75", CRITICAL: ">75"}
confidence_weights: {data_completeness: number, probability_certainty: number, model_agreement: number, history_consistency: number, rfq_data_completeness: number}
suspicious_low_bid_ratio: number
llm_enabled: bool
llm_provider: string
llm_model: null
dense_retrieval_enabled: bool
embedding_model: null
retriever: "hybrid-bm25+tfidf"
hugging_face_key_present: bool
rag_top_k: number
allowed_rag_document_types: ["buyer_master_contract" × 3]
…
```

---
