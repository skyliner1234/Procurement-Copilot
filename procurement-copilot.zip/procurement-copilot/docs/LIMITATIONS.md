# Limitations and Assumptions

Read this before presenting. Being first to name a weakness is worth more in a
viva than being caught not knowing it.

## Data

1. **Everything is synthetic.** One buyer, 50 suppliers, 15 RFQs, 120
   quotations, generated from a supplied seed dataset. No figure here describes a
   real supplier.
2. **The correlations were designed in.** The generator encoded relationships
   (poor history → lower delivery → higher disruption risk). The model recovering
   them shows the pipeline works; it is not evidence those relationships hold in
   the world.
3. **n = 50 with 18 positive labels.** Small. Confidence intervals on every
   metric are wide. This is why repeated cross-validation is used and why every
   metric is reported with a standard deviation.
4. **No time dimension.** Suppliers have no history over time, so there is no
   forward-chaining temporal validation. Real supplier risk drifts and would
   require it.
5. **The label is one binary event**, not a disruption rate. A production system
   would model time-to-event or a frequency.

## Model

6. **AUC ≈ 0.73** is a real but modest signal. It is what an honest pipeline
   produces from this data. An AUC near 1.0 would indicate leakage, and the test
   suite fails the build above 0.999.
7. **No hyper-parameter search.** Sensible defaults, held fixed across all three
   candidates so the comparison is fair. Tuning on 50 rows would over-fit the
   validation folds.
8. **No calibration curve.** Brier score is reported; a reliability diagram on 50
   points would not be meaningful.
9. **Displayed risk is out-of-fold.** Honest for these 50 suppliers, but it means
   the number shown is not the one the deployed all-data model would produce for a
   genuinely new supplier.
10. **Shapley values are estimates.** Exact Shapley over 23 features is 2²³
    coalitions; 200 sampled permutations per supplier converge closely but are not
    exact. Small attributions should not be over-read.

## Scoring

11. **The weights are the buyer's policy, not a derived optimum.** 25/20/20/15/15/5
    comes from POL-MED-001 §3. It is defensible because it is the buyer's stated
    priority, not because it was fitted to anything. The reweighting check exists
    precisely because a single weighting is an assumption.
12. **Sub-score normalisation bounds are judgement calls.** The best/worst anchors
    in `features.py` (e.g. field failure 0%→100, 7%→0) were chosen from the observed
    data range. They are explicit and auditable, but they are choices.
13. **Total evaluated cost is unit price × quantity.** No landed cost, duties,
    lifecycle service cost or financing. A real evaluation would include them.
14. **No multi-award or split-award logic.** One RFQ, one recommended supplier.

## RAG

15. **The corpus is small and clean** — 17 short structured documents. Retrieval
    quality here does not predict performance on a large heterogeneous corpus.
16. **Lexical retrieval has a known weakness**: a question phrased entirely in
    synonyms the documents never use may miss. A small, auditable synonym table
    mitigates this; a dense retriever would handle it better and the interface to
    plug one in exists.
17. **Retrieval is evaluated by known-clause probes**, not by a labelled
    relevance set with recall@k over many queries. Honest for a prototype; not a
    formal IR evaluation.
17a. **Structured retrieval is a fixed operation set**, not general
    text-to-SQL: lookup, filter, count, aggregate, rank, compare and portfolio
    views over a registry of ~26 fields and ~14 categorical filters. A question
    needing a join or an operation outside that set falls back to the
    per-RFQ/per-supplier answer. This is a deliberate trade - an LLM generating
    SQL would cover more phrasings but could emit a wrong query and report a
    confident wrong number, which is the failure this system exists to avoid.
18. **No cross-encoder reranking.** Reciprocal rank fusion over two lexical
    signals only. At 53 chunks it is not the bottleneck.

## Copilot

19. **Intent routing is rule-based** — keyword precedence, not a trained
    classifier. Transparent and debuggable, but a question phrased unusually may
    route to a general answer.
19a. **Scope is enforced by a vocabulary gate**, not a classifier. Questions
    outside procurement are declined rather than answered. The gate uses layered
    signals (RFQ/supplier identifier, domain vocabulary and stems, supplier name,
    document match) and is tuned to never reject a legitimate procurement
    question — measured at 49/49 on the probe set in `TestCopilot`. A question
    using only vocabulary the gate does not know could still be declined; the
    refusal says what the system can answer, so the failure is visible and
    recoverable rather than silent.
20. **Not multi-turn.** UI context (selected RFQ and supplier) is passed, but
    there is no conversation memory across questions.
21. **With an LLM configured, phrasing is not deterministic.** Facts and
    citations are fixed by the grounded frame; wording is not. The deterministic
    mode is fully reproducible — use it for anything you need to reproduce
    exactly in a report.
22. **Hugging Face adds an external dependency when enabled.** Generation needs
    a live call per question; retrieval needs one per query (chunk vectors are
    cached, so the corpus is embedded only at build time). Both degrade to the
    offline path on failure, but response times become network-dependent, and
    free-tier models can be cold-started or rate-limited.
23. **The embedding model is not tuned for this domain.** `all-MiniLM-L6-v2` is
    a general-purpose encoder; it has no medical-device or procurement-contract
    training. That is precisely why the dense ranking is down-weighted rather
    than trusted equally — and why the lexical-vs-hybrid comparison is worth
    reporting rather than assuming hybrid is better.

## System

24. **Single buyer, no authentication, no roles.** The approver is a typed name,
    not an authenticated identity. Production would need real auth and
    segregation of duties.
25. **The audit trail is append-only by convention**, not cryptographically. No
    hash chain or tamper evidence.
26. **No concurrency control** on approvals. Two simultaneous decisions on the
    same RFQ would both be recorded.
27. **SQLite, single file.** Fine for this scale; `db.py` is written so the schema
    can move to PostgreSQL without touching call sites.

## What this prototype does demonstrate

- A working end-to-end pipeline: data → ML → deterministic scoring → retrieval →
  cited recommendation → human decision → audit.
- Four quantities (decision score, risk, confidence, policy eligibility) kept
  rigorously separate, so "good offer, risky supplier, blocked on compliance" is
  representable.
- Regulatory hard rules that route decisions independently of price.
- Feature-level explanations in a unit a procurement officer can act on.
- Retrieval scoped to buyer documents only, with clause-level citations.
- Human authority preserved at every point, with overrides permitted and
  permanently recorded.

## What it does not

- Predict real supplier disruption.
- Replace procurement judgement.
- Provide production-grade security, scale or governance.
