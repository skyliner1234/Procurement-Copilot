# ML Methodology

> **Prototype result on synthetic data.** n = 50 suppliers, 18 positive labels.
> The figures below demonstrate the methodology. They are not estimates of
> real-world supplier disruption risk and do not transfer to real suppliers.

Regenerate everything here with `python scripts/build_all.py`; the authoritative
artefact is `models/model_evaluation.json`.

---

## 1. Problem framing

**Target.** `Historical Disruption Label` — a material supply-disruption or
late-delivery event attributed to the supplier. Binary, supplier-level.

**Prevalence.** 18 / 50 = 36% positive. Imbalanced enough to matter; class
weighting is applied in every model.

**What this is not.** It is not a delivery-date regression and not a rate over
time. It is a single historical binary event per supplier, which is a real
limitation (see §7).

---

## 2. Features and leakage control

23 features across delivery reliability, quality, regulatory, resilience and
financial signals. The full list is `config.ML_FEATURES`; construction is in
`features.ml_feature_vector`.

**The dataset contains a trap.** `Synthetic Disruption Probability` is the latent
generator parameter from which the label was drawn. A model given that column
would score near-perfectly and would have learned nothing — the column *is* the
answer. It is therefore excluded from the feature set and retained only as a
diagnostic column. `TestFeatures.test_no_target_leakage_in_features` enforces
this.

Categorical fields (FDA status, CE marking, ISO 13485, 510(k), inspection
outcome, credit rating, backup facility) are mapped through explicit,
auditable vocabularies in `config.py` rather than one-hot encoded, so that an
unseen value degrades to a conservative mid-value instead of raising.

---

## 3. Validation design

With n = 50, a single train/test split leaves a test fold of about 10 rows —
one supplier moving across the threshold swings accuracy by 10 points. A single
hold-out number here would be noise reported as a result.

**Design: 5-fold stratified cross-validation, repeated 10 times.** 50 fits per
model. Metrics are pooled out-of-fold within each repeat, then reported as
mean ± standard deviation across repeats. The standard deviation is the honest
statement of how much the number moves when the folds move.

Stratification preserves the 36% positive rate in every fold.

---

## 4. Model comparison

Three candidates, as specified. Logistic Regression is the declared baseline.

| Metric | Logistic Regression | **Random Forest** | XGBoost |
|---|---|---|---|
| ROC-AUC | 0.678 ± 0.031 | **0.730 ± 0.030** | 0.682 ± 0.050 |
| F1 | 0.500 ± 0.049 | **0.576 ± 0.022** | 0.551 ± 0.055 |
| Accuracy | 0.636 | **0.726** | 0.690 |
| Precision | 0.498 | **0.652** | 0.580 |
| Recall | 0.506 | 0.517 | **0.528** |
| Brier score (lower better) | 0.242 | **0.189** | 0.237 |

**Selection rule, fixed before results were seen:** highest mean cross-validated
ROC-AUC; ties broken on mean F1, then on Brier score.

**Selected: Random Forest.** XGBoost was not forced to win and did not win. It
also carries the widest AUC spread (± 0.050), which is what over-fitting looks
like at this sample size: a boosted ensemble with 200 rounds has far more
capacity than 40 training rows can constrain. Random Forest's bagging averages
that variance away, and its Brier score of 0.189 says its probabilities are the
best calibrated of the three — which matters, because those probabilities are
displayed as percentages that a procurement officer will act on.

`TestMLMetrics.test_selection_rule_actually_picked_the_best_auc` re-derives the
choice from the artefact, so the claim cannot silently rot.

**How to read AUC 0.73.** It is a real signal, well above chance, and modest. It
is exactly what an honest pipeline produces from 50 synthetic rows. An AUC above
0.99 here would be evidence of leakage, not of quality — the test suite fails the
build if any model exceeds 0.999.

---

## 5. What the model learned

Global importance, mean |Shapley value| in percentage points of predicted risk:

| Feature | Mean effect |
|---|---|
| Lead-time variability (days) | 4.32 pp |
| On-time delivery % | 4.05 pp |
| Complaint rate / 1000 units | 2.70 pp |
| Demand-to-capacity ratio % | 2.27 pp |
| Capacity utilisation % | 2.09 pp |
| Historical performance score | 2.05 pp |
| Warranty claim rate % | 1.96 pp |
| Batch rejection rate % | 1.93 pp |

This ordering is the correct sanity check on the whole exercise: delivery
consistency dominates, quality signals follow, and capacity pressure appears
where it should. A model that had ranked, say, credit rating first would have
been a reason to distrust the pipeline.

---

## 6. Predictions, explanations and confidence

### Out-of-fold predictions

The final models are fitted on all 50 suppliers — that artefact is what would
score a *new* supplier. But the risk displayed for the 50 suppliers already in
the training set is their **cross-validated out-of-fold probability**, averaged
across repeats. No supplier is ever shown a score from a model that saw its own
label. In-sample probabilities would cluster near 0 and 1 and would look far more
decisive than the evidence supports.

Resulting distribution: LOW 25, MEDIUM 11, HIGH 6, CRITICAL 8.

### Shapley attributions

`shap` is used when installed. Otherwise attributions are estimated by
permutation sampling — for each random feature ordering, features are switched
from a background row to the instance's own value and the marginal change in
predicted probability is that feature's contribution; averaging over orderings
converges to the exact Shapley value (Štrumbelj & Kononenko, 2014). Same value
function, different estimator, so the semantics of the explanation do not change
with the environment. 200 permutations per supplier, batched.

Attributions are reported in percentage points of predicted probability, which
is the unit a procurement officer can actually reason about: "lead-time
variability of 19 days adds 4.5 points to this supplier's risk."

### Confidence is not the inverse of risk

Confidence measures the strength and consistency of the evidence behind a
prediction. Five weighted components:

| Component | Weight | What it captures |
|---|---|---|
| Data completeness | 25% | How much of the supplier's feature record is populated |
| Probability certainty | 25% | Distance of p from the 0.5 decision boundary |
| Model agreement | 20% | Spread of the three candidates' probabilities for this supplier |
| History consistency | 20% | Agreement between the learned model and a rule-based evidence view |
| RFQ data completeness | 10% | Completeness of the quotation and RFQ fields |

A supplier can be **confidently high-risk** (rich, consistent, unambiguous
evidence) or **unconfidently low-risk** (sparse data, a probability near the
boundary, models disagreeing). Those are different situations and a buyer needs
to tell them apart. `TestRiskAndConfidence.test_confidence_is_not_the_inverse_of_risk`
asserts the two series are not related by `100 − risk`.

The rule-based "evidence view" used for the consistency check is built only from
the deterministic sub-scores. It never feeds the model or the decision score; it
exists purely as an independent second opinion.

---

## 7. Limitations

1. **Synthetic data.** Absolute metric values do not transfer to real suppliers.
2. **n = 50, 18 positives.** Confidence intervals on every metric are wide. This
   is why repeated CV is used and why the standard deviation is always shown.
3. **Single binary label.** The target is one historical event, not a disruption
   rate over time. A production system would model time-to-event or a rate.
4. **No temporal validation.** There is no time dimension in the data, so there
   is no forward-chaining split. Real supplier risk drifts and would require it.
5. **Correlations are designer-imposed.** The generator built in relationships
   (poor history → higher disruption risk). The model recovering them is evidence
   the pipeline works, not evidence those relationships hold in the world.
6. **No calibration curve.** Brier score is reported; a reliability diagram on 50
   points would not be meaningful.

## 8. Separate evaluation tracks

Per the academic requirement, four things are evaluated separately and never
merged into one headline number:

| Track | How it is evaluated | Where |
|---|---|---|
| Predictive ML | Repeated stratified CV, 6 metrics, 3 models | `models/model_evaluation.json`, Reports screen |
| Retrieval | Known-clause probes: each question must surface the clause a procurement officer would cite | `TestRag.test_retrieval_precision_on_known_clauses` |
| Procurement scoring | Weighted-sum identity, price relativity, hard-rule routing, reweighting robustness | `TestScoring`, `TestComplianceHardRules` |
| Explanation quality | Every recommendation carries reasons, concerns and citations to permitted documents | `TestRecommendation`, `TestCopilot` |

**No performance number in this repository was written by hand.** Every figure in
this document was read out of the generated artefact.
