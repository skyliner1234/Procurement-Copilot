---
title: "AI-Powered Medical Equipment Supplier Risk Intelligence and Procurement Copilot"
subtitle: "A hybrid retrieval and explainable-ML decision-support system for hospital procurement"
author: "Yash Sharma — M.Tech Capstone Project"
date: "September 2026"
---

\newpage

# Abstract

Hospital procurement of medical equipment is a decision in which the cheapest
compliant offer is frequently the wrong answer. Patient safety, regulatory
standing and delivery reliability carry weight that a purely commercial
evaluation does not capture, and the consequences of a wrong award are clinical
rather than merely financial.

This project builds an end-to-end decision-support system for that setting. It
combines a machine-learned supplier disruption-risk model, a deterministic and
configurable procurement scoring engine, a retrieval layer over the buyer's own
governing documents, and a natural-language Copilot that answers procurement
questions from those sources and nothing else. Every recommendation is routed to
a human approver, and every step is written to an audit trail.

The central design commitment is that the system **does not select suppliers**.
It assembles evidence so that a procurement officer can decide, and it records
what it showed them. Four quantities — decision score, predicted risk, model
confidence and policy eligibility — are computed by four different mechanisms
and deliberately never merged, because merging them destroys the case the buyer
most needs to see: a commercially attractive supplier that is nonetheless
blocked on compliance.

Three candidate classifiers were compared under 5-fold stratified
cross-validation repeated ten times. Random Forest was selected on a rule fixed
before results were observed (mean ROC-AUC 0.730 ± 0.030), outperforming both
the logistic-regression baseline (0.678 ± 0.031) and XGBoost (0.682 ± 0.050).
Retrieval uses a hybrid lexical index over clause-level chunks, scoring 6/6 on
known-clause probes, with structured SQL retrieval handling any question whose
answer must be computed rather than quoted. The implementation is approximately
9,500 lines, verified by 139 automated checks, and reproduces identical results
on every run.

All data is synthetic. Every quantitative result in this report is a prototype
result on synthetic data and is labelled as such.

\newpage

# 1. Introduction

## 1.1 Background

Medical-equipment procurement differs from general commercial sourcing in three
respects that matter to system design.

First, **regulatory standing is a gate, not a score.** A supplier whose FDA
certification is suspended, or which lacks the mandatory product clearance for
the device being bought, cannot be awarded regardless of how attractive its
commercial offer is. A weighted average that lets a low price compensate for a
missing clearance is not merely suboptimal; it is a mechanism for producing
awards that should never have been made.

Second, **failure is clinical.** An infusion pump that arrives late or fails in
the field is not an inventory problem. This asymmetry justifies weighting
delivery reliability and quality history far more heavily than a general
procurement function would.

Third, **the decision must be defensible after the fact.** Public-hospital
procurement is audited. A recommendation that cannot be traced to a rule and a
record is of limited use even when it happens to be correct.

## 1.2 Problem statement

Given a set of supplier quotations against a request for quotation (RFQ),
produce a ranked, explainable evaluation that:

- predicts the risk of material supply disruption for each supplier;
- scores each quotation against the buyer's stated evaluation priorities;
- enforces the buyer's regulatory rules independently of commercial merit;
- grounds every contractual claim in a citable clause of the buyer's own
  documents;
- explains itself in natural language without inventing facts; and
- leaves the award decision to a human, with a durable record of what was shown.

## 1.3 Objectives

1. Generate and ingest a realistic synthetic dataset: one buyer, 50 suppliers,
   15 RFQs and 120 quotations.
2. Train and honestly compare Logistic Regression, Random Forest and XGBoost for
   supplier disruption prediction, selecting on a pre-declared rule.
3. Produce, per supplier, a risk probability, a risk band, a model confidence
   that is *not* the inverse of risk, and feature-level explanations.
4. Implement a configurable procurement decision score in which price cannot
   dominate safety or compliance.
5. Build a retrieval pipeline restricted to buyer RFQs, the buyer procurement
   policy and the buyer master contract, with clause-level citations.
6. Build a Copilot that answers from structured records and cited documents,
   and refuses anything it cannot ground.
7. Enforce human-in-the-loop approval and a complete audit trail.
8. Deliver a professional dashboard exposing all of the above.

## 1.4 Scope and assumptions

**In scope.** A single buyer (BUY-001, AarogyaCare Hospitals & Clinical
Network); medical equipment only; synthetic data throughout; a working prototype
optimised for a reliable, reproducible demonstration.

**Explicitly out of scope.** Supplier contracts are excluded from the knowledge
base and from the database schema by design — this is a stated requirement of
the specification and is enforced in three independent places. Live supplier
APIs, ERP integration and geopolitical feeds are not used; the system is fully
offline-capable.

**Key assumption.** The synthetic generator encoded plausible correlations (poor
history leads to lower delivery reliability, which leads to higher disruption risk). The model
recovering those correlations demonstrates that the pipeline functions; it is
not evidence that the relationships hold in the world.

## 1.5 Contributions

1. **A four-quantity separation** maintained from computation through to the
   user interface, with an automated test asserting that model confidence is not
   derivable as `100 − risk`.
2. **A hybrid retrieval architecture** that routes each question to either
   structured SQL retrieval or document retrieval, on the principle that
   numeric facts must never pass through an embedding.
3. **Regulatory hard rules that route independently of score**, so that a
   blocked supplier cannot be recommended however well it scores.
4. **A methodologically honest ML evaluation** on a small sample: repeated
   stratified cross-validation, out-of-fold reporting, explicit leakage control,
   and a selection rule fixed before results were seen — with the result that
   the "expected" winner, XGBoost, lost and was left losing.
5. **Graceful degradation at every external dependency**, such that no library,
   network or API failure can prevent the system from running.

\newpage

# 2. Background and related work

This section situates the design choices; it does not claim novelty in the
underlying algorithms.

**Retrieval-augmented generation.** Lewis et al. (2020) established the pattern
of conditioning a generator on retrieved documents to ground its output. The
present system applies the grounding principle but inverts the usual emphasis:
retrieval and fact assembly are the substance, and the language model is an
optional renderer that cannot introduce facts.

**Lexical retrieval.** BM25 (Robertson and Zaragoza, 2009) remains a strong
baseline, particularly where queries contain exact technical surface forms.
Reciprocal rank fusion (Cormack, Clarke and Buettcher, 2009) combines rankings
from heterogeneous scorers without requiring score calibration, and is used here
to merge BM25, TF-IDF cosine and — when enabled — dense embedding similarity.

**Ensemble classifiers.** Random Forest (Breiman, 2001) reduces variance by
bagging decorrelated trees. Gradient boosting as implemented by XGBoost (Chen
and Guestrin, 2016) achieves strong performance on tabular data at larger sample
sizes. The comparison in Section 7 illustrates the well-known result that the
variance reduction of bagging is more valuable than the bias reduction of
boosting when the training set is very small.

**Explainability.** SHAP (Lundberg and Lee, 2017) provides an additive
attribution grounded in Shapley values from cooperative game theory. Where the
`shap` package is unavailable, this implementation estimates the same quantity by
permutation sampling (Štrumbelj and Kononenko, 2014), which converges to the
exact Shapley values, so the semantics of the explanation do not change with the
runtime environment.

**Text-to-SQL.** Systems that translate natural language into SQL with a
language model achieve broad phrasing coverage at the cost of occasionally
emitting a wrong query and reporting a confidently wrong number. Section 5.7
explains why this project deliberately uses a fixed, registry-bound operation set
instead.

\newpage

# 3. System architecture

## 3.1 Overview

```
   data/*.csv  ──►  ingest.py  ──►  SQLite (9 tables)
   17 buyer PDFs ─►  rag/parse ──►  clause index (53 chunks)
                            │
        ┌───────────────────┼────────────────────┐
        ▼                   ▼                    ▼
   ml/train.py         scoring.py           rag/retrieve.py
   risk probability    decision score       cited clauses
   risk band           price/delivery rules  query_engine.py
   confidence          compliance flags      computed facts
   Shapley drivers     eligibility routing
        │                   │                    │
        └─────────┬─────────┴──────────┬─────────┘
                  ▼                    ▼
            recommender.py         copilot.py
                  │                    │
                  └─────────┬──────────┘
                            ▼
                        routes.py
                  ┌─────────┴─────────┐
                  ▼                   ▼
          api_fastapi.py      serve_stdlib.py
                  └─────────┬─────────┘
                            ▼
                    frontend (10 screens)
                            ▼
               human review → approve / reject
                            ▼
              audit.py → approvals + audit_events
```

## 3.2 The four quantities

The most important architectural property of this system is what it refuses to
combine.

| Quantity | Question answered | Mechanism | Range |
|---|---|---|---|
| Decision score | Which offer is best for this RFQ? | Deterministic weighted sum | 0–100 |
| Risk | What is likely to happen? | Learned classifier | 0–100 + band |
| Model confidence | How far should this prediction be trusted? | Evidence-strength formula | 0–100 |
| Policy eligibility | What is permitted? | Hard rules over regulatory evidence | 3 states |

`scoring.py` computes the decision score and never calls a model.
`ml/train.py` computes risk and confidence and never sees a price.
`features.compliance_subscore` returns hard-rule flags *alongside* the compliance
score rather than folding them in, so policy can route on them independently.
`recommender.py` is the only module that sees all four, and it presents them
side by side rather than blending them.

## 3.3 Technology choices and justifications

| Decision | Chosen | Rationale |
|---|---|---|
| Database | SQLite | Identical schema and SQL to PostgreSQL for this workload; removes a server process from the demonstration. `db.py` is written so the schema can be repointed without touching call sites. |
| API | FastAPI, with a standard-library fallback | Both adapters register the same handler table from `routes.py`, so the HTTP surface cannot drift and the whole API is testable without starting a server. |
| Frontend | Hand-written HTML/CSS/JS | No build step, no CDN, no npm. Ten screens, all fed by the API, no hardcoded figures. |
| ML backend | scikit-learn / XGBoost, with NumPy reference implementations | The same algorithms, not approximations. The evaluation artefact records which backend produced the reported metrics. |
| Retrieval | Hybrid BM25 + TF-IDF, optional dense | Justified in Section 5.7. |

\newpage

# 4. Dataset

## 4.1 Composition

| Entity | Count | Notes |
|---|---|---|
| Buyer | 1 | BUY-001, AarogyaCare Hospitals & Clinical Network |
| Suppliers | 50 | 44 raw attributes each |
| RFQs | 15 | RFQ-101 … RFQ-115, distinct equipment types |
| Quotations | 120 | 8 per RFQ |
| Knowledge-base documents | 17 | 1 policy, 1 master contract, 15 RFQ PDFs |

Supplier attributes span regulatory standing (FDA, CE, ISO 13485, 510(k),
recalls, adverse events, inspection outcomes), quality (batch rejection,
complaints, CAPA frequency, field failure, MTBF, warranty claims), financial
position (credit rating, revenue growth, debt-to-equity, liquidity, payment
history), delivery (on-time delivery, lead-time variability, fulfilment
accuracy), and resilience (capacity utilisation, country risk, alternate
suppliers, sites, inventory cover, backup facility, distance and transit).

## 4.2 Integrity

Ingestion is validated on every build: 0 orphan quotations, 0 RFQs without
quotations, and an assertion that no `supplier_contracts` table exists. The build
fails if any of these is violated.

## 4.3 Label distribution

The prediction target is `Historical Disruption Label`, a binary indicator of a
material supply-disruption or late-delivery event attributed to the supplier.
18 of 50 suppliers are positive — a 36% prevalence, imbalanced enough that class
weighting is applied in every candidate model.

\newpage

# 5. Methodology

## 5.1 Feature engineering and leakage control

Two distinct products are derived from each supplier record and never mixed:
**model features** (23 numeric inputs to the risk classifier) and **sub-scores**
(five deterministic 0–100 values feeding the procurement score). Categorical
attributes are mapped through explicit vocabularies so that an unseen value
degrades to a conservative mid-point rather than raising an exception.

**Leakage control.** The supplied dataset contains a column,
`Synthetic Disruption Probability`, which is the latent generator parameter from
which the label was drawn. A model given that column would score near-perfectly
while learning nothing, because the column *is* the answer. It is therefore
excluded from the feature set and retained only as a diagnostic. An automated
test asserts its absence, so the exclusion cannot be silently reversed.

## 5.2 Risk model

**Validation design.** With n = 50 and 18 positives, a single train/test split
leaves a test fold of roughly ten rows; one supplier crossing the threshold moves
accuracy by ten points. A single hold-out figure at this scale is noise reported
as a result. The design is therefore **5-fold stratified cross-validation
repeated 10 times** — 50 fits per model — with metrics pooled out-of-fold within
each repeat and reported as mean ± standard deviation across repeats.

**Selection rule, fixed before results were observed:** highest mean
cross-validated ROC-AUC; ties broken on mean F1, then on Brier score.

**Reported predictions.** The final models are fitted on all 50 suppliers, since
that is the artefact which would score a genuinely new supplier. However, the
risk *displayed* for each of the 50 suppliers already in the training set is its
**cross-validated out-of-fold probability**, averaged across repeats. No supplier
is ever shown a score produced by a model that saw its own label; in-sample
probabilities would cluster near 0 and 1 and appear far more decisive than the
evidence supports.

## 5.3 Explainability

Feature attributions are Shapley values expressed in percentage points of
predicted probability — a unit a procurement officer can reason about ("lead-time
variability of 19 days adds 4.5 points to this supplier's risk"). The `shap`
package is used when installed; otherwise attributions are estimated by
permutation sampling over 200 orderings per supplier, batched for tractability.

## 5.4 Model confidence

Confidence measures the strength and consistency of the evidence behind a
prediction, and is explicitly **not** `100 − risk`. Five weighted components:

| Component | Weight | Captures |
|---|---|---|
| Data completeness | 25% | Proportion of the supplier's feature record populated |
| Probability certainty | 25% | Distance of *p* from the 0.5 decision boundary |
| Model agreement | 20% | Dispersion of the three candidates' probabilities |
| History consistency | 20% | Agreement between the model and a rule-based second opinion |
| RFQ data completeness | 10% | Completeness of the quotation and RFQ fields |

A supplier can therefore be *confidently high-risk* (rich, consistent evidence)
or *unconfidently low-risk* (sparse data, a probability near the boundary,
models disagreeing). These are different situations and a buyer must be able to
distinguish them.

## 5.5 Procurement decision score

$$\text{Score} = 0.25 P + 0.20 D + 0.20 H + 0.15 Q + 0.15 C + 0.05 R$$

where *P* is price competitiveness, *D* delivery performance, *H* historical
supplier performance, *Q* quality and reliability, *C* regulatory compliance and
*R* financial and service resilience. Weights are those stated in the buyer's own
procurement policy (POL-MED-001 §3) and are read from `data/scoring_spec.json` at
request time, making the engine configurable without code changes.

**Price is scored relative to competing quotations on the same RFQ**, which makes
the RFQ rather than the supplier the unit of scoring. A quotation below 75% of
the peer median ceases to earn additional points and raises a
`SUSPICIOUS_LOW_BID` flag: on medical equipment, an implausibly cheap quotation
is a risk signal rather than a bargain.

## 5.6 Compliance hard rules

Regulatory flags are returned alongside the compliance sub-score, not folded into
it, and route the decision independently:

| Condition | Severity | Outcome |
|---|---|---|
| FDA certification suspended | Blocking | Cannot be auto-approved |
| 510(k) clearance missing | Blocking | Cannot be auto-approved |
| ISO 13485 not certified | Blocking | Cannot be auto-approved |
| Regulatory consent decree | Blocking | Cannot be auto-approved |
| Predicted risk CRITICAL | Blocking | Cannot be auto-approved |
| Predicted risk HIGH | Review | Manager approval required |
| CE expired / under review, clearance pending, warning letter, incomplete documentation, warranty or SLA shortfall | Review | Manager approval required |

Each flag carries the clause that justifies it, so the routing decision is
itself citable.

## 5.7 Retrieval: two retrievers, routed

The Copilot uses two retrievers and routes each question to the appropriate one.

| Question | Retriever | Why |
|---|---|---|
| "What does the policy say about suspended certifications?" | Document | The answer *is written* in a clause |
| "How many suppliers have suspended FDA certification?" | Structured SQL | The answer must be *computed* from 50 records |
| "Which supplier should I select for RFQ-107?" | Both | Scores from SQL, the governing rule from a cited clause |

**Numbers never pass through an embedding.** Chunking supplier rows into text and
retrieving them by vector similarity is a well-known route to reporting the wrong
supplier's price with complete confidence. Prices, risk scores and certification
statuses are read with parameterised queries; only prose is retrieved
semantically. This also satisfies the specification's requirement that structured
supplier facts come from the database rather than from retrieved text.

**Document retrieval** uses BM25 and TF-IDF cosine over clause-level chunks,
fused by reciprocal rank fusion. Lexical scoring was chosen over neural
embeddings for three reasons specific to this corpus: the corpus is 17 short
structured documents (53 chunks), so approximate nearest-neighbour indexing
solves a scaling problem that does not exist; the decisive query terms are exact
surface forms such as "510(k)", "ISO 13485" and "consent decree", which lexical
matching handles exactly and general-purpose embedding models routinely conflate;
and results are identical on every machine and every run.

Dense retrieval is nonetheless available. Setting a Hugging Face API key enables
`all-MiniLM-L6-v2` embeddings, whose cosine ranking joins the same fusion at a
deliberately reduced weight of 0.5 against 1.0 per lexical ranking. Equal-weight
fusion was measured to be worse: a low-quality dense signal displaced the correct
clause from the top three on a known-clause probe. Chunk vectors are cached at
build time so that server startup makes no API call.

**Structured retrieval** (`query_engine.py`) supports lookup, categorical filter,
count, aggregation, ranking with direction awareness, comparison and portfolio
views, over a registry of 26 fields and 14 categorical filters. Column names come
from that registry only and every user-supplied value is bound as a parameter, so
the question cannot alter the shape of the query and there is no text-to-SQL
attack surface. Each result carries the SQL statement that produced it.

## 5.8 Recommendation engine

The recommender combines all four quantities with retrieved evidence. A blocked
supplier is never recommended, however well it scores. Output includes positive
reasons (each requiring both a better-than-median value and an absolute floor, so
that "best of a weak field" is not presented as a strength), concerns with the
clause behind each, and a **reweighting robustness check**: the RFQ is re-scored
under price-led, safety-led and equal weightings, and the panel reports whether
the same supplier wins under all four.

## 5.9 Human-in-the-loop and audit

The only path that produces an award requires an approver identity, a decision
and a reason. Approving a supplier that policy has blocked is permitted but
requires a written justification and is recorded as `POLICY OVERRIDE`. The system
does not prevent a human from overriding it; it makes the override deliberate and
permanent. Every recommendation, review and decision is appended to
`audit_events` with scores, risk, actor, reason and timestamp.

\newpage

# 6. Implementation

## 6.1 Statistics

| Measure | Value |
|---|---|
| Total lines (Python, JS, CSS, HTML) | ≈ 9,500 |
| Python modules | 18 |
| Database tables | 9 |
| REST endpoints | 23 |
| Dashboard screens | 10 |
| Automated checks | 139 |
| Cold build time | ≈ 40 s |

## 6.2 Repository structure

```
run.py                     single entry point: build if needed, then serve
backend/
  api_fastapi.py           FastAPI adapter (primary, /docs)
  serve_stdlib.py          standard-library adapter (zero-dependency fallback)
  app/
    config.py              paths, weights, bands, vocabularies, environment
    db.py                  SQLite schema (no supplier_contracts)
    ingest.py              CSV → SQLite
    features.py            ML features + deterministic sub-scores
    scoring.py             decision-score engine, price rules, eligibility
    query_engine.py        structured retrieval (safe parameterised SQL)
    recommender.py         combines score + risk + policy + evidence
    copilot.py             scope gate, routing, grounded answers
    audit.py               approvals + append-only audit trail
    routes.py              framework-agnostic handler table
    ml/                    numpy_models, backends, evaluate, explain,
                           confidence, train
    rag/                   parse, index, retrieve
frontend/                  index.html, styles.css, app.js (no build step)
data/                      4 CSVs + scoring_spec.json
rag_documents/             policy, master contract, RFQ-101…115
models/                    generated: database, model artefacts, RAG index
scripts/                   build_all.py, export_static.py, gen_api_docs.py
tests/                     test_all.py, test_huggingface.py,
                           render_check.js, css_check.js
docs/                      architecture, ML methodology, demo script,
                           limitations, API reference, this report
```

## 6.3 Dependencies and graceful degradation

The hard requirements are Python 3.10+, `numpy` and `pypdf`. Every other
dependency is optional and detected at import time.

| Absent dependency | Behaviour |
|---|---|
| FastAPI / uvicorn | Standard-library server, identical routes |
| scikit-learn / XGBoost | NumPy reference implementations, recorded in the report |
| `shap` | Permutation-sampled Shapley values |
| Hugging Face key | Deterministic grounded answers; lexical retrieval only |
| Network unavailable | Entire system unaffected |

No single failure takes the dashboard down; each screen degrades independently.

## 6.4 Determinism

All randomness is seeded (`RANDOM_SEED = 42`): fold assignment, bootstrap
sampling, boosting subsampling and permutation-Shapley draws. Re-running
`scripts/build_all.py` reproduces identical numbers; this was verified by
comparing decision-score hashes across rebuilds. The only non-deterministic
element is an optional LLM call, which cannot change any figure.

\newpage

# 7. Results and evaluation

> **All results below are prototype results on synthetic data (n = 50, 18
> positive labels).** They demonstrate the methodology. They are not estimates
> of real-world supplier risk and do not transfer to real suppliers.

Four evaluation tracks are maintained separately and never merged into a single
headline figure.

## 7.1 Predictive model comparison

5-fold stratified cross-validation × 10 repeats (50 fits per model):

| Metric | Logistic Regression (baseline) | **Random Forest (selected)** | XGBoost |
|---|---|---|---|
| ROC-AUC | 0.678 ± 0.031 | **0.730 ± 0.030** | 0.682 ± 0.050 |
| F1 | 0.500 ± 0.049 | **0.576 ± 0.022** | 0.551 ± 0.055 |
| Accuracy | 0.636 | **0.726** | 0.690 |
| Precision | 0.498 | **0.652** | 0.580 |
| Recall | 0.506 | 0.517 | **0.528** |
| Brier score (lower better) | 0.242 | **0.189** | 0.237 |

**Interpretation.** XGBoost was not privileged and did not win. It exhibits the
widest AUC dispersion (± 0.050) — the signature of over-fitting when 200 boosting
rounds meet approximately 40 training rows — and the second-worst calibration.
Random Forest's bagging averages that variance away, and its Brier score of 0.189
indicates the best-calibrated probabilities of the three, which matters because
those probabilities are displayed to a procurement officer as percentages.

An AUC of 0.730 is a real signal well above chance and simultaneously a modest
one. It is what an honest pipeline produces from 50 synthetic rows with leakage
controlled. An AUC approaching 1.0 here would be evidence of leakage rather than
of quality, and the test suite fails the build if any model exceeds 0.999.

## 7.2 Global feature importance

Mean absolute Shapley value, in percentage points of predicted risk:

| Rank | Feature | Mean effect |
|---|---|---|
| 1 | Lead-time variability (days) | 4.32 pp |
| 2 | On-time delivery % | 4.05 pp |
| 3 | Complaint rate per 1000 units | 2.70 pp |
| 4 | Demand-to-capacity ratio % | 2.27 pp |
| 5 | Capacity utilisation % | 2.09 pp |
| 6 | Historical performance score | 2.05 pp |
| 7 | Warranty claim rate % | 1.96 pp |
| 8 | Batch rejection rate % | 1.93 pp |

This ordering is the substantive sanity check on the pipeline: delivery
consistency dominates, quality signals follow, and capacity pressure appears
where it should. A model ranking credit rating first would have been grounds to
distrust the entire exercise.

## 7.3 Risk distribution

| Band | Definition | Suppliers |
|---|---|---|
| LOW | 0–25 | 25 |
| MEDIUM | >25–50 | 11 |
| HIGH | >50–75 | 6 |
| CRITICAL | >75 | 8 |

Bands are those defined in the buyer's procurement policy (POL-MED-001 §4), not
thresholds chosen by the author.

## 7.4 Retrieval evaluation

Known-clause probes, measured at *k* = 3. Each probe asserts that the clause a
procurement officer would cite appears in the top three results.

| Probe | Expected clause | Result |
|---|---|---|
| "What are the supplier risk thresholds?" | POL-MED-001 §4 Risk thresholds | Hit |
| "Does the lowest price guarantee the award?" | CON-MED-001 §7 Pricing | Hit |
| "Who holds final award authority?" | CON-MED-001 §11 Human decision authority | Hit |
| "What is the default warranty expectation?" | CON-MED-001 §5 Warranty | Hit |
| "When must a procurement manager approve?" | POL-MED-001 §7 Human approval | Hit |
| "What warranty does RFQ-102 require?" | RFQ-102 Requirement details | Hit |

**Probe accuracy: 6/6.** This is an honest prototype measure, not a formal
information-retrieval evaluation: there is no labelled relevance set and no
recall@k over a large query population.

## 7.5 Scoring behaviour

Across all 15 RFQs and 120 quotations:

| Observation | Value |
|---|---|
| RFQs where the cheapest quotation ranks first | 9 / 15 |
| Decision-score spread per RFQ (max − min) | median 49.1, range 17.0–79.4 |
| Quotations auto-approvable | 6 |
| Quotations requiring review | 74 |
| Quotations blocked by policy | 40 |
| Recommendations robust across all four weightings | 8 / 15 |

Two results deserve comment rather than presentation as successes.

**The cheapest quotation wins 9 of 15 RFQs.** Price carries the single largest
weight (25%), so it frequently *should* win; the requirement is that it cannot
win *automatically*, and in 6 of 15 RFQs it does not. An automated test asserts
that the cheapest quotation does not rank first in every RFQ, which would
indicate the weighting had collapsed to price alone.

**Recommendations are robust to reweighting in 8 of 15 RFQs.** In the remaining
seven, the recommended supplier changes under price-led or safety-led weightings.
This is reported to the user in the recommendation panel rather than concealed,
because a recommendation that survives reweighting is a materially stronger claim
than one that does not, and the buyer is entitled to know which they are looking
at.

**Only 6 of 120 quotations are auto-approvable.** This reflects a deliberately
strict reading of the buyer's policy for a safety-critical category, and is
consistent with real medical-device procurement, in which most awards receive
human scrutiny.

## 7.6 Copilot evaluation

| Measure | Result |
|---|---|
| RFQ coverage: five question types × 15 RFQs | 75 / 75 correct RFQ binding |
| Supplier profile coverage | 50 / 50 suppliers |
| Scope gate accuracy (34 in-scope, 15 out-of-scope probes) | 49 / 49 |
| Portfolio questions not contaminated by the selected RFQ | 12 / 12 |

The scope gate declines questions it cannot ground — general knowledge, current
affairs, arithmetic, creative writing — and an out-of-scope question is never
forwarded to a language model. The refusal is therefore a property of the system
rather than of the model's compliance with a prompt.

## 7.7 Worked example: RFQ-102

Infusion Pump, 350 units, budget ₹1,85,000 per unit, 40-day delivery
requirement, 24-month warranty, 24-hour service SLA, 8 quotations.

| # | Supplier | Unit price | Days | Quality | Risk | Conf. | Score | Status |
|---|---|---|---|---|---|---|---|---|
| 1 | MediCore Medical Systems 19 | ₹1,69,299 | 45 | 53.5 | LOW (23) | 83% | **73.5** | Review required |
| 2 | Cura Medical Systems 11 | ₹1,78,167 | 44 | 61.4 | LOW (16) | 87% | 70.9 | **Blocked** |
| 3 | Sterling Biomedical 25 | ₹1,82,003 | 46 | 54.2 | MEDIUM (29) | 78% | 58.0 | Review required |
| 4 | Ardent Biomedical 38 | ₹1,70,563 | 35 | 33.6 | HIGH (68) | 79% | 56.9 | Review required |

Two rows carry the argument of the entire system.

**Cura at rank 2** offers a competitive price, *better* quality than the leader,
and LOW predicted risk with the highest confidence in the field — and is blocked,
because it is operating under a regulatory consent decree. Compliance is not
averaged away by commercial merit; it routes the decision on its own.

**Ardent at rank 4** offers the fastest delivery in the field (35 days against a
40-day requirement) and is cheaper than the leader, yet ranks fourth, because the
model places it at HIGH disruption risk with a quality score of 33.6.

The recommended supplier's score of 73.5 decomposes as price 25.0 + compliance
13.7 + historical 11.9 + delivery 11.8 + quality 8.0 + resilience 3.1. Its
leading risk drivers are lead-time variability (−5.1 pp), on-time delivery
(−3.9 pp) and warranty claim rate (−2.5 pp), all reducing risk. Its confidence of
83% decomposes as data completeness 100, probability certainty 55, model
agreement 85, history consistency 87, RFQ completeness 100.

It nonetheless carries one exception — its most recent inspection produced a
warning letter — and is therefore returned as `RECOMMENDED_WITH_REVIEW` rather
than presented as clean, with the policy clause that requires the review cited
alongside.

## 7.8 Verification

| Suite | Checks | Covers |
|---|---|---|
| `tests/test_all.py` | 102 | Ingestion, features, leakage, compliance rules, scoring, risk, confidence, ML metrics, retrieval, recommendation, Copilot, scope, API, approvals, audit, end-to-end journey |
| `tests/test_huggingface.py` | 21 | Provider resolution, chat completions, embeddings, batching, caching, fusion weighting, graceful degradation — against a local mock of the Hugging Face router |
| `tests/render_check.js` | 11 | All ten dashboard views rendered headlessly against captured API data |
| `tests/css_check.js` | 5 | Stylesheet regressions in the cascade |
| **Total** | **139** | All passing |

The end-to-end test exercises the complete journey: RFQ, quotations, ML risk,
scoring, retrieval, recommendation, pending approval, human decision, audit
trail, and confirmation that the item is no longer pending.

\newpage

# 8. Discussion

## 8.1 Why four quantities rather than one

A single blended score is more convenient to display and strictly less useful.
The RFQ-102 result in Section 7.7 could not be represented by one number: Cura is
simultaneously commercially attractive, statistically low-risk, confidently so,
and legally unawardable. Any weighting that reduces those four facts to a scalar
either conceals the blocking condition or over-penalises the commercial offer.
Keeping them separate costs display space and buys correctness.

## 8.2 Why the specified technologies were sometimes not used

The specification permitted better-justified alternatives. Three were taken.

**SQLite rather than PostgreSQL.** The schema, SQL and access layer are identical
for this workload; the difference is a server process the demonstration would
depend on.

**Hybrid lexical retrieval rather than Chroma/FAISS with embeddings.** Justified
in Section 5.7. The interface for dense retrieval exists and is exercised by
tests; the default is lexical because it is more accurate on this corpus, not
because it is simpler.

**A fixed structured-query operation set rather than LLM text-to-SQL.** Broader
phrasing coverage is not worth the possibility of a confidently wrong number in a
compliance setting.

In each case the alternative is implemented and available, and the reasoning is
documented rather than asserted.

## 8.3 On reporting an unfavourable result

XGBoost is the model an examiner would expect to win, and it lost. The selection
rule was fixed before results were observed, is recorded in the evaluation
artefact, and is re-derived from that artefact by an automated test. Reporting
the loss is more valuable than tuning until the expected model won, because the
explanation — bagging beats boosting at n = 50 — is itself a defensible finding.

\newpage

# 9. Limitations

## 9.1 Data

1. **All data is synthetic.** No figure in this report describes a real supplier.
2. **The correlations were designed in.** The generator encoded the relationships
   the model recovers. Recovery demonstrates a working pipeline, not a true
   relationship.
3. **n = 50 with 18 positives.** Confidence intervals on every metric are wide.
4. **No time dimension**, therefore no forward-chaining temporal validation. Real
   supplier risk drifts.
5. **A single binary label**, not a disruption rate. A production system would
   model time-to-event or frequency.

## 9.2 Model

6. **AUC 0.730 is modest.** Real, above chance, and limited by the data.
7. **No hyper-parameter search.** Defaults held fixed across candidates for a
   fair comparison; tuning on 50 rows would over-fit the validation folds.
8. **No calibration curve.** Brier is reported; a reliability diagram on 50
   points would not be meaningful.
9. **Displayed risk is out-of-fold**, so it is not the figure the deployed
   all-data model would produce for a genuinely new supplier.
10. **Shapley values are sampled estimates.** Small attributions should not be
    over-interpreted.

## 9.3 Scoring

11. **Weights are policy, not a derived optimum.** Defensible because they are
    the buyer's stated priorities, not because they are optimal.
12. **Normalisation anchors are judgement calls**, chosen from the observed data
    range — explicit and auditable, but still choices.
13. **Total evaluated cost is unit price × quantity.** No landed cost, duties,
    lifecycle service cost or financing.
14. **No multi-award or split-award logic.**

## 9.4 Retrieval and Copilot

15. **A small, clean corpus.** Retrieval quality here does not predict
    performance on a large heterogeneous corpus.
16. **Lexical retrieval can miss** a question phrased entirely in vocabulary the
    documents never use; a small synonym table mitigates this.
17. **Evaluation is by known-clause probes**, not a labelled relevance set.
18. **Structured retrieval is a fixed operation set**, not general text-to-SQL.
    Questions outside it fall back to the per-RFQ answer.
19. **Intent routing and scope are rule-based**, not trained classifiers.
20. **The Copilot is not multi-turn.** UI context is passed; conversation memory
    is not.
21. **The embedding model is not domain-tuned**, which is why the dense ranking
    is down-weighted rather than trusted equally.

## 9.5 System

22. **No authentication or roles.** The approver is a typed name.
23. **The audit trail is append-only by convention**, not cryptographically —
    no hash chain or tamper evidence.
24. **No concurrency control** on approvals.
25. **SQLite single file**, appropriate at this scale.

\newpage

# 10. Conclusion and future work

## 10.1 Conclusion

The project delivers a working end-to-end decision-support system for medical
equipment procurement: data ingestion, a cross-validated and explainable risk
model, a configurable deterministic scoring engine with regulatory hard rules, a
hybrid retrieval layer restricted to the buyer's own documents, a grounded
Copilot, human-in-the-loop approval and a complete audit trail, presented through
a ten-screen enterprise dashboard.

The objectives in Section 1.3 are met. The system holds four decision-relevant
quantities apart rather than blending them, enforces compliance independently of
commercial merit, grounds every claim in a record or a citable clause, refuses
questions it cannot ground, and preserves human authority over every award.

The contribution is methodological rather than algorithmic. It lies in the
separation of concerns, the honesty of the evaluation — including a
pre-registered selection rule that produced an unexpected winner, explicit
leakage control, and out-of-fold reporting — and in an architecture where no
single external dependency can prevent the system from running.

## 10.2 Future work

**Near term.** A labelled relevance set for formal retrieval evaluation
(recall@k, MRR); a cross-encoder reranking stage; multi-turn conversation memory;
an empirical lexical-versus-hybrid retrieval comparison using the
`USE_DENSE_RETRIEVAL` switch already provided.

**Medium term.** Temporal validation on time-stamped supplier histories; modelling
a disruption *rate* rather than a single binary event; probability calibration
with a reliability diagram once sample size permits; multi-award and split-award
optimisation; total-cost-of-ownership rather than unit price × quantity.

**Longer term.** Authentication with role-based access and segregation of duties;
a cryptographically verifiable audit chain; migration to PostgreSQL with
concurrency control; domain-adapted embeddings fine-tuned on regulatory and
contractual text; and validation against a real buyer's historical award
decisions, which is the only way any of the figures in this report could become
meaningful.

\newpage

# References

Breiman, L. (2001). Random Forests. *Machine Learning*, 45(1), 5–32.

Chen, T. and Guestrin, C. (2016). XGBoost: A Scalable Tree Boosting System.
*Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge
Discovery and Data Mining*, 785–794.

Cormack, G. V., Clarke, C. L. A. and Buettcher, S. (2009). Reciprocal Rank Fusion
Outperforms Condorcet and Individual Rank Learning Methods. *Proceedings of the
32nd International ACM SIGIR Conference*, 758–759.

Lewis, P., Perez, E., Piktus, A., et al. (2020). Retrieval-Augmented Generation
for Knowledge-Intensive NLP Tasks. *Advances in Neural Information Processing
Systems*, 33, 9459–9474.

Lundberg, S. M. and Lee, S.-I. (2017). A Unified Approach to Interpreting Model
Predictions. *Advances in Neural Information Processing Systems*, 30, 4765–4774.

Robertson, S. and Zaragoza, H. (2009). The Probabilistic Relevance Framework:
BM25 and Beyond. *Foundations and Trends in Information Retrieval*, 3(4),
333–389.

Štrumbelj, E. and Kononenko, I. (2014). Explaining Prediction Models and
Individual Predictions with Feature Contributions. *Knowledge and Information
Systems*, 41(3), 647–665.

\newpage

# Appendix A — Database schema

Nine tables. No `supplier_contracts` table exists, by design.

| Table | Purpose |
|---|---|
| `buyers` | Buyer master data |
| `suppliers` | Supplier master data, 44 attributes |
| `rfqs` | RFQ header and requirements |
| `rfq_quotes` | Quotations, unique per (RFQ, supplier) |
| `supplier_risk_predictions` | Probability, score, band, confidence, drivers |
| `supplier_scores` | Per-RFQ sub-scores, decision score, flags, eligibility |
| `recommendations` | Generated recommendations with reasons and evidence |
| `approvals` | Human decisions with approver, reason, timestamp |
| `audit_events` | Append-only event log |

# Appendix B — API endpoints

```
GET  /api/health                              GET  /api/rfqs
GET  /api/dashboard/summary                   GET  /api/rfqs/{id}
GET  /api/buyer                               GET  /api/rfqs/{id}/suppliers
GET  /api/rfqs/{id}/suppliers/{sid}           POST /api/rfqs/{id}/recommendation
GET  /api/suppliers                           GET  /api/suppliers/{id}
GET  /api/suppliers/{id}/risk                 GET  /api/risk
GET  /api/model                               GET  /api/model/evaluation
GET  /api/knowledge-base                      GET  /api/documents/search
POST /api/copilot/query                       POST /api/approvals
GET  /api/approvals                           POST /api/reviews
GET  /api/audit                               GET  /api/analytics
GET  /api/settings
```

Full request and response shapes are in `docs/API.md`, generated from the live
route table so it cannot drift from the implementation.

# Appendix C — Reproduction

```bash
pip install numpy pypdf        # the only hard requirements
python scripts/build_all.py    # ~40 s; ingests, indexes, trains, scores
python run.py                  # serves at http://127.0.0.1:8000

python tests/test_all.py         # 102 checks
python tests/test_huggingface.py # 21 checks
node tests/render_check.js       # 11 checks
node tests/css_check.js          # 5 checks
```

All results in this report were read from the generated artefacts
(`models/model_evaluation.json` and the live database), not transcribed by hand.
The build is seeded and reproduces identical figures on every run.
