# Demo Script

Two hardened golden paths: **RFQ-102** (Infusion Pump) and **RFQ-101** (Patient
Monitor). Everything is seeded, so these numbers reproduce exactly.

**Before you start**

```bash
python scripts/build_all.py    # ~25 s, confirms "health: ok"
python run.py                  # http://127.0.0.1:8000
```

Have `dist/procurement-copilot-offline.html` on the desktop as a backup — it is
a single file that opens with a double-click and needs no Python.

---

## The 8-minute walkthrough

### 1 · Frame it (30 s)

> "This helps a hospital procurement team make explainable, evidence-backed
> supplier decisions. It does not select suppliers. Every award is decided by a
> human, and every step is audited."

Say this first. It is the thesis, and the rest of the demo is evidence for it.

### 2 · Overview (45 s)

15 active RFQs · 50 suppliers · 14 high-risk · pending approvals. Risk
distribution: **LOW 25, MEDIUM 11, HIGH 6, CRITICAL 8**.

> "These bands come from the buyer's own procurement policy, section 4 — not from
> a threshold I chose."

### 3 · RFQ-102 supplier comparison (90 s)

| # | Supplier | Unit price | Delivery | Quality | Risk | Score | Status |
|---|---|---|---|---|---|---|---|
| 1 | MediCore Medical Systems 19 | ₹1,69,299 | 45 d | 53.5 | LOW | **73.5** | Review required |
| 2 | Cura Medical Systems 11 | ₹1,78,167 | 44 d | 61.4 | LOW | 70.9 | **Blocked** |
| 3 | Sterling Biomedical 25 | ₹1,82,003 | 46 d | 54.2 | MEDIUM | 58.0 | Review required |
| 4 | Ardent Biomedical 38 | ₹1,70,563 | 35 d | 33.6 | HIGH | 56.9 | Review required |

**This table is the whole argument. Make two points:**

> "Supplier 2 has a competitive price, better quality than the leader, and LOW
> predicted risk — and it is blocked. It is under a regulatory consent decree.
> Compliance is not a number that gets averaged away by a good price; it routes
> the decision on its own."

> "And note Ardent at #4 — the fastest delivery in the field at 35 days, cheaper
> than the leader, and it still ranks fourth, because the model puts it at HIGH
> disruption risk and its quality score is 33."

### 4 · Get Recommendation (60 s)

**MediCore Medical Systems 19 — 73.5/100, LOW risk (22.6/100, 23% probability),
83% confidence, RECOMMENDED WITH REVIEW.**

Reasons, then the concern:

> "It carries one exception — the most recent inspection produced a warning
> letter — so the system will not present it as clean. It is recommended
> *subject to human review*, and it cites the policy clause that says so."

Point at the "robust to reweighting" line:

> "The recommendation was re-run under price-led, safety-led and equal
> weightings. The same supplier wins all four. That is a much stronger claim
> than winning under one weighting I chose."

### 5 · Drill into a row (90 s)

Click MediCore. Walk the drawer top to bottom:

- **Score composition** — the six weighted contributions, summing to 73.5.
- **Risk drivers** — Shapley attributions in percentage points; red increases
  risk, green reduces it.
- **Confidence breakdown** — five components.

> "Confidence is 83% while risk is 23. Those are not two views of one number.
> Confidence measures how strong and consistent the evidence is — you can be
> confidently high-risk, or unconfidently low-risk. The system never computes
> confidence as 100 minus risk, and there is a test that fails if anyone ever
> makes it do that."

### 6 · Ask the Copilot (90 s)

Three questions, in this order:

1. **"Why is the recommended supplier recommended for RFQ-102?"**
   → score composition, risk, confidence, routing, plus cited clauses.
2. **"Why is supplier C high risk?"**
   → *Watch for the correction.* Supplier C is MEDIUM, not HIGH, and the Copilot
   says so before answering. Worth calling out: "it corrects the premise rather
   than agreeing with me."
3. **"What does the buyer policy say about suspended certifications?"**
   → policy clauses with document, section and page.

> "Supplier facts come from the database. Contractual claims come from retrieval,
> always with a citation. The Copilot cannot assert a requirement without
> pointing at the clause."

**If an examiner tries to break it** — and they will — ask it yourself first:
**"Who is the PM of India?"**

> "It declines. This is a grounded procurement assistant: every answer has to
> trace to a database record or a cited clause, so a question it cannot ground
> is refused rather than answered from a language model's general knowledge.
> And the refusal isn't the model being well-behaved — an out-of-scope question
> is never sent to the model at all. The guard sits in front of it."

That is a stronger moment than any answer it gives, because it demonstrates the
one property that separates this from a chatbot bolted onto a database.

If asked about the LLM:

> "It runs deterministically here. With an API key configured, the same verified
> facts and citations are handed to an LLM which may rephrase them — it cannot
> introduce a fact. If the call fails, it falls back to this. The demo cannot
> break on a network problem."

### 7 · Contract intelligence (45 s)

Show the clause card and the knowledge-base table: 17 documents, 53 clauses,
policy + master contract + RFQ-101…115.

> "Supplier contracts are deliberately absent. There is no supplier-contracts
> table and the document discovery function refuses any other document type.
> That is a scope requirement enforced in three places, not a comment."

### 8 · Approve and audit (60 s)

Approve as yourself, with a reason. Then open **Audit Trail**:
`RECOMMENDATION_GENERATED` followed by `HUMAN_DECISION`, with scores, risk,
actor, reason and timestamp.

**Optional, and the strongest moment if you have time:** go back and try to
approve the blocked Cura Medical Systems 11 with no reason. It is refused. Add a
justification and it goes through — recorded as `POLICY OVERRIDE` in the audit
trail.

> "The system does not prevent a human from overriding it. It makes the override
> deliberate, and permanent in the record."

### 9 · Reports (30 s)

The model comparison table.

> "Logistic regression was the baseline. Random Forest won on cross-validated
> ROC-AUC. XGBoost lost — and I left it losing, because the selection rule was
> fixed before I saw the results. AUC 0.73 on 50 synthetic suppliers is a modest,
> honest number. If it said 0.99, that would be evidence of leakage."

---

## If they ask for a different RFQ

They can pick any of RFQ-101 to RFQ-115 from the dropdown and every screen
recomputes - comparison, recommendation, drill-down, Copilot. This is tested:
`test_every_rfq_answers_the_core_questions` runs five question types against all
fifteen RFQs, and `test_every_supplier_has_a_profile_answer` covers all fifty
suppliers.

Portfolio-wide questions work with no RFQ selected at all:

| Ask | Get |
|---|---|
| "How many suppliers have suspended FDA certification?" | 5, listed with risk levels |
| "Which suppliers are under a consent decree?" | 3, named |
| "Which supplier is riskiest?" | Sterling Healthcare Devices 45, 94/100 |
| "Which supplier has the best on-time delivery?" | MedAxis Medical Systems 03, 96.17% |
| "What is the total budget across all RFQs?" | INR 74.61 Cr across 15 RFQs |
| "Which RFQ has the most blocked suppliers?" | RFQ-101, 4 of 8 |
| "Compare MED-024 and MED-030" | side by side, with who is better on what |

> "Those numbers are computed from the database by a parameterised query, not
> retrieved from a document. The system will show you the SQL that produced
> them. Prices and risk scores never pass through an embedding, because that is
> how a RAG system ends up quoting the wrong supplier's price confidently."

## Backup path: RFQ-101

Pick RFQ-101 from the dropdown if you need a second example.

**Solaris MedTech — 92.7/100, LOW risk (19.2), 84% confidence.** A high scorer
with a *contractual* exception rather than a regulatory one: quoted warranty is
24 months against an RFQ requirement of 36. Useful for showing that the flag
engine reads the RFQ and master contract, not just certification status. Zenith
at #3 is blocked on suspended FDA certification.

---

## Questions you should expect

**"Why is the AUC only 0.73?"**
50 suppliers, 18 positive labels, no leakage. That is what honest looks like at
this sample size. The report shows ± 0.03 across 50 fits, so it is a stable 0.73,
not a lucky one.

**"Why not XGBoost?"**
It was evaluated and it lost — widest variance of the three, worse calibration.
The selection rule is in the artefact and a test re-derives the choice.

**"Isn't confidence just the inverse of risk?"**
No, and there is a test asserting it isn't. Five evidence-strength components,
listed in the drawer.

**"How do I know the Copilot isn't making things up?"**
Supplier facts are read from SQLite. Contract and policy claims come from
retrieval and carry document, section and page. With no LLM configured the answer
is assembled directly from those two sources. And anything it cannot ground in
those sources is refused — try "who is the PM of India".

**"So it can't answer general questions at all?"**
Correct, by design. Answering them would mean producing output with no
traceable source, which is the exact failure mode this architecture exists to
prevent. In a compliance setting a confident wrong answer is worse than a
refusal.

**"What if the model is wrong?"**
It never awards. High and critical risk, and every regulatory exception, route to
a human. Overrides are allowed but recorded.

**"Could this run on real data?"**
The pipeline could. The numbers could not — they are synthetic. Real deployment
would need temporal validation, a disruption rate rather than a single binary
label, and recalibration against the buyer's own history.
