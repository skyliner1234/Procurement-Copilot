/* Procurement Copilot - dashboard front end.
   Vanilla ES modules-free JS: no build step, no CDN, works from the FastAPI or
   the stdlib server. Every figure on screen comes from the API. */
'use strict';

/* ====================================================================== utils */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const state = {
  rfqId: 'RFQ-102',
  supplierId: null,
  chat: [],
  docPage: 1,
  cache: {},
};

async function api(path, opts) {
  const res = await fetch(path, Object.assign({
    headers: { 'content-type': 'application/json' },
  }, opts));
  let data;
  try { data = await res.json(); } catch { data = { error: 'Malformed response' }; }
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

const esc = s => String(s ?? '').replace(/[&<>"']/g,
  c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const num = (v, d = 0) => (v === null || v === undefined || isNaN(v))
  ? '--' : Number(v).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });

function inrShort(v) {
  if (v === null || v === undefined || isNaN(v)) return '--';
  const n = Number(v);
  if (n >= 1e7) return '₹' + (n / 1e7).toFixed(2) + ' Cr';
  if (n >= 1e5) return '₹' + (n / 1e5).toFixed(2) + ' L';
  return '₹' + num(n);
}
const pct = v => (v === null || v === undefined || isNaN(v)) ? '--' : Math.round(Number(v)) + '%';
const dt = s => { if (!s) return '--'; const d = new Date(s); return isNaN(d) ? String(s).slice(0, 16) : d.toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }); };
const scoreClass = v => v >= 75 ? 'score-good' : v >= 60 ? 'score-mid' : 'score-bad';
const riskClass = l => (l || 'unknown').toLowerCase();

function toast(msg, isErr) {
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' err' : '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 4600);
}

/* ====================================================================== icons */
const ICONS = {
  home:  'M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z',
  doc:   'M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8zM14 3v5h5M9 13h6M9 17h4',
  users: 'M16 20v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 6a3 3 0 100 6 3 3 0 000-6M22 20v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8',
  shield:'M12 3l8 3v6c0 4.5-3.2 7.9-8 9-4.8-1.1-8-4.5-8-9V6zM9.2 12.2l2 2 3.6-3.9',
  file:  'M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8zM14 3v5h5',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  report:'M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8zM14 3v5h5M8.5 16l2.5-3 2 2 2.5-3.5',
  check: 'M9 12.5l2.2 2.2L15.5 10M12 21a9 9 0 110-18 9 9 0 010 18z',
  list:  'M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01',
  gear:  'M12 15.2a3.2 3.2 0 100-6.4 3.2 3.2 0 000 6.4M19.4 15a1.6 1.6 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.6 1.6 0 00-2.7 1.1v.3a2 2 0 11-4 0v-.2a1.6 1.6 0 00-2.8-1.1l-.1.1a2 2 0 11-2.8-2.8l.1-.1A1.6 1.6 0 003.7 15H3.4a2 2 0 110-4h.2a1.6 1.6 0 001.1-2.8l-.1-.1a2 2 0 112.8-2.8l.1.1A1.6 1.6 0 009.9 4.4V4a2 2 0 114 0v.2a1.6 1.6 0 002.7 1.1l.1-.1a2 2 0 112.8 2.8l-.1.1a1.6 1.6 0 001.1 2.7h.3a2 2 0 110 4h-.2a1.6 1.6 0 00-1.2.9z',
  spark: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9zM19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z',
  chat:  'M21 11.5a8.4 8.4 0 01-9 8.4 8.5 8.5 0 01-3.9-.9L3 21l1.9-5a8.4 8.4 0 01-.9-3.9 8.5 8.5 0 018.5-8.5h.5a8.5 8.5 0 018 8z',
  alert: 'M10.3 3.9L1.8 18a2 2 0 001.7 3h17a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0zM12 9v4M12 17h.01',
  bot:   'M12 7V4M9 2h6M5 7h14a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9a2 2 0 012-2M9 13h.01M15 13h.01M9.5 17h5',
  star:  'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z',
  eye:   'M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7M12 15a3 3 0 100-6 3 3 0 000 6',
  thumb: 'M7 22V11l4.5-9a2.5 2.5 0 013.6 3l-1.4 5H20a2 2 0 012 2.4l-1.6 7A2 2 0 0118.4 22z',
  cross: 'M18 6L6 18M6 6l12 12',
  search:'M11 19a8 8 0 100-16 8 8 0 000 16M21 21l-4.3-4.3',
  clock: 'M12 21a9 9 0 100-18 9 9 0 000 18M12 7v5l3 2',
};
function svg(name, size = 18, stroke = 1.7) {
  const d = ICONS[name] || '';
  return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor"
    stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round"><path d="${d}"/></svg>`;
}
function cardIcon(name, color, bg) {
  return `<span class="card-icon" style="background:${bg};color:${color}">${svg(name, 15, 1.9)}</span>`;
}

/* ====================================================================== chrome */
function paintNavIcons() {
  $$('.ico[data-ico]').forEach(el => { el.innerHTML = svg(el.dataset.ico, 17); });
}
function setActiveNav(view) {
  $$('.nav-item').forEach(a => a.classList.toggle('active', a.dataset.view === view));
}
function openDrawer(title, html) {
  $('#drawer-title').textContent = title;
  $('#drawer-body').innerHTML = html;
  $('#drawer').hidden = false;
  $('#scrim').hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeDrawer() {
  const drawer = $('#drawer');
  const scrim = $('#scrim');
  if (drawer) { drawer.hidden = true; drawer.scrollTop = 0; }
  if (scrim) scrim.hidden = true;
  document.body.style.overflow = '';
  const body = $('#drawer-body');
  if (body) body.innerHTML = '';       // drop stale handlers and content
}

/* ====================================================================== charts */
function donut(segments, total, caption) {
  const R = 68, C = 2 * Math.PI * R;
  let offset = 0;
  const arcs = segments.filter(s => s.value > 0).map(s => {
    const frac = total ? s.value / total : 0;
    const seg = `<circle cx="85" cy="85" r="${R}" fill="none" stroke="${s.color}" stroke-width="17"
      stroke-dasharray="${(frac * C).toFixed(2)} ${(C - frac * C).toFixed(2)}"
      stroke-dashoffset="${(-offset * C).toFixed(2)}" transform="rotate(-90 85 85)" stroke-linecap="butt"/>`;
    offset += frac;
    return seg;
  }).join('');
  return `<div class="donut">
    <svg viewBox="0 0 170 170" width="170" height="170">
      <circle cx="85" cy="85" r="${R}" fill="none" stroke="#eef2f0" stroke-width="17"/>${arcs}
    </svg>
    <div class="donut-center"><div><b>${total}</b><span>${caption}</span></div></div></div>`;
}

function gauge(value, label) {
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  const R = 62, cx = 75, cy = 76;
  const len = Math.PI * R;
  const col = v >= 75 ? '#1a7a4f' : v >= 60 ? '#f0ab2e' : '#e0524a';
  return `<div class="gauge">
    <svg viewBox="0 0 150 90" width="150" height="90">
      <path d="M ${cx - R} ${cy} A ${R} ${R} 0 0 1 ${cx + R} ${cy}" fill="none" stroke="#eef2f0" stroke-width="13" stroke-linecap="round"/>
      <path d="M ${cx - R} ${cy} A ${R} ${R} 0 0 1 ${cx + R} ${cy}" fill="none" stroke="${col}" stroke-width="13"
        stroke-linecap="round" stroke-dasharray="${(v / 100 * len).toFixed(1)} ${len.toFixed(1)}"/>
    </svg>
    <div class="gauge-num" style="color:${col}">${Math.round(v)}</div>
    <div class="gauge-cap">${label}</div></div>`;
}

function barList(items, opts = {}) {
  const max = Math.max(...items.map(i => Math.abs(i.value)), opts.max || 1);
  return `<div class="bar-list">${items.map(i => `
    <div class="bar-item">
      <div class="k" title="${esc(i.label)}">${esc(i.label)}</div>
      <div class="bar-track"><div class="bar-fill ${i.value < 0 ? 'neg' : ''}"
        style="width:${(Math.abs(i.value) / max * 100).toFixed(1)}%;${i.color ? 'background:' + i.color : ''}"></div></div>
      <div class="v">${i.display ?? num(i.value, 1)}</div>
    </div>`).join('')}</div>`;
}

function divergingBars(items) {
  const max = Math.max(...items.map(i => Math.abs(i.value)), 0.1);
  return `<div class="bar-list">${items.map(i => {
    const w = Math.abs(i.value) / max * 50;
    const pos = i.value >= 0;
    return `<div class="bar-item">
      <div class="k" title="${esc(i.label)}">${esc(i.label)}</div>
      <div class="diverge"><div class="mid"></div>
        <div class="seg" style="background:${pos ? '#e0524a' : '#1a7a4f'};
          ${pos ? `left:50%;width:${w}%` : `right:50%;width:${w}%`}"></div></div>
      <div class="v" style="color:${pos ? '#c8382f' : '#1a7a4f'}">${i.display}</div>
    </div>`;
  }).join('')}</div>`;
}

/* ====================================================================== bits */
const AV_COLORS = [
  ['#e4f2e9', '#12613f'], ['#fdf3e0', '#a1650a'], ['#fdeceb', '#b5342c'],
  ['#e7f0fd', '#25599f'], ['#f0eafc', '#5b34a8'], ['#e6f4f4', '#116363'],
  ['#fbeaf3', '#a32a6c'], ['#f2f4e8', '#5a6b1f'],
];
function supplierAvatar(index, letterOverride) {
  const [bg, fg] = AV_COLORS[index % AV_COLORS.length];
  const letter = letterOverride || String.fromCharCode(65 + (index % 26));
  return `<span class="sup-avatar" style="background:${bg};color:${fg}">${letter}</span>`;
}
function riskPill(level) {
  return `<span class="pill ${riskClass(level)}">${esc(level || 'UNKNOWN')}</span>`;
}
function eligibilityMark(elig) {
  if (elig === 'AUTO_APPROVABLE')
    return `<span class="rec-mark" style="color:#1a7a4f" title="No outstanding exceptions">${svg('check', 21, 2)}</span>`;
  if (elig === 'REVIEW_REQUIRED')
    return `<span class="rec-mark" style="color:#93a49a" title="Human review required">
      <svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="12" cy="12" r="9"/><path d="M8 12h8" stroke-linecap="round"/></svg></span>`;
  return `<span class="rec-mark" style="color:#c8382f" title="Blocked by buyer policy">${svg('alert', 21, 2)}</span>`;
}
function citeBlock(c) {
  return `<div class="cite"><b>${esc(c.citation)}</b>"${esc(c.evidence)}"</div>`;
}
function evidenceList(items) {
  if (!items || !items.length) return `<div class="empty">No supporting documents retrieved.</div>`;
  return `<div class="evidence">${items.map(e => `
    <div class="ev-item">
      <div class="src">${svg('file', 12, 2)} ${esc(e.citation)}</div>
      <div class="quote">"${esc(e.evidence)}"</div>
      ${e.why ? `<div class="why">${esc(e.why)}</div>` : ''}
    </div>`).join('')}</div>`;
}

/* ====================================================================== views */
const views = {};

/* ---------------------------------------------------------------- OVERVIEW */
views.overview = async () => {
  const s = await api('/api/dashboard/summary');
  state.cache.summary = s;
  $('#alert-count').textContent = s.counts.pending_approval + s.counts.high_risk_suppliers;

  const d = s.risk_distribution;
  const totalRated = d.LOW + d.MEDIUM + d.HIGH + d.CRITICAL;

  const kpi = (icon, color, bg, label, value, note) => `
    <div class="kpi">
      <span class="kpi-ico" style="background:${bg};color:${color}">${svg(icon, 22, 1.9)}</span>
      <div>
        <div class="kpi-label">${label}</div>
        <div class="kpi-value">${value}</div>
        <div class="kpi-delta">${note}</div>
      </div>
    </div>`;

  const html = `
  <section class="card">
    <div class="card-head">${cardIcon('chart', '#12613f', '#e4f2e9')}<h2>Procurement Overview</h2>
      <span class="sub">${esc(s.buyer.buyer_name)} · ${esc(s.buyer.buyer_id)}</span></div>
    <div class="kpis">
      ${kpi('doc', '#2f6fd0', '#e7f0fd', 'Active RFQs', s.counts.active_rfqs, `${s.counts.total_rfqs} total issued`)}
      ${kpi('users', '#1a7a4f', '#e4f2e9', 'Suppliers', s.counts.suppliers, `${s.counts.quotations} quotations on file`)}
      ${kpi('shield', '#c8382f', '#fdeceb', 'High-Risk Suppliers', s.counts.high_risk_suppliers, `${d.CRITICAL} critical · ${d.HIGH} high`)}
      ${kpi('check', '#7a4fd0', '#f0eafc', 'Pending Approval', s.counts.pending_approval, 'awaiting human decision')}
    </div>
  </section>

  <div class="grid-2 left-narrow">
    <section class="card">
      <div class="card-head">${cardIcon('chat', '#12613f', '#e4f2e9')}<h2>Ask Procurement Copilot</h2></div>
      <div class="chat">
        <div class="chat-log" id="chat-log"></div>
        <div class="chat-input">
          <input id="chat-q" placeholder="Ask Copilot…" autocomplete="off">
          <button class="send" id="chat-send" aria-label="Send">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M3 20.5l19-8.5L3 3.5 3 10l13 2-13 2z"/></svg>
          </button>
        </div>
        <div class="chips" id="chat-chips">
          <span class="chips-label">Try asking:</span>
          ${(s.copilot_suggestions || []).slice(0, 3).map(q =>
            `<button class="chip">${esc(q)}</button>`).join('')}
        </div>
      </div>
    </section>

    <section class="card">
      <div class="card-head">${cardIcon('alert', '#d98708', '#fdf3e0')}<h2>Supplier Risk Overview</h2>
        <span class="sub">${esc(s.model.selected_model || 'model pending')}</span></div>
      <div class="section-title">Risk distribution</div>
      <div class="risk-split">
        <div class="risk-bars">
          ${[['LOW', '#1a7a4f'], ['MEDIUM', '#f0ab2e'], ['HIGH', '#e0524a'], ['CRITICAL', '#7f1d1d']].map(([k, c]) => `
            <div class="risk-row">
              <span class="lbl">${k}</span>
              <div class="risk-track"><div class="risk-fill" style="width:${totalRated ? (d[k] / totalRated * 100).toFixed(1) : 0}%;background:${c}"></div></div>
              <span class="num">${d[k]}</span>
            </div>`).join('')}
        </div>
        ${donut([
          { value: d.LOW, color: '#1a7a4f' }, { value: d.MEDIUM, color: '#f0ab2e' },
          { value: d.HIGH, color: '#e0524a' }, { value: d.CRITICAL, color: '#7f1d1d' },
        ], s.counts.suppliers, 'Total<br>Suppliers')}
      </div>
    </section>
  </div>

  <section class="card" id="comparison-card"><div class="empty">Loading supplier comparison…</div></section>

  <div class="grid-2 right-narrow">
    <section class="card" id="contract-card"><div class="empty">Loading buyer documentation…</div></section>
    <section class="card" id="rec-card">
      <div class="card-head">${cardIcon('bot', '#12613f', '#e4f2e9')}<h2>Recommendation</h2></div>
      <div class="empty">Select <b>Get Recommendation</b> to generate an evidence-backed recommendation.</div>
    </section>
  </div>

  <p class="footnote">${esc(s.disclaimer)}</p>`;

  $('#view').innerHTML = html;
  mountChat();
  await renderComparison();
  await renderContractIntel();
};

/* ------------------------------------------------- supplier comparison card */
async function renderComparison() {
  const el = $('#comparison-card');
  if (!el) return;
  const rfqs = (await api('/api/rfqs')).rfqs;
  let data;
  try { data = await api(`/api/rfqs/${state.rfqId}/suppliers`); }
  catch (e) { el.innerHTML = `<div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div>`; return; }

  const rows = data.suppliers;
  el.innerHTML = `
    <div class="card-head">${cardIcon('doc', '#2f6fd0', '#e7f0fd')}
      <h2>${esc(state.rfqId)} — Supplier Comparison</h2>
      <span class="sub">
        <select id="rfq-picker" style="padding:6px 10px;border:1px solid var(--line);border-radius:8px;font-family:inherit;font-size:12.5px">
          ${rfqs.map(r => `<option value="${r.rfq_id}" ${r.rfq_id === state.rfqId ? 'selected' : ''}>${r.rfq_id} — ${esc(r.equipment)}</option>`).join('')}
        </select></span></div>

    <div class="notice plain" style="margin-bottom:14px">${svg('doc', 16)}
      <div><b>${esc(data.rfq.equipment)}</b> for ${esc(data.rfq.clinical_use)} ·
      ${num(data.rfq.quantity)} units · budget ${inrShort(data.rfq.budget_per_unit)}/unit ·
      required delivery ${data.rfq.required_delivery_days} days ·
      warranty ${data.rfq.warranty_months} months · SLA ${data.rfq.service_sla_hours}h</div></div>

    <div class="table-wrap"><table>
      <thead><tr>
        <th>Supplier</th><th>Price</th><th>Delivery</th><th>Quality</th>
        <th>Risk</th><th>Risk prob.</th><th>Confidence</th><th>Score</th><th style="text-align:center">Status</th>
      </tr></thead>
      <tbody>${rows.map((r, i) => `
        <tr class="clickable ${r.eligibility === 'BLOCKED' ? 'is-blocked' : ''}" data-sid="${r.supplier_id}">
          <td><div class="supplier-cell">${supplierAvatar(i)}
            <div><div class="cell-main">${esc(r.supplier_name)}</div>
            <div class="cell-sub">${esc(r.supplier_id)} · ${esc(r.primary_product_category || '')}</div></div></div></td>
          <td><div class="cell-main">${inrShort(r.total_evaluated_cost)}</div>
              <div class="cell-sub">${inrShort(r.quoted_unit_price)}/unit${r.vs_median_pct != null ? ` · ${r.vs_median_pct > 0 ? '+' : ''}${r.vs_median_pct}% vs median` : ''}</div></td>
          <td><div class="cell-main">${r.quoted_delivery_days} days</div>
              <div class="cell-sub">need ${data.rfq.required_delivery_days} days</div></td>
          <td><div class="cell-main">${num(r.quality_score)}%</div><div class="cell-sub">quality score</div></td>
          <td>${riskPill(r.risk_level)}</td>
          <td><div class="cell-main">${pct((r.risk_probability || 0) * 100)}</div></td>
          <td><div class="cell-main">${pct(r.model_confidence)}</div></td>
          <td><span class="num-strong ${scoreClass(r.decision_score)}">${num(r.decision_score, 1)}</span><span class="num-unit">/100</span></td>
          <td style="text-align:center">${eligibilityMark(r.eligibility)}</td>
        </tr>`).join('')}
      </tbody></table></div>

    <div class="actions">
      <button class="btn btn-outline" id="btn-analysis">${svg('report', 16)} View Analysis</button>
      <button class="btn btn-primary" id="btn-recommend">${svg('spark', 16)} Get Recommendation</button>
    </div>
    <p class="footnote" style="margin-top:12px">Score = price 25% · delivery 20% · historical 20% · quality 15% ·
      compliance 15% · resilience 5%. Risk probability and model confidence are separate quantities from the decision score.
      ${rows.filter(r => r.eligibility === 'BLOCKED').length} quotation(s) cannot be auto-approved under buyer policy.</p>`;

  $('#rfq-picker').onchange = async e => {
    state.rfqId = e.target.value; state.supplierId = null;
    await renderComparison(); await renderContractIntel();
    const rc = $('#rec-card');
    if (rc) rc.innerHTML = `<div class="card-head">${cardIcon('bot', '#12613f', '#e4f2e9')}<h2>Recommendation</h2></div>
      <div class="empty">Select <b>Get Recommendation</b> for ${esc(state.rfqId)}.</div>`;
  };
  $$('#comparison-card tbody tr').forEach(tr => {
    tr.onclick = () => showSupplierExplain(state.rfqId, tr.dataset.sid);
  });
  $('#btn-analysis').onclick = () => { location.hash = '#/risk'; };
  $('#btn-recommend').onclick = () => renderRecommendation(true);
}

/* --------------------------------------------------- contract intelligence */
async function renderContractIntel() {
  const el = $('#contract-card');
  if (!el) return;
  let hits;
  try {
    hits = (await api(`/api/documents/search?q=${encodeURIComponent('delivery commitments warranty regulatory compliance award')}&k=4`)).results;
  } catch (e) {
    el.innerHTML = `<div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div>`; return;
  }
  const kb = await api('/api/knowledge-base');
  state.cache.docs = hits;
  const i = Math.min(state.docPage - 1, hits.length - 1);
  const h = hits[i] || {};

  el.innerHTML = `
    <div class="card-head">${cardIcon('file', '#2f6fd0', '#e7f0fd')}<h2>Contract Intelligence</h2>
      <span class="sub">${kb.total_chunks} clauses indexed</span></div>
    <div class="grid-2" style="gap:16px">
      <div>
        <h3 style="font-size:15px;margin-bottom:3px">${esc(h.document_title || '')}</h3>
        <div style="color:var(--green-700);font-weight:650;font-size:13px;margin-bottom:11px">
          ${esc(h.section || '')} — Page ${h.page || 1}</div>
        <div class="notice plain" style="font-style:italic">${svg('file', 15)}<div>"${esc(h.evidence || '')}"</div></div>
        <button class="btn btn-outline btn-sm" id="btn-view-doc" style="margin-top:13px">${svg('file', 15)} View Document</button>
      </div>
      <div>
        <div class="doc-preview">
          ${Array.from({ length: 11 }, (_, k) =>
            `<div class="doc-line ${k === 4 || k === 5 ? 'hl' : ''} ${k % 4 === 3 ? 'short' : ''}"></div>`).join('')}
        </div>
        <div class="doc-pager">
          <button id="doc-prev" ${i === 0 ? 'disabled' : ''}>‹</button>
          <span>Clause ${i + 1} of ${hits.length}</span>
          <button id="doc-next" ${i >= hits.length - 1 ? 'disabled' : ''}>›</button>
        </div>
      </div>
    </div>
    <p class="footnote" style="margin-top:12px">Knowledge base contains buyer RFQs, the procurement policy and the
      master contract only. ${esc(kb.excluded)}</p>`;

  $('#doc-prev').onclick = () => { state.docPage = Math.max(1, state.docPage - 1); renderContractIntel(); };
  $('#doc-next').onclick = () => { state.docPage = Math.min(hits.length, state.docPage + 1); renderContractIntel(); };
  $('#btn-view-doc').onclick = () => openDrawer(h.document_title || 'Document', `
    <div class="notice info">${svg('file', 16)}<div><b>${esc(h.citation)}</b><br>Source file: ${esc(h.source_file)}</div></div>
    <div><div class="section-title">Full clause text</div>
      <div class="card" style="box-shadow:none;background:#fbfcfb;white-space:pre-wrap;font-size:13px;line-height:1.65">${esc(h.passage)}</div></div>
    <a class="btn btn-outline" href="/rag_documents/${h.document_type === 'buyer_rfq' ? 'rfqs/' : ''}${esc(h.source_file)}" target="_blank">
      ${svg('eye', 16)} Open source PDF</a>`);
}

/* --------------------------------------------------------- recommendation */
async function renderRecommendation(announce) {
  const el = $('#rec-card');
  if (!el) return;
  el.innerHTML = `<div class="card-head">${cardIcon('bot', '#12613f', '#e4f2e9')}<h2>Recommendation</h2></div>
    <div class="empty">Analysing quotations, risk predictions and buyer documentation…</div>`;
  let out;
  try { out = await api(`/api/rfqs/${state.rfqId}/recommendation`, { method: 'POST', body: '{}' }); }
  catch (e) { el.innerHTML = `<div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div>`; return; }

  const r = out.recommendation;
  if (!r) { el.innerHTML = `<div class="empty">${esc(out.message || 'No recommendation available.')}</div>`; return; }
  state.cache.rec = r;

  const outcomeTag = r.outcome === 'RECOMMENDED' ? 'ok' : r.outcome === 'FLAGGED' ? 'bad' : 'warn';

  el.innerHTML = `
    <div class="card-head">${cardIcon('bot', '#12613f', '#e4f2e9')}<h2>Recommendation</h2>
      <span class="sub"><span class="tag ${outcomeTag}">${esc(r.outcome.replace(/_/g, ' '))}</span></span></div>
    <div class="rec-panel">
      <div>
        <div class="rec-title">
          <span class="rec-star">${svg('star', 20, 0)}<style>.rec-star svg path{fill:#7fd6a0;stroke:#7fd6a0}</style></span>
          <div><h3>${esc(r.supplier_name)}</h3>
            <div class="outcome">${esc(r.outcome_note)}</div></div>
        </div>
        <ul class="reason-list">
          ${r.reasons.map(x => `<li><span class="ico" style="color:#1a7a4f">${svg('check', 16, 2)}</span>${esc(x.text)}</li>`).join('')}
        </ul>
        ${r.concerns.length ? `<ul class="concern-list">
          ${r.concerns.map(c => `<li><span class="ico" style="color:${c.severity === 'BLOCKING' ? '#c8382f' : '#d98708'}">${svg('alert', 15, 2)}</span>
            <div>${esc(c.text)}<span class="clause">${esc(c.clause || '')}</span></div></li>`).join('')}
        </ul>` : ''}
      </div>
      <div>
        ${gauge(r.decision_score, 'Decision score<br>(out of 100)')}
        <div class="mini-stats">
          <div class="mini-stat"><span>Risk</span><b>${riskPill(r.risk_level)}</b></div>
          <div class="mini-stat"><span>Risk probability</span><b>${pct((r.risk_probability || 0) * 100)}</b></div>
          <div class="mini-stat"><span>Model confidence</span><b>${pct(r.model_confidence)}</b></div>
          ${r.margin_over_runner_up != null ? `<div class="mini-stat"><span>Margin</span><b>+${num(r.margin_over_runner_up, 1)} pts</b></div>` : ''}
          <div class="mini-stat"><span>Reweighting</span><b>${r.robust_to_reweighting ? 'robust' : 'sensitive'}</b></div>
        </div>
      </div>
    </div>

    <div style="margin-top:18px"><div class="section-title">Supporting buyer documentation</div>
      ${evidenceList(r.evidence)}</div>

    <div class="actions">
      <button class="btn btn-primary" id="btn-approve">${svg('thumb', 16)} Approve</button>
      <button class="btn btn-outline" id="btn-review">${svg('eye', 16)} Review</button>
    </div>
    <p class="footnote" style="margin-top:12px">${esc(r.human_authority_note)}</p>`;

  $('#btn-approve').onclick = () => approvalDialog(r, 'APPROVED');
  $('#btn-review').onclick = () => showSupplierExplain(r.rfq_id, r.supplier_id);
  if (announce) toast(`${r.supplier_name} — ${r.decision_score}/100, risk ${r.risk_level}. Human approval required.`);
}

/* ------------------------------------------------------- supplier explain */
async function showSupplierExplain(rfqId, supplierId) {
  state.supplierId = supplierId;
  openDrawer('Loading…', `<div class="empty">Loading explanation…</div>`);
  let d;
  try { d = await api(`/api/rfqs/${rfqId}/suppliers/${supplierId}`); }
  catch (e) { openDrawer('Error', `<div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div>`); return; }

  const w = d.weights, wl = d.weight_labels;
  const contrib = Object.entries(d.weighted_contributions)
    .sort((a, b) => b[1] - a[1])
    .map(([k, v]) => ({ label: `${wl[k]} (${Math.round(w[k] * 100)}%)`, value: v, display: num(v, 1) }));
  const drivers = (d.top_drivers || []).map(x => ({
    label: `${x.label} = ${x.value}`, value: x.contribution_pp,
    display: `${x.contribution_pp > 0 ? '+' : ''}${num(x.contribution_pp, 1)} pp`,
  }));
  const cb = d.confidence_breakdown || {};

  openDrawer(d.supplier_name, `
    <div class="stat-row">
      <div class="stat"><div class="k">Decision score</div><div class="v ${scoreClass(d.decision_score)}">${num(d.decision_score, 1)}<small>/100</small></div></div>
      <div class="stat"><div class="k">Risk</div><div class="v">${riskPill(d.risk_level)}</div></div>
      <div class="stat"><div class="k">Risk probability</div><div class="v">${pct((d.risk_probability || 0) * 100)}</div></div>
      <div class="stat"><div class="k">Confidence</div><div class="v">${pct(d.model_confidence)}</div></div>
    </div>

    <div class="notice ${d.eligibility === 'BLOCKED' ? 'warn' : d.eligibility === 'AUTO_APPROVABLE' ? 'ok' : 'plain'}">
      ${svg(d.eligibility === 'AUTO_APPROVABLE' ? 'check' : 'alert', 16)}
      <div><b>${esc(d.eligibility.replace(/_/g, ' '))}</b>
      ${d.eligibility_reasons.length ? '<br>' + d.eligibility_reasons.map(esc).join('<br>') : ''}</div></div>

    <div><div class="section-title">Decision score composition (weighted points)</div>${barList(contrib)}</div>

    <div><div class="section-title">Quotation vs RFQ</div>
      <dl class="kv">
        <dt>Unit price</dt><dd>${inrShort(d.quoted_unit_price)} (${d.vs_median_pct > 0 ? '+' : ''}${d.vs_median_pct}% vs peer median)</dd>
        <dt>Total evaluated cost</dt><dd>${inrShort(d.total_evaluated_cost)}</dd>
        <dt>Delivery</dt><dd>${d.quoted_delivery_days} days</dd>
        <dt>Warranty</dt><dd>${d.warranty_months} months</dd>
        <dt>Service SLA</dt><dd>${d.service_sla_hours} hours</dd>
        <dt>Compliance docs</dt><dd>${esc(d.compliance_docs)}</dd>
      </dl></div>

    <div><div class="section-title">Risk drivers — Shapley attributions (percentage points)</div>
      ${drivers.length ? divergingBars(drivers) : '<div class="empty">No attributions available.</div>'}
      <p class="footnote" style="margin-top:8px">Red increases predicted disruption risk, green reduces it.</p></div>

    <div><div class="section-title">Model confidence breakdown</div>
      ${Object.keys(cb).length ? barList(Object.entries(cb).map(([k, v]) => ({
        label: `${k.replace(/_/g, ' ')} (${Math.round(v.weight * 100)}%)`, value: v.value, display: pct(v.value),
      })), { max: 100 }) : '<div class="empty">Not available.</div>'}
      <p class="footnote" style="margin-top:8px">Confidence measures evidence strength and consistency. It is deliberately
        <b>not</b> 100 minus risk.</p></div>

    ${d.flags && d.flags.length ? `<div><div class="section-title">Policy flags</div>
      <div class="evidence">${d.flags.map(f => `<div class="ev-item" style="background:${f.severity === 'BLOCKING' ? '#fdeceb' : f.severity === 'REVIEW' ? '#fdf3e0' : '#f6f8f7'}">
        <div class="src">${esc(f.severity)} — ${esc(f.code)}</div>
        <div class="quote" style="font-style:normal">${esc(f.message)}</div>
        <div class="why">${esc(f.clause || '')}</div></div>`).join('')}</div></div>` : ''}

    <div><div class="section-title">Buyer documentation</div>${evidenceList(d.evidence)}</div>

    <div class="actions" style="justify-content:flex-start">
      <button class="btn btn-primary btn-sm" id="dw-approve">${svg('thumb', 15)} Approve</button>
      <button class="btn btn-danger btn-sm" id="dw-reject">${svg('cross', 15)} Reject</button>
      <button class="btn btn-outline btn-sm" id="dw-ask">${svg('chat', 15)} Ask Copilot</button>
    </div>`);

  $('#dw-approve').onclick = () => approvalDialog(d, 'APPROVED');
  $('#dw-reject').onclick = () => approvalDialog(d, 'REJECTED');
  $('#dw-ask').onclick = () => {
    closeDrawer();
    if (location.hash !== '#/overview') location.hash = '#/overview';
    setTimeout(() => askCopilot(`Why is ${d.supplier_name} scored the way it is on ${rfqId}?`), 350);
  };
}

/* --------------------------------------------------------- approval dialog */
function approvalDialog(row, decision) {
  const blocked = row.eligibility === 'BLOCKED';
  openDrawer(`${decision === 'APPROVED' ? 'Approve' : 'Reject'} — ${row.supplier_name}`, `
    ${blocked && decision === 'APPROVED' ? `<div class="notice warn">${svg('alert', 16)}
      <div><b>Policy override.</b> This supplier is BLOCKED under buyer policy
      (POL-MED-001 §4). Approving requires a written justification, and the override
      is recorded in the audit trail.</div></div>` : ''}
    <dl class="kv">
      <dt>RFQ</dt><dd>${esc(row.rfq_id)}</dd>
      <dt>Supplier</dt><dd>${esc(row.supplier_name)} (${esc(row.supplier_id)})</dd>
      <dt>Decision score</dt><dd>${num(row.decision_score, 1)}/100</dd>
      <dt>Risk</dt><dd>${esc(row.risk_level)} · ${pct((row.risk_probability || 0) * 100)} probability</dd>
      <dt>Model confidence</dt><dd>${pct(row.model_confidence)}</dd>
    </dl>
    <div class="field"><label for="ap-name">Approver</label>
      <input id="ap-name" value="Yash Sharma" placeholder="Your name"></div>
    <div class="field"><label for="ap-reason">Reason ${blocked && decision === 'APPROVED' ? '(required)' : '(optional)'}</label>
      <textarea id="ap-reason" placeholder="Record the rationale for the audit trail…"></textarea></div>
    <div class="actions" style="justify-content:flex-start">
      <button class="btn ${decision === 'APPROVED' ? 'btn-primary' : 'btn-danger'}" id="ap-confirm">
        Confirm ${decision === 'APPROVED' ? 'approval' : 'rejection'}</button>
      <button class="btn btn-outline" id="ap-cancel">Cancel</button>
    </div>
    <p class="footnote">The decision, approver, scores and timestamp are written to the approvals
      table and the audit trail.</p>`);

  $('#ap-cancel').onclick = closeDrawer;
  $('#ap-confirm').onclick = async () => {
    const approver = $('#ap-name').value.trim();
    const reason = $('#ap-reason').value.trim();
    if (!approver) return toast('An approver name is required.', true);
    try {
      const res = await api('/api/approvals', {
        method: 'POST',
        body: JSON.stringify({ rfq_id: row.rfq_id, supplier_id: row.supplier_id, decision, approver, reason }),
      });
      closeDrawer();
      toast(`${row.supplier_name} ${decision.toLowerCase()} by ${approver}${res.policy_override ? ' (policy override recorded)' : ''}.`);
      if (location.hash === '#/overview' || location.hash === '') views.overview();
      else route();
    } catch (e) { toast(e.message, true); }
  };
}

/* ------------------------------------------------------------------ chat */
function mountChat() {
  const log = $('#chat-log');
  if (!log) return;
  renderChat();
  $('#chat-send').onclick = () => askCopilot($('#chat-q').value);
  $('#chat-q').onkeydown = e => { if (e.key === 'Enter') askCopilot($('#chat-q').value); };
  $$('#chat-chips .chip').forEach(b => { b.onclick = () => askCopilot(b.textContent); });
}
function renderChat() {
  const log = $('#chat-log');
  if (!log) return;
  if (!state.chat.length) {
    log.innerHTML = `<div class="bubble me">Which supplier should I select for ${esc(state.rfqId)}?
      <span class="stamp">tap send, or pick a suggestion</span></div>`;
    return;
  }
  log.innerHTML = state.chat.map(m => m.role === 'me'
    ? `<div class="bubble me">${esc(m.text)}<span class="stamp">${m.time}</span></div>`
    : `<div class="bubble ai${m.outOfScope ? ' out-of-scope' : ''}">${esc(m.text)}
        ${m.citations && m.citations.length ? `<div class="cites">${m.citations.map(citeBlock).join('')}</div>` : ''}
        ${m.suggestions && m.suggestions.length ? `<div class="cites">${m.suggestions.map(s =>
            `<button class="chip suggest">${esc(s)}</button>`).join('')}</div>` : ''}
        <span class="stamp">${esc(m.mode)} · ${m.time}</span></div>`).join('');
  // Suggested questions inside a refusal are clickable.
  $$('.bubble .chip.suggest', log).forEach(b => { b.onclick = () => askCopilot(b.textContent); });
  log.scrollTop = log.scrollHeight;
}
async function askCopilot(question) {
  question = (question || '').trim();
  if (!question) return;
  const t = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  state.chat.push({ role: 'me', text: question, time: t });
  const input = $('#chat-q'); if (input) input.value = '';
  renderChat();
  try {
    const a = await api('/api/copilot/query', {
      method: 'POST',
      body: JSON.stringify({ question, rfq_id: state.rfqId, supplier_id: state.supplierId }),
    });
    state.chat.push({
      role: 'ai', text: a.answer, citations: a.citations, mode: a.mode, time: t,
      outOfScope: a.in_scope === false, suggestions: a.suggestions || [],
    });
  } catch (e) {
    state.chat.push({ role: 'ai', text: `Sorry — ${e.message}`, citations: [], mode: 'error', time: t });
  }
  renderChat();
}

/* ---------------------------------------------------------------- RFQs */
views.rfqs = async () => {
  const { rfqs } = await api('/api/rfqs');
  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('doc', '#2f6fd0', '#e7f0fd')}<h2>Requests for Quotation</h2>
        <span class="sub">${rfqs.length} RFQs</span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>RFQ</th><th>Equipment</th><th>Qty</th><th>Budget/unit</th>
          <th>Delivery</th><th>Warranty</th><th>Quotes</th><th>Best score</th><th>Status</th></tr></thead>
        <tbody>${rfqs.map(r => `
          <tr class="clickable" data-rfq="${r.rfq_id}">
            <td><div class="cell-main">${esc(r.rfq_id)}</div><div class="cell-sub">${esc(r.issue_date)}</div></td>
            <td><div class="cell-main">${esc(r.equipment)}</div><div class="cell-sub">${esc(r.clinical_use)}</div></td>
            <td>${num(r.quantity)}</td>
            <td>${inrShort(r.budget_per_unit)}</td>
            <td>${r.required_delivery_days} d</td>
            <td>${r.warranty_months} mo</td>
            <td>${r.quotes}</td>
            <td>${r.best_score != null ? `<span class="num-strong ${scoreClass(r.best_score)}">${num(r.best_score, 1)}</span>` : '--'}</td>
            <td><span class="tag ${r.status === 'Open' ? 'ok' : ''}">${esc(r.status)}</span></td>
          </tr>`).join('')}</tbody></table></div>
    </section>`;
  $$('#view tbody tr').forEach(tr => {
    tr.onclick = () => { state.rfqId = tr.dataset.rfq; location.hash = '#/overview'; };
  });
};

/* ------------------------------------------------------------- SUPPLIERS */
views.suppliers = async () => {
  const render = async (q, lvl) => {
    const url = `/api/suppliers?${q ? 'q=' + encodeURIComponent(q) + '&' : ''}${lvl ? 'risk_level=' + lvl : ''}`;
    const { suppliers, count } = await api(url);
    $('#sup-body').innerHTML = suppliers.length ? suppliers.map((s, i) => `
      <tr class="clickable" data-sid="${s.supplier_id}">
        <td><div class="supplier-cell">${supplierAvatar(i, (s.supplier_name || '?')[0])}
          <div><div class="cell-main">${esc(s.supplier_name)}</div>
          <div class="cell-sub">${esc(s.supplier_id)} · ${esc(s.contact_email || '')}</div></div></div></td>
        <td>${esc(s.primary_product_category || '')}</td>
        <td><span class="tag ${/suspend/i.test(s.fda_status) ? 'bad' : /major/i.test(s.fda_status) ? 'warn' : 'ok'}">${esc(s.fda_status)}</span></td>
        <td><span class="tag ${s.ce_status === 'Valid' ? 'ok' : s.ce_status === 'Expired' ? 'bad' : 'warn'}">${esc(s.ce_status)}</span></td>
        <td>${num(s.on_time_delivery, 1)}%</td>
        <td>${num(s.lead_time_variability, 0)} d</td>
        <td>${riskPill(s.risk_level)}</td>
        <td>${s.risk_score != null ? num(s.risk_score, 0) : '--'}</td>
        <td>${pct(s.model_confidence)}</td>
      </tr>`).join('') : `<tr><td colspan="9"><div class="empty">No suppliers match.</div></td></tr>`;
    $('#sup-count').textContent = `${count} suppliers`;
    $$('#sup-body tr.clickable').forEach(tr => { tr.onclick = () => showSupplierProfile(tr.dataset.sid); });
  };

  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('users', '#1a7a4f', '#e4f2e9')}<h2>Supplier Master</h2>
        <span class="sub" id="sup-count">…</span></div>
      <div class="toolbar">
        <input class="grow" id="sup-q" placeholder="Search by name, id or product category…">
        <select id="sup-lvl">
          <option value="">All risk levels</option>
          <option value="LOW">Low</option><option value="MEDIUM">Medium</option>
          <option value="HIGH">High</option><option value="CRITICAL">Critical</option>
        </select>
      </div>
      <div class="table-wrap"><table>
        <thead><tr><th>Supplier</th><th>Category</th><th>FDA</th><th>CE</th>
          <th>On-time</th><th>LT var.</th><th>Risk</th><th>Score</th><th>Confidence</th></tr></thead>
        <tbody id="sup-body"><tr><td colspan="9"><div class="empty">Loading…</div></td></tr></tbody>
      </table></div>
    </section>`;

  let timer;
  $('#sup-q').oninput = () => { clearTimeout(timer); timer = setTimeout(() => render($('#sup-q').value, $('#sup-lvl').value), 220); };
  $('#sup-lvl').onchange = () => render($('#sup-q').value, $('#sup-lvl').value);
  await render('', '');
};

async function showSupplierProfile(sid) {
  openDrawer('Loading…', `<div class="empty">Loading supplier…</div>`);
  const s = await api(`/api/suppliers/${sid}`);
  const r = s.risk || {};
  const drivers = (r.top_drivers || []).map(x => ({
    label: `${x.label} = ${x.value}`, value: x.contribution_pp,
    display: `${x.contribution_pp > 0 ? '+' : ''}${num(x.contribution_pp, 1)} pp`,
  }));
  openDrawer(s.supplier_name, `
    <div class="stat-row">
      <div class="stat"><div class="k">Risk</div><div class="v">${riskPill(r.risk_level)}</div></div>
      <div class="stat"><div class="k">Risk score</div><div class="v">${num(r.risk_score, 0)}<small>/100</small></div></div>
      <div class="stat"><div class="k">Confidence</div><div class="v">${pct(r.model_confidence)}</div></div>
    </div>
    <div><div class="section-title">Contact &amp; category</div>
      <dl class="kv"><dt>Supplier id</dt><dd>${esc(s.supplier_id)}</dd>
        <dt>Category</dt><dd>${esc(s.primary_product_category)}</dd>
        <dt>Contact</dt><dd>${esc(s.contact_name)}</dd>
        <dt>Email</dt><dd>${esc(s.contact_email)}</dd>
        <dt>Phone</dt><dd>${esc(s.contact_phone)}</dd></dl></div>
    <div><div class="section-title">Regulatory</div>
      <dl class="kv"><dt>FDA</dt><dd>${esc(s.fda_status)}</dd>
        <dt>CE marking</dt><dd>${esc(s.ce_status)}</dd>
        <dt>ISO 13485</dt><dd>${esc(s.iso_13485_status)}</dd>
        <dt>510(k)</dt><dd>${esc(s.clearance_510k_status)}</dd>
        <dt>Last inspection</dt><dd>${esc(s.last_inspection_outcome)} (${s.months_since_inspection} months ago)</dd>
        <dt>Recalls (3y)</dt><dd>${s.recalls_3y}</dd>
        <dt>Adverse events</dt><dd>${s.adverse_events}</dd></dl></div>
    <div><div class="section-title">Procurement sub-scores</div>
      ${barList(Object.entries(s.subscores).map(([k, v]) => ({
        label: k.replace(/_/g, ' '), value: v, display: num(v, 1),
      })), { max: 100 })}</div>
    <div><div class="section-title">Risk drivers</div>
      ${drivers.length ? divergingBars(drivers) : '<div class="empty">No prediction on file.</div>'}</div>
    <div><div class="section-title">Quotations (${s.quotes.length})</div>
      <div class="table-wrap"><table><thead><tr><th>RFQ</th><th>Equipment</th><th>Unit price</th><th>Days</th><th>Score</th></tr></thead>
      <tbody>${s.quotes.map(q => `<tr><td>${esc(q.rfq_id)}</td><td>${esc(q.equipment)}</td>
        <td>${inrShort(q.quoted_unit_price)}</td><td>${q.quoted_delivery_days}</td>
        <td>${q.decision_score != null ? num(q.decision_score, 1) : '--'}</td></tr>`).join('')}</tbody></table></div></div>`);
}

/* ------------------------------------------------------------------ RISK */
views.risk = async () => {
  const d = await api('/api/risk');
  const m = d.model || {};
  const total = d.suppliers.length;
  const gi = (m.global_feature_importance || []).slice(0, 8);

  $('#view').innerHTML = `
    <div class="grid-2 right-narrow">
      <section class="card">
        <div class="card-head">${cardIcon('shield', '#c8382f', '#fdeceb')}<h2>Risk Distribution</h2>
          <span class="sub">${total} suppliers scored</span></div>
        <div class="risk-split">
          <div class="risk-bars">
            ${[['LOW', '#1a7a4f'], ['MEDIUM', '#f0ab2e'], ['HIGH', '#e0524a'], ['CRITICAL', '#7f1d1d']].map(([k, c]) => `
              <div class="risk-row"><span class="lbl">${k}</span>
                <div class="risk-track"><div class="risk-fill" style="width:${total ? (d.distribution[k] / total * 100).toFixed(1) : 0}%;background:${c}"></div></div>
                <span class="num">${d.distribution[k]}</span></div>`).join('')}
          </div>
          ${donut([
            { value: d.distribution.LOW, color: '#1a7a4f' }, { value: d.distribution.MEDIUM, color: '#f0ab2e' },
            { value: d.distribution.HIGH, color: '#e0524a' }, { value: d.distribution.CRITICAL, color: '#7f1d1d' },
          ], total, 'Suppliers<br>rated')}
        </div>
        <p class="footnote" style="margin-top:14px">Bands per policy POL-MED-001 §4: LOW 0-25, MEDIUM &gt;25-50,
          HIGH &gt;50-75, CRITICAL &gt;75.</p>
      </section>

      <section class="card">
        <div class="card-head">${cardIcon('chart', '#12613f', '#e4f2e9')}<h2>Model</h2></div>
        ${m.available === false ? `<div class="empty">${esc(m.message)}</div>` : `
        <dl class="kv" style="margin-bottom:14px">
          <dt>Selected</dt><dd>${esc(m.selected_model)}</dd>
          <dt>Validation</dt><dd>${esc(m.cv_design)}</dd>
          <dt>Sample</dt><dd>${m.n_samples} suppliers · ${m.n_features} features · ${pct((m.positive_rate || 0) * 100)} positive</dd>
          <dt>Prediction basis</dt><dd>${esc(m.prediction_basis || '')}</dd>
          <dt>Explainability</dt><dd>${esc(m.explainability_method)}</dd>
        </dl>
        <div class="section-title">Global feature importance (mean |Shapley|, pp)</div>
        ${barList(gi.map(g => ({ label: g.label, value: g.mean_abs_pp, display: num(g.mean_abs_pp, 2) })))}
        <div class="notice warn" style="margin-top:14px">${svg('alert', 16)}<div>${esc(m.data_note || '')}</div></div>`}
      </section>
    </div>

    <section class="card">
      <div class="card-head">${cardIcon('alert', '#d98708', '#fdf3e0')}<h2>Supplier Risk Register</h2>
        <span class="sub">highest predicted disruption risk first</span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Supplier</th><th>Category</th><th>Risk</th><th>Score</th><th>Probability</th>
          <th>Confidence</th><th>On-time</th><th>LT var.</th><th>Leading driver</th></tr></thead>
        <tbody>${d.suppliers.map((s, i) => `
          <tr class="clickable" data-sid="${s.supplier_id}">
            <td><div class="supplier-cell">${supplierAvatar(i, (s.supplier_name || '?')[0])}
              <div><div class="cell-main">${esc(s.supplier_name)}</div>
              <div class="cell-sub">${esc(s.supplier_id)}</div></div></div></td>
            <td>${esc(s.primary_product_category || '')}</td>
            <td>${riskPill(s.risk_level)}</td>
            <td><span class="num-strong">${num(s.risk_score, 0)}</span><span class="num-unit">/100</span></td>
            <td>${pct((s.risk_probability || 0) * 100)}</td>
            <td>${pct(s.model_confidence)}</td>
            <td>${num(s.on_time_delivery, 1)}%</td>
            <td>${num(s.lead_time_variability, 0)} d</td>
            <td><div class="cell-sub">${esc((s.top_drivers[0] || {}).label || '--')}
              ${s.top_drivers[0] ? `<b style="color:${s.top_drivers[0].contribution_pp > 0 ? '#c8382f' : '#1a7a4f'}">
                ${s.top_drivers[0].contribution_pp > 0 ? '+' : ''}${num(s.top_drivers[0].contribution_pp, 1)} pp</b>` : ''}</div></td>
          </tr>`).join('')}</tbody></table></div>
    </section>

    <section class="card">
      <div class="card-head">${cardIcon('chart', '#2f6fd0', '#e7f0fd')}<h2>Average Risk by Product Category</h2></div>
      ${barList(d.by_category.map(c => ({
        label: `${c.category} (${c.suppliers})`, value: c.avg_risk, display: num(c.avg_risk, 1),
        color: c.avg_risk > 50 ? '#e0524a' : c.avg_risk > 25 ? '#f0ab2e' : '#1a7a4f',
      })), { max: 100 })}
    </section>`;
  $$('#view tbody tr.clickable').forEach(tr => { tr.onclick = () => showSupplierProfile(tr.dataset.sid); });
};

/* ------------------------------------------------------------- CONTRACTS */
views.contracts = async () => {
  const kb = await api('/api/knowledge-base');
  const typeLabel = t => ({
    buyer_policy: 'Procurement policy', buyer_master_contract: 'Master contract', buyer_rfq: 'RFQ',
  }[t] || t);

  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('search', '#12613f', '#e4f2e9')}<h2>Buyer Contract &amp; Policy Intelligence</h2>
        <span class="sub">${kb.total_chunks} clauses · ${kb.retriever}</span></div>
      <div class="toolbar">
        <input class="grow" id="kb-q" placeholder="Ask the buyer documentation… e.g. can a supplier with suspended FDA certification be approved?">
        <select id="kb-type"><option value="">All documents</option>
          <option value="buyer_policy">Procurement policy</option>
          <option value="buyer_master_contract">Master contract</option>
          <option value="buyer_rfq">RFQs</option></select>
        <button class="btn btn-primary btn-sm" id="kb-go">${svg('search', 15)} Search</button>
      </div>
      <div id="kb-results"><div class="empty">Enter a question to retrieve cited clauses.</div></div>
    </section>

    <section class="card">
      <div class="card-head">${cardIcon('file', '#2f6fd0', '#e7f0fd')}<h2>Knowledge Base</h2></div>
      <div class="notice ok">${svg('check', 16)}<div>${esc(kb.excluded)}</div></div>
      <div class="table-wrap" style="margin-top:14px"><table>
        <thead><tr><th>Document</th><th>Type</th><th>Pages</th><th>Clauses</th><th>Source file</th></tr></thead>
        <tbody>${kb.documents.map(d => `
          <tr><td><div class="cell-main">${esc(d.document_id)}</div>
            <div class="cell-sub">${esc(d.title)}</div></td>
            <td><span class="tag info">${typeLabel(d.document_type)}</span></td>
            <td>${d.pages}</td><td>${d.chunks}</td>
            <td><a class="mono" href="/rag_documents/${d.document_type === 'buyer_rfq' ? 'rfqs/' : ''}${esc(d.source_file)}"
              target="_blank" style="color:var(--green-700)">${esc(d.source_file)}</a></td></tr>`).join('')}
        </tbody></table></div>
    </section>`;

  const run = async () => {
    const q = $('#kb-q').value.trim();
    if (!q) return;
    $('#kb-results').innerHTML = `<div class="empty">Retrieving…</div>`;
    try {
      const t = $('#kb-type').value;
      const { results } = await api(`/api/documents/search?q=${encodeURIComponent(q)}&k=6${t ? '&document_type=' + t : ''}`);
      $('#kb-results').innerHTML = results.length ? evidenceList(results)
        : `<div class="empty">No clause matched that query.</div>`;
    } catch (e) { $('#kb-results').innerHTML = `<div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div>`; }
  };
  $('#kb-go').onclick = run;
  $('#kb-q').onkeydown = e => { if (e.key === 'Enter') run(); };
};

/* ------------------------------------------------------------- ANALYTICS */
views.analytics = async () => {
  const a = await api('/api/analytics');
  $('#view').innerHTML = `
    <div class="grid-2">
      <section class="card">
        <div class="card-head">${cardIcon('chart', '#12613f', '#e4f2e9')}<h2>Budget Headroom by RFQ</h2></div>
        ${barList(a.spend_by_rfq.filter(s => s.headroom_pct != null).map(s => ({
          label: `${s.rfq_id} ${s.equipment}`, value: s.headroom_pct, display: num(s.headroom_pct, 1) + '%',
          color: s.headroom_pct < 0 ? '#e0524a' : '#1a7a4f',
        })))}
        <p class="footnote" style="margin-top:10px">Best quotation vs RFQ budget per unit. Negative means every
          quotation exceeds budget.</p>
      </section>
      <section class="card">
        <div class="card-head">${cardIcon('check', '#7a4fd0', '#f0eafc')}<h2>Eligibility Mix</h2></div>
        ${barList(a.eligibility_mix.map(e => ({
          label: e.eligibility.replace(/_/g, ' '), value: e.n, display: e.n,
          color: e.eligibility === 'BLOCKED' ? '#e0524a' : e.eligibility === 'REVIEW_REQUIRED' ? '#f0ab2e' : '#1a7a4f',
        })))}
        <div class="section-title" style="margin-top:18px">FDA status mix (all suppliers)</div>
        ${barList(a.fda_status_mix.map(f => ({
          label: f.fda_status, value: f.n, display: f.n,
          color: /suspend/i.test(f.fda_status) ? '#e0524a' : /major/i.test(f.fda_status) ? '#f0ab2e' : '#1a7a4f',
        })))}
      </section>
    </div>
    <section class="card">
      <div class="card-head">${cardIcon('report', '#2f6fd0', '#e7f0fd')}<h2>Decision Score Spread by RFQ</h2>
        <span class="sub">how much separation the scoring engine produces</span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>RFQ</th><th>Equipment</th><th>Quotes</th><th>Min</th><th>Avg</th><th>Max</th>
          <th>Spread</th><th>Blocked</th><th>Budget total</th><th>Best quote total</th></tr></thead>
        <tbody>${a.score_spread.map(s => {
          const sp = a.spend_by_rfq.find(x => x.rfq_id === s.rfq_id) || {};
          return `<tr><td class="cell-main">${esc(s.rfq_id)}</td><td>${esc(sp.equipment || '')}</td>
            <td>${s.n}</td><td>${num(s.min_score, 1)}</td><td>${num(s.avg_score, 1)}</td>
            <td class="${scoreClass(s.max_score)}"><b>${num(s.max_score, 1)}</b></td>
            <td>${num(s.max_score - s.min_score, 1)}</td>
            <td>${s.blocked ? `<span class="tag bad">${s.blocked}</span>` : '0'}</td>
            <td>${inrShort(sp.budget_total)}</td><td>${inrShort(sp.best_quote_total)}</td></tr>`;
        }).join('')}</tbody></table></div>
    </section>
    <section class="card">
      <div class="card-head">${cardIcon('gear', '#12613f', '#e4f2e9')}<h2>Scoring Weights in Force</h2></div>
      ${barList(Object.entries(a.weights).map(([k, v]) => ({
        label: a.weight_labels[k], value: v * 100, display: Math.round(v * 100) + '%',
      })), { max: 100 })}
    </section>`;
};

/* --------------------------------------------------------------- REPORTS */
views.reports = async () => {
  let r;
  try { r = await api('/api/model/evaluation'); }
  catch (e) { $('#view').innerHTML = `<section class="card"><div class="notice warn">${svg('alert', 16)}<div>${esc(e.message)}</div></div></section>`; return; }

  const metricRow = (key, label) => {
    const cells = ['logistic_regression', 'random_forest', 'xgboost'].map(k => {
      const m = ((r.models[k] || {}).metrics || {})[key] || {};
      const best = k === r.selected_model;
      return `<td class="${best ? 'cell-main' : ''}" style="${best ? 'color:var(--green-700)' : ''}">
        ${m.mean != null ? num(m.mean, 3) : '--'}
        <span class="num-unit"> ±${m.std != null ? num(m.std, 3) : '--'}</span></td>`;
    }).join('');
    return `<tr><td class="cell-main">${label}</td>${cells}</tr>`;
  };

  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('report', '#2f6fd0', '#e7f0fd')}<h2>Model Evaluation Report</h2>
        <span class="sub">generated ${dt(r.generated_at)}</span></div>
      <div class="notice warn" style="margin-bottom:16px">${svg('alert', 16)}<div>${esc(r.data_note)}</div></div>
      <dl class="kv" style="margin-bottom:18px">
        <dt>Target</dt><dd>${esc(r.target)}</dd>
        <dt>Leakage control</dt><dd>${esc(r.leakage_control)}</dd>
        <dt>Validation design</dt><dd>${esc(r.cv_design)} (${(r.models[r.selected_model] || {}).n_fits} fits per model)</dd>
        <dt>Selection rule</dt><dd>${esc(r.selection_rule)}</dd>
        <dt>Selected model</dt><dd><b style="color:var(--green-700)">${esc(r.selected_model_name)}</b></dd>
        <dt>Explainability</dt><dd>${esc(r.explainability_method)}</dd>
        <dt>Compute backend</dt><dd class="mono">${esc(JSON.stringify({
          sklearn: r.compute_backend.sklearn_available, xgboost: r.compute_backend.xgboost_available }))}</dd>
      </dl>
      <div class="section-title">Cross-validated metrics (mean ± sd across repeats)</div>
      <div class="table-wrap"><table>
        <thead><tr><th>Metric</th>
          <th>${esc((r.models.logistic_regression || {}).display_name || 'Logistic Regression')}</th>
          <th>${esc((r.models.random_forest || {}).display_name || 'Random Forest')}</th>
          <th>${esc((r.models.xgboost || {}).display_name || 'XGBoost')}</th></tr></thead>
        <tbody>
          ${metricRow('roc_auc', 'ROC-AUC')}
          ${metricRow('f1', 'F1')}
          ${metricRow('accuracy', 'Accuracy')}
          ${metricRow('precision', 'Precision')}
          ${metricRow('recall', 'Recall')}
          ${metricRow('brier', 'Brier score (lower is better)')}
        </tbody></table></div>
      <p class="footnote" style="margin-top:12px">The selected column is highlighted. XGBoost is not privileged:
        the model with the best validated ROC-AUC is selected, and here that is
        <b>${esc(r.selected_model_name)}</b>.</p>
    </section>

    <div class="grid-2">
      <section class="card">
        <div class="card-head">${cardIcon('chart', '#12613f', '#e4f2e9')}<h2>Global Feature Importance</h2></div>
        ${barList((r.global_feature_importance || []).slice(0, 10).map(g => ({
          label: g.label, value: g.mean_abs_pp, display: num(g.mean_abs_pp, 2) + ' pp',
        })))}
      </section>
      <section class="card">
        <div class="card-head">${cardIcon('alert', '#d98708', '#fdf3e0')}<h2>Limitations</h2></div>
        <ul class="reason-list">${(r.limitations || []).map(l =>
          `<li><span class="ico" style="color:#d98708">${svg('alert', 15, 2)}</span>${esc(l)}</li>`).join('')}</ul>
      </section>
    </div>

    <section class="card">
      <div class="card-head">${cardIcon('doc', '#7a4fd0', '#f0eafc')}<h2>Raw Report</h2>
        <span class="sub"><a class="btn btn-outline btn-sm" href="/api/model/evaluation" target="_blank">${svg('eye', 15)} Open JSON</a></span></div>
      <p class="footnote">The complete evaluation artefact is written to <span class="mono">models/model_evaluation.json</span>
        on every build, so the numbers on this page can always be traced back to a file.</p>
    </section>`;
};

/* ------------------------------------------------------------- APPROVALS */
views.approvals = async () => {
  const a = await api('/api/approvals');
  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('clock', '#d98708', '#fdf3e0')}<h2>Pending Human Decision</h2>
        <span class="sub">${a.pending.length} awaiting</span></div>
      ${a.pending.length ? `<div class="table-wrap"><table>
        <thead><tr><th>RFQ</th><th>Equipment</th><th>Recommended supplier</th><th>Score</th>
          <th>Risk</th><th>Confidence</th><th>Outcome</th><th>Generated</th><th></th></tr></thead>
        <tbody>${a.pending.map(p => `
          <tr><td class="cell-main">${esc(p.rfq_id)}</td><td>${esc(p.equipment)}</td>
            <td>${esc(p.supplier_name)}</td>
            <td><span class="num-strong ${scoreClass(p.decision_score)}">${num(p.decision_score, 1)}</span></td>
            <td>${riskPill(p.risk_level)}</td><td>${pct(p.model_confidence)}</td>
            <td><span class="tag ${p.outcome === 'RECOMMENDED' ? 'ok' : p.outcome === 'FLAGGED' ? 'bad' : 'warn'}">${esc(p.outcome.replace(/_/g, ' '))}</span></td>
            <td class="cell-sub">${dt(p.created_at)}</td>
            <td><button class="btn btn-outline btn-sm" data-rfq="${p.rfq_id}" data-sid="${p.supplier_id}">Review</button></td>
          </tr>`).join('')}</tbody></table></div>`
        : `<div class="empty">Nothing pending. Generate a recommendation from the Overview screen.</div>`}
      <p class="footnote" style="margin-top:12px">AI recommendations are advisory. A procurement manager must approve all
        awards involving High/Critical risk or regulatory exceptions (POL-MED-001 §7).</p>
    </section>

    <section class="card">
      <div class="card-head">${cardIcon('check', '#1a7a4f', '#e4f2e9')}<h2>Decision History</h2>
        <span class="sub">${a.approvals.length} recorded</span></div>
      ${a.approvals.length ? `<div class="table-wrap"><table>
        <thead><tr><th>Decided</th><th>RFQ</th><th>Supplier</th><th>Decision</th><th>Score</th>
          <th>Risk</th><th>Approver</th><th>Reason</th></tr></thead>
        <tbody>${a.approvals.map(x => `
          <tr><td class="cell-sub">${dt(x.decided_at)}</td><td>${esc(x.rfq_id)}</td><td>${esc(x.supplier_id)}</td>
            <td><span class="tag ${x.decision === 'APPROVED' ? 'ok' : 'bad'}">${esc(x.decision)}</span></td>
            <td>${num(x.recommendation_score, 1)}</td><td>${num(x.risk_score, 0)}</td>
            <td>${esc(x.approver)}</td><td class="cell-sub">${esc(x.reason || '--')}</td></tr>`).join('')}
        </tbody></table></div>` : `<div class="empty">No decisions recorded yet.</div>`}
    </section>`;
  $$('#view button[data-rfq]').forEach(b => {
    b.onclick = () => showSupplierExplain(b.dataset.rfq, b.dataset.sid);
  });
};

/* ----------------------------------------------------------------- AUDIT */
views.audit = async () => {
  const { events } = await api('/api/audit?limit=300');
  const tagFor = e => e.event_type === 'HUMAN_DECISION'
    ? (e.decision === 'APPROVED' ? 'ok' : 'bad')
    : e.event_type === 'HUMAN_REVIEW' ? 'info' : 'warn';
  $('#view').innerHTML = `
    <section class="card">
      <div class="card-head">${cardIcon('list', '#7a4fd0', '#f0eafc')}<h2>Audit Trail</h2>
        <span class="sub">${events.length} events · append-only</span></div>
      ${events.length ? `<div class="table-wrap"><table>
        <thead><tr><th>When</th><th>Event</th><th>RFQ</th><th>Supplier</th><th>Score</th>
          <th>Risk</th><th>Decision</th><th>Actor</th><th>Reason</th></tr></thead>
        <tbody>${events.map(e => `
          <tr><td class="cell-sub">${dt(e.created_at)}</td>
            <td><span class="tag ${tagFor(e)}">${esc(e.event_type.replace(/_/g, ' '))}</span></td>
            <td>${esc(e.rfq_id || '--')}</td><td>${esc(e.supplier_id || '--')}</td>
            <td>${e.decision_score != null ? num(e.decision_score, 1) : '--'}</td>
            <td>${e.risk_score != null ? num(e.risk_score, 0) : '--'}</td>
            <td>${esc(e.decision || '--')}</td><td>${esc(e.actor)}</td>
            <td class="cell-sub" style="max-width:340px">${esc(e.reason || '')}</td></tr>`).join('')}
        </tbody></table></div>` : `<div class="empty">No events recorded yet.</div>`}
      <p class="footnote" style="margin-top:12px">Every recommendation, review and approval is recorded with scores,
        risk, actor and timestamp (CON-MED-001 §9).</p>
    </section>`;
};

/* -------------------------------------------------------------- SETTINGS */
views.settings = async () => {
  const s = await api('/api/settings');
  const h = await api('/api/health');
  $('#view').innerHTML = `
    <div class="grid-2">
      <section class="card">
        <div class="card-head">${cardIcon('gear', '#12613f', '#e4f2e9')}<h2>Decision Score Weights</h2></div>
        ${barList(Object.entries(s.weights).map(([k, v]) => ({
          label: s.weight_labels[k], value: v * 100, display: Math.round(v * 100) + '%',
        })), { max: 100 })}
        <p class="footnote" style="margin-top:12px">Weights are read from <span class="mono">data/scoring_spec.json</span>
          at request time — edit that file and reload to reconfigure the engine without code changes.</p>
      </section>
      <section class="card">
        <div class="card-head">${cardIcon('shield', '#c8382f', '#fdeceb')}<h2>Thresholds &amp; Governance</h2></div>
        <dl class="kv">
          ${Object.entries(s.risk_bands).map(([k, v]) => `<dt>${k}</dt><dd>${v}</dd>`).join('')}
          <dt>Suspicious low bid</dt><dd>below ${Math.round(s.suspicious_low_bid_ratio * 100)}% of peer median</dd>
          <dt>RAG top-k</dt><dd>${s.rag_top_k}</dd>
          <dt>Copilot mode</dt><dd>${esc(s.llm_provider)}</dd>
          <dt>Random seed</dt><dd>${s.random_seed}</dd>
          <dt>Golden-path RFQs</dt><dd>${s.golden_path_rfqs.join(', ')}</dd>
        </dl>
      </section>
    </div>

    <div class="grid-2">
      <section class="card">
        <div class="card-head">${cardIcon('check', '#1a7a4f', '#e4f2e9')}<h2>System Health</h2>
          <span class="sub"><span class="tag ${h.status === 'ok' ? 'ok' : 'warn'}">${esc(h.status)}</span></span></div>
        <dl class="kv">
          <dt>Suppliers</dt><dd>${s.data_integrity.suppliers}</dd>
          <dt>RFQs</dt><dd>${s.data_integrity.rfqs}</dd>
          <dt>Quotations</dt><dd>${s.data_integrity.rfq_quotes}</dd>
          <dt>Orphan quotations</dt><dd>${s.data_integrity.orphan_quotes}</dd>
          <dt>RFQs without quotes</dt><dd>${s.data_integrity.rfqs_without_quotes}</dd>
          <dt>Risk model</dt><dd>${h.checks.model ? 'trained' : 'not trained'}</dd>
          <dt>Knowledge base</dt><dd>${h.checks.knowledge_base_chunks} clauses</dd>
        </dl>
      </section>
      <section class="card">
        <div class="card-head">${cardIcon('file', '#2f6fd0', '#e7f0fd')}<h2>RAG Governance</h2></div>
        <div class="notice ok">${svg('check', 16)}<div><b>Supplier contracts are not indexed.</b>
          The knowledge base is restricted to ${s.allowed_rag_document_types.join(', ')} (POL-MED-001 §9).
          Supplier master and quotation data stay structured in the database.</div></div>
        <div class="notice plain" style="margin-top:12px">${svg('alert', 16)}<div>${esc(s.disclaimer)}</div></div>
      </section>
    </div>`;
};

/* ====================================================================== router */
async function route() {
  const hash = (location.hash || '#/overview').replace('#/', '');
  const view = views[hash] ? hash : 'overview';
  setActiveNav(view);
  $('#view').innerHTML = `<div class="loading">Loading…</div>`;
  try { await views[view](); }
  catch (e) {
    $('#view').innerHTML = `<section class="card"><div class="notice warn">
      ${svg('alert', 18)}<div><b>Could not load this view.</b><br>${esc(e.message)}<br>
      <span class="footnote">If the application has not been built yet, run
      <span class="mono">python scripts/build_all.py</span>.</span></div></div></section>`;
  }
}

window.addEventListener('hashchange', route);

function init() {
  paintNavIcons();
  closeDrawer();                        // start from a known-closed state

  // Delegated, so closing keeps working no matter what re-renders inside the
  // drawer, and so a missing element can never leave the close button dead.
  document.addEventListener('click', e => {
    const t = e.target;
    if (t.closest && (t.closest('#drawer-close') || t.closest('#scrim'))) {
      e.preventDefault();
      closeDrawer();
    }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeDrawer(); });

  const tryCopilot = $('#btn-try-copilot');
  if (tryCopilot) tryCopilot.onclick = () => {
    location.hash = '#/overview';
    setTimeout(() => { const i = $('#chat-q'); if (i) i.focus(); }, 300);
  };
  const alerts = $('#btn-alerts');
  if (alerts) alerts.onclick = () => { location.hash = '#/approvals'; };

  route();
}

// The script may be evaluated before or after parsing finishes depending on how
// the page is hosted, so handle both rather than assuming DOMContentLoaded is
// still ahead of us.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
