/* Stylesheet regression checks.
 *
 *   node tests/css_check.js
 *
 * Catches the class of bug that unit tests and the render harness cannot see,
 * because it lives in the cascade rather than in the markup or the data.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const CSS = fs.readFileSync(path.resolve(__dirname, '../frontend/styles.css'), 'utf8');
const HTML = fs.readFileSync(path.resolve(__dirname, '../frontend/index.html'), 'utf8');
const JS = fs.readFileSync(path.resolve(__dirname, '../frontend/app.js'), 'utf8');

const strip = s => s.replace(/\/\*[\s\S]*?\*\//g, '');
const rules = [];
{
  const src = strip(CSS);
  const re = /([^{}]+)\{([^{}]*)\}/g;
  let m;
  while ((m = re.exec(src))) rules.push({ sel: m[1].trim(), body: m[2] });
}

let failed = 0;
const check = (name, ok, detail) => {
  if (ok) { console.log(`  ok    ${name}`); return; }
  failed++;
  console.log(`  FAIL  ${name}${detail ? '\n        ' + detail : ''}`);
};

// 1. The `hidden` attribute must beat any author `display` rule.
//    The UA stylesheet's [hidden]{display:none} loses to any author rule that
//    sets display on the same element, so a component styled `display:flex`
//    stays visible when hidden=true and its close button looks broken.
const hiddenRule = rules.find(r => /\[hidden\]/.test(r.sel) && /display\s*:\s*none/.test(r.body));
check('[hidden] is enforced in author CSS',
  !!hiddenRule && /!important/.test(hiddenRule.body),
  'add `[hidden]{display:none !important}` above components that set display');

// 2. Everything toggled via .hidden in JS must be covered by that rule.
const toggled = new Set();
for (const m of JS.matchAll(/\$\('#([\w-]+)'\)[^;\n]*\.hidden\s*=/g)) toggled.add(m[1]);
for (const m of JS.matchAll(/(\w+)\.hidden\s*=\s*(?:true|false)/g)) toggled.add(m[1]);
for (const m of HTML.matchAll(/id="([\w-]+)"[^>]*\shidden/g)) toggled.add(m[1]);
check(`elements toggled by the hidden attribute are covered (${[...toggled].join(', ')})`,
  !!hiddenRule);

// 3. Every id referenced by $('#id') in JS exists in the HTML shell, unless it
//    is created by a view's own innerHTML.
const shellIds = new Set([...HTML.matchAll(/id="([\w-]+)"/g)].map(m => m[1]));
const jsIds = new Set([...JS.matchAll(/id="([\w-]+)"/g)].map(m => m[1]));
const queried = new Set([...JS.matchAll(/\$\('#([\w-]+)'\)/g)].map(m => m[1]));
const missing = [...queried].filter(id => !shellIds.has(id) && !jsIds.has(id));
check('every $("#id") target is defined somewhere',
  missing.length === 0, missing.join(', '));

// 4. The drawer and scrim must both start hidden in the shell.
check('drawer and scrim start hidden',
  /id="drawer"[^>]*\shidden/.test(HTML) && /id="scrim"[^>]*\shidden/.test(HTML));

// 5. body must paint an explicit background (the host paints its own ground).
// `find` would stop at the first `html,body{margin:0}` rule, so check them all.
const bodyRules = rules.filter(r => /(^|,)\s*body\s*(,|$)/.test(r.sel));
check('body sets an explicit background',
  bodyRules.some(r => /background\s*:/.test(r.body)));

console.log(`\n${failed === 0 ? 'PASS' : 'FAIL'} — ${5 - failed}/5 checks passed`);
process.exit(failed === 0 ? 0 : 1);
