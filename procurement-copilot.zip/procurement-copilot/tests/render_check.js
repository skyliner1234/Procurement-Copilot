/* Front-end render check.
 *
 *   node tests/render_check.js
 *
 * Executes every dashboard view against the captured API snapshot inside a
 * minimal DOM shim, so a runtime error or an empty screen fails here instead of
 * during the demo. Run `python scripts/export_static.py` first to refresh the
 * snapshot.
 *
 * The shim is deliberately small: the dashboard renders by assigning innerHTML
 * and wiring handlers through querySelector, so faithful emulation of those two
 * things is enough to exercise every code path that builds a screen.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const SNAP = JSON.parse(fs.readFileSync(path.join(ROOT, 'models/static_snapshot.json'), 'utf8'));

/* ------------------------------------------------------------------ DOM shim */
function makeEl(tag = 'div') {
  const el = {
    tagName: tag.toUpperCase(), _html: '', textContent: '', hidden: false,
    value: '', dataset: {}, style: {}, children: [],
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    appendChild(c) { this.children.push(c); return c; },
    remove() {}, focus() {}, scrollTop: 0, scrollHeight: 0,
    addEventListener() {}, setAttribute() {}, getAttribute: () => null,
    // Elements are valid roots for scoped queries; the shim does not parse
    // innerHTML, so scoped lookups legitimately find nothing.
    querySelector: () => null,
    querySelectorAll: () => [],
    closest: () => null,
  };
  Object.defineProperty(el, 'innerHTML', {
    get() { return this._html; },
    set(v) { this._html = String(v); },
  });
  return el;
}

const registry = new Map();
function elFor(sel) {
  if (!registry.has(sel)) registry.set(sel, makeEl());
  return registry.get(sel);
}

const document = {
  readyState: 'complete',
  querySelector: sel => elFor(sel),
  querySelectorAll: () => [],
  createElement: tag => makeEl(tag),
  addEventListener() {},
  documentElement: makeEl('html'),
  body: makeEl('body'),
};

/* --------------------------------------------------------------- fetch shim */
const fetchLog = [];
async function fetchShim(p, opts = {}) {
  const method = (opts.method || 'GET').toUpperCase();
  const key = method === 'POST' ? 'POST:' + p : p;
  let data = SNAP[key] !== undefined ? SNAP[key] : SNAP[p];
  if (data === undefined && p === '/api/copilot/query') {
    const body = JSON.parse(opts.body || '{}');
    const k = `${body.rfq_id || 'RFQ-102'}||${(body.question || '').toLowerCase()}`;
    data = (SNAP.__copilot__ || {})[k];
  }
  if (data === undefined && p.startsWith('/api/suppliers?')) data = SNAP['/api/suppliers'];
  if (data === undefined && p.startsWith('/api/audit')) data = SNAP['/api/audit?limit=300'];
  fetchLog.push({ path: p, method, hit: data !== undefined });
  if (data === undefined) return { ok: false, status: 404, json: async () => ({ error: 'not captured: ' + p }) };
  return { ok: !data.error, status: data.error ? 400 : 200, json: async () => data };
}

/* ------------------------------------------------------------------- context */
const sandbox = {
  document, fetch: fetchShim, console,
  window: { addEventListener() {} },
  location: { hash: '#/overview' },
  setTimeout: (fn) => { try { fn(); } catch (_) {} return 0; },
  clearTimeout() {}, Date, Math, JSON, encodeURIComponent, isNaN, Number, String, Object, Array,
};
sandbox.globalThis = sandbox;
sandbox.window.location = sandbox.location;

let src = fs.readFileSync(path.join(ROOT, 'frontend/app.js'), 'utf8');
src += '\n;globalThis.__views = views; globalThis.__ask = askCopilot; globalThis.__state = state;';
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: 'app.js' });

/* --------------------------------------------------------------------- run */
(async () => {
  const views = sandbox.__views;
  const names = Object.keys(views);
  let failed = 0;

  console.log(`Rendering ${names.length} views against the captured snapshot\n`);
  for (const name of names) {
    const view = elFor('#view');
    view.innerHTML = '';
    try {
      await views[name]();
      const html = view.innerHTML;
      const bad = /undefined|NaN|\[object Object\]/.test(html);
      const empty = html.length < 400;
      if (bad || empty) {
        failed++;
        console.log(`  FAIL  ${name.padEnd(11)} ${empty ? 'rendered almost nothing' : 'contains undefined/NaN/[object Object]'} (${html.length} chars)`);
        const m = html.match(/.{0,70}(undefined|NaN|\[object Object\]).{0,70}/);
        if (m) console.log(`        …${m[0].replace(/\s+/g, ' ')}…`);
      } else {
        console.log(`  ok    ${name.padEnd(11)} ${String(html.length).padStart(6)} chars`);
      }
    } catch (e) {
      failed++;
      console.log(`  FAIL  ${name.padEnd(11)} ${e.message}`);
      console.log('        ' + (e.stack || '').split('\n')[1]);
    }
  }

  // Copilot round-trip
  try {
    sandbox.__state.chat.length = 0;
    await sandbox.__ask('Which supplier should I select for RFQ-102?');
    const replies = sandbox.__state.chat.filter(m => m.role === 'ai');
    const ok = replies.length === 1 && replies[0].text.length > 80;
    console.log(`  ${ok ? 'ok   ' : 'FAIL '} copilot     ${ok ? replies[0].text.length + ' char answer, ' + (replies[0].citations || []).length + ' citations' : 'no usable answer'}`);
    if (!ok) failed++;
  } catch (e) { failed++; console.log('  FAIL  copilot     ' + e.message); }

  const misses = fetchLog.filter(f => !f.hit);
  if (misses.length) {
    console.log('\n  endpoints not found in the snapshot:');
    misses.forEach(m => console.log(`    ${m.method} ${m.path}`));
  }

  console.log(`\n${failed === 0 ? 'PASS' : 'FAIL'} — ${names.length + 1 - failed}/${names.length + 1} checks passed`);
  process.exit(failed === 0 ? 0 : 1);
})();
