"""Hugging Face integration tests, run against a local mock of the HF router.

    python tests/test_huggingface.py

No API key and no network access are required: a standard-library HTTP server
impersonates the two Hugging Face endpoints the application uses, so the request
shape, the response parsing, the batching, the caching and - most importantly -
the fallback behaviour are all exercised for real.

Covers:
  * provider auto-detection from a single HF_API_KEY
  * chat completions through the OpenAI-compatible router
  * feature-extraction embeddings in both sentence and token-level shapes
  * embedding batching and L2 normalisation
  * vectors cached into the index file, so startup makes no API call
  * dense scores fused into the ranking alongside BM25 and TF-IDF
  * graceful degradation to the deterministic/lexical path on any failure
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.app import config, copilot, db                     # noqa: E402
from backend.app.rag import index as rag_index                  # noqa: E402

CHAT_REPLY = ("MediCore Medical Systems 19 is the best-scoring quotation on "
              "RFQ-102 at 73.5/100 with LOW predicted risk "
              "[Procurement Policy POL-MED-001 - 3. Evaluation priorities (p.1)].")

# What the mock should do next; flipped per test.
BEHAVIOUR = {"chat": "ok", "embed": "sentence", "requests": []}


def _fake_vector(text: str, dims: int = 64) -> list[float]:
    """Hashed bag-of-words stand-in for a real sentence embedding.

    A real embedding model produces vectors that correlate with content, so the
    mock does too - otherwise these tests would only measure how the ranking
    copes with noise rather than how fusion actually behaves.  Deterministic
    across processes (hashlib, not the salted builtin hash).
    """
    vec = [0.0] * dims
    for token in re.findall(r"[a-z0-9]+", text.lower()):
        h = int(hashlib.md5(token.encode()).hexdigest(), 16)
        vec[h % dims] += 1.0
    return vec or [0.01] * dims


def _noise_vector(text: str, dims: int = 64) -> list[float]:
    """Deliberately uninformative vector, for the adversarial fusion test."""
    h = int(hashlib.md5(text.encode()).hexdigest(), 16)
    return [((h >> (i * 3)) % 97) / 97.0 + 0.01 for i in range(dims)]


class MockHF(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, status, payload):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        length = int(self.headers.get("content-length") or 0)
        body = json.loads(self.rfile.read(length) or b"{}")
        BEHAVIOUR["requests"].append({
            "path": self.path,
            "auth": self.headers.get("authorization"),
            "body": body,
        })

        if self.path.endswith("/chat/completions"):
            if BEHAVIOUR["chat"] == "error":
                return self._json(503, {"error": "model is loading"})
            if BEHAVIOUR["chat"] == "empty":
                return self._json(200, {"choices": [{"message": {"content": ""}}]})
            return self._json(200, {
                "choices": [{"message": {"role": "assistant", "content": CHAT_REPLY}}]})

        if "feature-extraction" in self.path:
            if BEHAVIOUR["embed"] == "error":
                return self._json(503, {"error": "service unavailable"})
            texts = body.get("inputs") or []
            if BEHAVIOUR["embed"] == "token":
                # token-level: one matrix per input, to exercise mean pooling
                return self._json(200, [[_fake_vector(t), _fake_vector(t + " b")]
                                        for t in texts])
            if BEHAVIOUR["embed"] == "noise":
                return self._json(200, [_noise_vector(t) for t in texts])
            return self._json(200, [_fake_vector(t) for t in texts])

        self._json(404, {"error": "no such route"})


class HFTestCase(unittest.TestCase):
    """Base class that points config at the mock server."""

    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), MockHF)
        cls.port = cls.server.server_port
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.port}"

        cls._saved = {k: getattr(config, k) for k in
                      ("HF_API_KEY", "HF_ROUTER", "HF_CHAT_URL", "LLM_PROVIDER",
                       "LLM_MODEL", "CHAT_COMPLETIONS_URL", "USE_DENSE_RETRIEVAL",
                       "RAG_INDEX")}
        cls._saved_key_fn = config.llm_api_key

        config.HF_API_KEY = "hf_test_key"
        config.HF_ROUTER = cls.base
        config.HF_CHAT_URL = f"{cls.base}/v1/chat/completions"
        config.LLM_PROVIDER = "huggingface"
        config.LLM_MODEL = "meta-llama/Llama-3.3-70B-Instruct"
        config.CHAT_COMPLETIONS_URL = {"huggingface": config.HF_CHAT_URL}
        config.USE_DENSE_RETRIEVAL = True
        config.llm_api_key = lambda: config.HF_API_KEY
        config.RAG_INDEX = ROOT / "models" / "rag_index_hftest.json"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        for k, v in cls._saved.items():
            setattr(config, k, v)
        config.llm_api_key = cls._saved_key_fn
        rag_index._INDEX = None
        test_index = ROOT / "models" / "rag_index_hftest.json"
        if test_index.exists():
            test_index.unlink()

    def setUp(self):
        BEHAVIOUR.update({"chat": "ok", "embed": "sentence", "requests": []})
        rag_index._INDEX = None


# ==========================================================================
class TestProviderResolution(unittest.TestCase):
    """Auto-detection logic, exercised without touching the network."""

    def test_single_hf_key_selects_huggingface(self):
        self.assertEqual(config._DEFAULT_MODEL["huggingface"], config.HF_CHAT_MODEL)
        self.assertIn("huggingface", config.CHAT_COMPLETIONS_URL)

    def test_router_url_is_openai_compatible(self):
        self.assertTrue(config.HF_CHAT_URL.endswith("/v1/chat/completions"))
        self.assertTrue(config.HF_CHAT_URL.startswith("https://router.huggingface.co"))

    def test_embed_url_targets_feature_extraction(self):
        self.assertIn("feature-extraction", config.HF_EMBED_URL)
        self.assertIn(config.HF_EMBED_MODEL, config.HF_EMBED_URL)


# ==========================================================================
class TestChatCompletions(HFTestCase):

    def test_request_shape_and_auth(self):
        out = copilot._call_openai_compatible("QUESTION: test")
        self.assertEqual(out, CHAT_REPLY)
        req = BEHAVIOUR["requests"][-1]
        self.assertTrue(req["path"].endswith("/v1/chat/completions"))
        self.assertEqual(req["auth"], "Bearer hf_test_key")
        self.assertEqual(req["body"]["model"], "meta-llama/Llama-3.3-70B-Instruct")
        roles = [m["role"] for m in req["body"]["messages"]]
        self.assertEqual(roles, ["system", "user"])
        self.assertIn("Never invent", req["body"]["messages"][0]["content"])

    def test_copilot_uses_the_llm_and_reports_the_mode(self):
        with db.session() as conn:
            a = copilot.answer(conn, "Which supplier should I select for RFQ-102?",
                               "RFQ-102")
        self.assertEqual(a["answer"], CHAT_REPLY)
        self.assertTrue(a["mode"].startswith("llm:huggingface:"))
        # Facts and citations are still computed locally and returned alongside.
        self.assertTrue(a["facts"])
        self.assertTrue(a["citations"])

    def test_prompt_only_contains_verified_material(self):
        with db.session() as conn:
            copilot.answer(conn, "Why is the top supplier recommended?", "RFQ-102")
        prompt = BEHAVIOUR["requests"][-1]["body"]["messages"][1]["content"]
        self.assertIn("VERIFIED FACTS", prompt)
        self.assertIn("BUYER DOCUMENTATION", prompt)

    def test_falls_back_when_the_service_errors(self):
        BEHAVIOUR["chat"] = "error"
        with db.session() as conn:
            a = copilot.answer(conn, "Which supplier should I select for RFQ-102?",
                               "RFQ-102")
        self.assertIn("grounded-deterministic", a["mode"])
        self.assertIn("unavailable", a["mode"])
        self.assertIn("decision support", a["answer"].lower())

    def test_falls_back_when_the_reply_is_empty(self):
        BEHAVIOUR["chat"] = "empty"
        with db.session() as conn:
            a = copilot.answer(conn, "Which supplier should I select for RFQ-102?",
                               "RFQ-102")
        self.assertEqual(a["mode"], "grounded-deterministic")
        self.assertTrue(len(a["answer"]) > 100)


# ==========================================================================
class TestEmbeddings(HFTestCase):

    def _backend(self):
        return rag_index.HuggingFaceEmbeddingBackend()

    def test_missing_key_refuses_to_construct(self):
        saved = config.HF_API_KEY
        config.HF_API_KEY = ""
        try:
            with self.assertRaises(RuntimeError):
                rag_index.HuggingFaceEmbeddingBackend()
        finally:
            config.HF_API_KEY = saved

    def test_sentence_shape_is_normalised(self):
        vecs = self._backend().encode(["alpha", "beta"])
        self.assertEqual(len(vecs), 2)
        for v in vecs:
            self.assertAlmostEqual(math.sqrt(sum(x * x for x in v)), 1.0, places=6)

    def test_token_shape_is_mean_pooled(self):
        BEHAVIOUR["embed"] = "token"
        vecs = self._backend().encode(["alpha", "beta"])
        self.assertEqual(len(vecs), 2)
        self.assertEqual(len(vecs[0]), 64)
        for v in vecs:
            self.assertAlmostEqual(math.sqrt(sum(x * x for x in v)), 1.0, places=6)

    def test_encoding_is_batched(self):
        saved = config.HF_EMBED_BATCH
        config.HF_EMBED_BATCH = 3
        try:
            self._backend().encode([f"t{i}" for i in range(7)])
        finally:
            config.HF_EMBED_BATCH = saved
        embed_calls = [r for r in BEHAVIOUR["requests"] if "feature-extraction" in r["path"]]
        self.assertEqual(len(embed_calls), 3)                   # 3 + 3 + 1
        self.assertEqual([len(c["body"]["inputs"]) for c in embed_calls], [3, 3, 1])

    def test_same_text_embeds_consistently(self):
        a = self._backend().encode(["identical"])[0]
        b = self._backend().encode(["identical"])[0]
        self.assertEqual([round(x, 6) for x in a], [round(x, 6) for x in b])


# ==========================================================================
class TestDenseIndex(HFTestCase):

    def test_index_builds_with_dense_and_caches_vectors(self):
        idx = rag_index.build_index(verbose=False, use_dense=True)
        self.assertIsNotNone(idx.embeddings)
        self.assertEqual(len(idx.embeddings), idx.N)
        self.assertIn("dense", idx.retriever_name())

        saved = json.loads(config.RAG_INDEX.read_text())
        self.assertIn("embeddings", saved)
        self.assertEqual(len(saved["embeddings"]), idx.N)
        self.assertEqual(saved["embedding_model"], config.HF_EMBED_MODEL)

    def test_reload_uses_the_cache_and_makes_no_embedding_calls(self):
        rag_index.build_index(verbose=False, use_dense=True)
        rag_index._INDEX = None
        BEHAVIOUR["requests"].clear()

        idx = rag_index.get_index()
        self.assertIsNotNone(idx.embeddings)
        embed_calls = [r for r in BEHAVIOUR["requests"] if "feature-extraction" in r["path"]]
        self.assertEqual(embed_calls, [], "startup must not re-embed the corpus")

    def test_query_embedding_is_fused_into_the_ranking(self):
        idx = rag_index.build_index(verbose=False, use_dense=True)
        BEHAVIOUR["requests"].clear()
        hits = idx.search("What are the supplier risk thresholds?", 3)
        self.assertTrue(hits)
        embed_calls = [r for r in BEHAVIOUR["requests"] if "feature-extraction" in r["path"]]
        self.assertEqual(len(embed_calls), 1, "one live call to embed the query")
        self.assertEqual(embed_calls[0]["body"]["inputs"],
                         ["What are the supplier risk thresholds?"])

    def test_lexical_quality_is_preserved_with_dense_enabled(self):
        """The known-clause probes must still land after fusion."""
        idx = rag_index.build_index(verbose=False, use_dense=True)
        probes = [
            ("What are the supplier risk thresholds?", "POL-MED-001", "Risk thresholds"),
            ("Does the lowest price guarantee the award?", "CON-MED-001", "Pricing"),
            ("Who holds final award authority?", "CON-MED-001", "Human decision authority"),
        ]
        for q, doc, section in probes:
            hits = idx.search(q, 3)
            self.assertTrue(
                any(h["document_id"] == doc and section.lower() in h["section"].lower()
                    for h in hits),
                f"{q} -> {[h['section'] for h in hits]}")

    def test_build_degrades_to_lexical_when_embedding_fails(self):
        BEHAVIOUR["embed"] = "error"
        idx = rag_index.build_index(verbose=False, use_dense=True)
        self.assertIsNone(idx.embeddings)
        self.assertIsNotNone(idx.embedding_error)
        self.assertEqual(idx.retriever_name(), "hybrid-bm25+tfidf")
        # Retrieval still works.
        self.assertTrue(idx.search("What are the risk thresholds?", 3))

    def test_lexical_precision_survives_an_uninformative_dense_signal(self):
        """Down-weighted fusion must not let a bad embedding displace a clause.

        This is the regression test for the reason DENSE_FUSION_WEIGHT exists:
        under equal-weight RRF a useless dense ranking gets a third of the vote
        and pushes the exact clause out of the top 3.
        """
        BEHAVIOUR["embed"] = "noise"
        idx = rag_index.build_index(verbose=False, use_dense=True)
        self.assertIsNotNone(idx.embeddings)
        hits = idx.search("What are the supplier risk thresholds?", 3)
        self.assertTrue(
            any(h["document_id"] == "POL-MED-001" and "risk thresholds" in h["section"].lower()
                for h in hits),
            f"noise displaced the correct clause -> {[h['section'] for h in hits]}")

    def test_dense_ranking_is_down_weighted(self):
        self.assertLess(config.DENSE_FUSION_WEIGHT, 1.0)
        weights = [1.0, 1.0, config.DENSE_FUSION_WEIGHT]
        scores = rag_index.HybridIndex._rrf([[0, 1], [0, 1], [1, 0]], 2, weights=weights)
        self.assertGreater(scores[0], scores[1],
                           "two lexical votes must outweigh one dense vote")

    def test_search_survives_a_query_embedding_failure(self):
        idx = rag_index.build_index(verbose=False, use_dense=True)
        BEHAVIOUR["embed"] = "error"                 # break only the query call
        hits = idx.search("Who holds final award authority?", 3)
        self.assertTrue(hits, "a failed query embedding must not break retrieval")
        self.assertTrue(any(h["document_id"] == "CON-MED-001" for h in hits))


if __name__ == "__main__":
    if not config.DB_PATH.exists():
        raise SystemExit("Run `python scripts/build_all.py` before the tests.")
    unittest.main(verbosity=2 if "-v" in sys.argv else 1,
                  argv=[a for a in sys.argv if a != "-v"])
